# Reactive MD 组块协议

**中文** · [English](component-protocol-en.md)

协议修订 `component-protocol-3` · 适用语法 `local-draft-3` · 当前包版本 `0.7.0`

Reactive MD 的组块就是语言中的组件。本协议规定组块在贡献、实现和验收中的共同契约，连接作者语法、编译器、运行时、React 参考适配器和机器验收数据。作者写文档时以[本地交互语法规范](../reference/local-interaction-syntax-ch.md)为准；宿主接入以[本地模式集成](../integration/local-integration-ch.md)为准；本文供贡献者、评审和测试使用。

| 想了解 | 阅读 |
| --- | --- |
| 怎么写文档 | [新用户入门指南](../guides/local-guide-ch.md)、[语法规范](../reference/local-interaction-syntax-ch.md) |
| 怎么新增或修改组块 | [组块开发指南](component-development-ch.md)、本文第 12、13 节 |
| 怎么运行验收 | [语言验收数据](../../examples/conformance/README.md)、本文第 11 节 |
| 版本和迁移规则 | [版本与兼容性](../compatibility/compatibility-ch.md) |
| 安全边界 | [安全策略](../../SECURITY-ch.md) |

## 1. 状态、术语与约束力

### CP-SCOPE-01 版本轴（现有）

Reactive MD 分别维护以下版本轴：

| 版本轴 | 当前值 | 决定什么 |
| --- | --- | --- |
| 包版本 | `0.5.2` | npm 发布、核心与 React 入口、升级兼容规则 |
| 语法修订 | `local-draft-3` | 作者可以写出的标签、属性和表达式 |
| 协议修订 | `component-protocol-3` | 组块贡献要求、验收门槛和机器数据语义 |
| 主题协议 | `reactive-md-theme-1` | 主题登记、样式变量、深浅模式与主题验收 |

协议修订独立于包版本和语法版本。一个包版本只接受一个语法修订。协议修订可以在不改变作者语法的前提下提高贡献和验收要求；语法修订变化也不必自动提升协议修订。

### CP-SCOPE-02 规范来源（现有）

本协议复述现有行为时，以下文件是权威来源：

- 作者语法：[本地交互语法规范](../reference/local-interaction-syntax-ch.md)。
- 核心与 React API：[本地模式集成](../integration/local-integration-ch.md)。
- 安全边界与宿主责任：[安全策略](../../SECURITY-ch.md)。
- 版本、诊断契约与平台范围：[版本与兼容性](../compatibility/compatibility-ch.md)。
- 实现代码：`src/local/` 下的解析器、声明表、编译器、运行时和渲染器。

本协议不复制完整属性表。属性默认值、允许值和静态/动态标记以 `src/local/configuration/schema.ts` 和语法规范为准。

### CP-SCOPE-03 规范用词（要求）

| 词 | 含义 |
| --- | --- |
| 必须（MUST） | 不满足即不符合本协议，评审不得通过 |
| 不得（MUST NOT） | 明确禁止 |
| 应当（SHOULD） | 默认遵守；偏离时必须在提案中记录理由和替代证据 |
| 可以（MAY） | 可选，不影响符合性 |

### CP-SCOPE-04 条款标记（要求）

每条条款带一个标记：

- **（现有）**：复述当前代码和已发布文档中的行为，用于回归和评审。
- **（要求）**：本协议对新增或修改组块提出的要求；当前实现未必已经自动检查，评审时必须提供证据。
- **（边界）**：本修订明确不承诺的能力，不能作为验收依据。

复述现有行为的条款与语法规范、集成文档或代码不一致时，贡献者必须记录差异并提供最小复现。维护者确认预期行为后，按修复或迁移规则同步规范、实现和验收数据。本协议新增的贡献要求按“要求”标记识别。

### CP-SCOPE-05 适用范围（边界）

本协议适用于 `local-draft-3` 的 49 个标签名、它们的编译、运行时和参考渲染行为，以及向仓库提交新组块或修改现有组块的流程。

本文规定贡献与验收契约。作者教程和宿主 API 各有独立文档，HTML 可移植范围见 CP-CORE-03，扩展接口边界见 CP-CORE-05。

## 2. 组块模型

### CP-MODEL-01 组块分类（现有）

`local-draft-3` 固定 49 个标签名，分为以下类别：

| 类别 | 组块 | 说明 |
| --- | --- | --- |
| 输入控件 | `input`、`textarea`、`number`、`slider`、`range-slider`、`coordinate`、`toggle`、`checkbox`、`date`、`select`、`choices`、`radio-group`、`multi-select`、`option` | 读取读者输入并可选公开参数 |
| 自操作控件 | `counter`、`timer`、`checklist`、`progress` | 自带增减、计时、勾选或进度显示 |
| 组织与结构 | `panel`、`card`、`grid`、`tabs`、`tab`、`steps`、`step`、`accordion`、`disclosure`、`if` | 排版、切换、折叠、分步阅读和条件显示 |
| 跳转与正文 | `jump`、`anchor`、`text`、`section` | 跳转、显式锚点和受控前景色 |
| 练习 | `quiz` | 选择或数字自测题；不公开绑定 |
| 反馈 | `alert`、`badge`、`tooltip` | 提示和行内说明 |
| 声明 | `computed`、`const`、`validation` | 按标签解析但不渲染为控件 |
| 生成数据与可视化 | `data-table`、`column`、`table`、`chart`、`plot`、`timeline`、`diagram`、`node`、`edge` | 生成行、表格、图表、函数曲线、时间轴和图解 |

`option`、`tab`、`disclosure`、`node`、`edge`、`step`、`column` 是结构子项，只在指定父组块内出现。`computed`、`const` 是不可见声明；`validation` 在规则不满足时生成可访问的提示。开头的 `<theme>` 声明是文档元数据，不是组块。完整名称和用途见[语法规范第 12 节](../reference/local-interaction-syntax-ch.md#12-组件速查与语法裁剪)。

### CP-MODEL-02 三种形态（现有）

| 形态 | 作者写法 | 当前组块 |
| --- | --- | --- |
| 无正文（leaf） | `<slider ...>`，不写结束标签；也接受 `<slider ... />` | `input`、`textarea`、`number`、`slider`、`range-slider`、`coordinate`、`toggle`、`checkbox`、`date`、`counter`、`timer`、`progress`、`edge`、`anchor`、`computed`、`const`、`validation`、`column` |
| 行内（inline） | 成对标签，内容嵌入句子 | `badge`、`tooltip`、`jump`、`text` |
| 容器（container） | 成对标签，内部继续解析 Markdown 或子组块 | 其余组块 |

无正文组块不得携带正文；容器必须显式闭合，不允许自动闭合或纠正错配标签。`textarea` 的文本通过 `initial` 设置，因此属于无正文组块。

### CP-MODEL-03 声明内容（要求）

一个组块提案的声明至少包含以下信息；无绑定或无计算等不适用项须明确注明：

| 信息 | 内容 |
| --- | --- |
| 名称 | 小写 kebab-case 标签名 |
| 形态 | 无正文、行内或容器 |
| 子项规则 | 允许的直接子项；结构子项的允许父级 |
| 标签要求 | `label` 必填、可选或不适用 |
| 属性表 | 名称、类型、静态或动态、必填、默认值、约束 |
| 绑定 | 公开值类型、family、是否独占、默认初值规则 |
| 初值规则 | 省略 `initial` 时如何生成公开值 |
| 渲染 | 参考适配器的元素、可访问名称、键盘操作和样式钩子 |
| 诊断 | 结构、属性、绑定、初值、预算失败时的诊断类别 |
| 预算 | 新增无界输入、循环、递归或计算时定义的资源上限 |
| 兼容分类 | 能力新增、破坏性变更或实现/编辑性变更 |
| 验收证据 | 自动测试、机器验收数据和人工浏览器检查 |

当前声明表是 `src/local/configuration/schema.ts`，标签词法集合在 `src/local/parsing/parser.ts`，语义校验在 `src/local/compilation/compiler.ts`，写入约束在 `src/local/runtime/runtime.ts`，渲染在 `src/local/rendering/LocalDocumentView.tsx` 和 `src/local/widgets/visuals.tsx`。只改声明表不会自动获得解析、校验或渲染能力。

### CP-MODEL-04 名称集合（现有）

`local-draft-3` 的 49 个名称是当前语法的完整集合。新增名称、删除名称或改变名称含义都属于作者可见变化，按第 10 节处理。实现可以在内部使用未公开的节点类型，但作者只能使用这里和语法规范列出的名称。

## 3. 名称、语法和属性

### CP-SYNTAX-01 名称拼写（现有）

标签名和属性名必须使用小写 kebab-case，匹配 `^[a-z][a-z0-9]*(?:-[a-z0-9]+)*$`。属性名重复、结束标签带属性、标签名或属性名不合规都产生编译诊断。作者不能定义新标签，也不能用 `class`、`style` 或 `on-*` 扩展组块。

### CP-SYNTAX-02 形态与嵌套（现有）

- 无正文组块不写结束标签；末尾 `/` 可以作为自闭合写法。
- 容器必须写配对的结束标签；结束标签必须匹配最近尚未关闭的容器。
- 不支持自动闭合、自动补全或纠正错配标签。
- 行内组块为 `badge`、`tooltip`、`jump`、`text`，可以嵌入句子；其他组块按块级内容处理。
- 代码围栏和行内代码中的标签、插值和公式按原文显示，不激活；Markdown 注释不产生显示内容、组块或绑定。

### CP-SYNTAX-03 属性值（现有）

普通属性值必须用单引号或双引号包围；布尔属性可以省略值，表示 `true`。属性顺序无语义，重复属性报错。属性值中的 `&quot;`、`&apos;`、`&amp;`、`&lt;`、`&gt;` 解码为对应字符；反斜杠不用于转义属性引号。

缺省布尔属性采用组块声明的默认值，不统一假定为 `false`。例如 `panel.reset` 默认为 `true`。

### CP-SYNTAX-04 静态与动态值（现有）

声明为静态的属性不得包含插值。动态属性可以使用合法字面量；使用插值时，数字、布尔或枚举属性必须是一个完整的 `{{ 表达式 }}`，结果保持对应类型。文本属性可以包含多段插值，输出按文本处理。

```markdown
<slider bind="people" label="人数" initial="2" min="1" max="20">
<number bind="lowerBound" label="下限" initial="-2">
<number bind="upperBound" label="上限" initial="2">
<if when="{{ people >= 5 }}">
<plot min="{{ lowerBound }}" max="{{ upperBound }}">
$$ y = x^2 $$
</plot>
</if>
```

`bind`、`initial`、`id`、`value`、`from`、`to`、`kind`、`type` 和布局枚举等是静态属性；`disabled`、`if.when`、`plot.min`、`plot.max` 和 `node.tone` 是动态属性。完整清单以 `schema.ts` 的 `static`、`dynamic` 标记为准。

### CP-SYNTAX-05 标签与可访问名称（现有）

`label` 的必填、可选或不适用由组块声明决定。必填标签不能缺失或只有空白；标签可以是动态文本。输入控件的 `label` 同时是可访问名称。可选标签省略时，参考适配器必须提供稳定的可访问名称回退，不能留下无名控件。

### CP-SYNTAX-06 子项规则（现有）

| 子项规则 | 允许内容 | 当前组块 |
| --- | --- | --- |
| 无子项 | 不得有正文或子组块 | 无正文控件、`progress`、`edge`、`anchor`、`computed`、`const`、`validation`、`column` |
| 行内内容 | 行内 Markdown，不得嵌套组件标签 | `option`、`badge`、`tooltip`、`jump`、`text` |
| 选项 | 一个或多个 `option` | `select`、`choices`、`radio-group`、`multi-select`、`quiz`（选择题） |
| 标签页 | 一个或多个 `tab` | `tabs` |
| 步骤 | 一个或多个 `step` | `steps` |
| 折叠项 | 一个或多个 `disclosure` | `accordion` |
| 卡片 | 一个或多个 `card` | `grid` |
| 图解 | 一个或多个 `node`，可选 `edge` | `diagram` |
| 表格 | 正好一张 Markdown 表格 | `table`、`chart`、`timeline` |
| 列 | 1 至 20 个 `column` 声明 | `data-table` |
| 公式 | 一个或多个 `$$...$$` 公式块 | `plot` |
| 内容 | 任务列表或静态说明 | `checklist`、`node` |
| 普通内容 | Markdown 和组块，按组块附加规则 | `panel`、`card`、`tab`、`step`、`if`、`alert`、`section` |

`checklist` 的正文必须正好是一层 Markdown 任务列表；`node` 的说明可以包含文本插值，但不得包含交互组块。`choice` 类型的 `quiz` 接受 `option` 子项，`number` 类型的正文为空。结构子项出现在错误父级、容器缺少必需子项或子项类型不符时，编译失败。

### CP-SYNTAX-07 Markdown 上下文（现有）

组块可以位于段落或独立块中。容器内容按共同缩进去缩进后继续按 Markdown 解析；代码围栏内部的缩进保持原样。解析器先识别代码、数学区域和标签边界，再解释插值，不能通过对整篇文档的字符串替换实现语法。

### CP-SYNTAX-08 作者能力边界（现有）

作者不能执行脚本、写入可执行 HTML、提供作者 CSS、注册事件处理器或声明网络服务调用。图片与链接受 CP-SEC-02 的宿主 URL 策略约束。`<script>`、`<style>`、`on-*`、`class`、`style` 和旧版 directive 都不属于 `local-draft-3`。完整未知标签按源码降级，结构不完整或无法恢复的标签产生错误。文档内容不会作为任意 HTML 执行。

## 4. 绑定与状态

### CP-STATE-01 绑定名称（现有）

`bind` 必须匹配 `[A-Za-z_][A-Za-z0-9_]*`，区分大小写，长度不超过 128 字符。表达式内置函数名、`x`、`y`、`pi`、`e`、`true`、`false`、`null` 以及 `__proto__`、`prototype`、`constructor` 是保留名称，不能作为绑定名。

省略 `bind` 的组块仍有内部状态，使用内部键 `@<node.id>`，但该键不进入公开参数集合，不能被表达式引用。公开参数只包含显式 `bind` 的名称。

### CP-STATE-02 绑定 family（现有）

| family | 公开值 | 组块 |
| --- | --- | --- |
| `text` | 字符串 | `input`、`textarea` |
| `number` | 有限数字 | `number`、`slider`、`counter` |
| `boolean` | 布尔值 | `toggle`、`checkbox` |
| `date` | `YYYY-MM-DD` 或空字符串 | `date` |
| `choice` | 选项字符串 | `select`、`choices`、`radio-group` |
| `timer` | 剩余秒数，非负数字 | `timer` |
| `checklist` | 已选条目 ID 的字符串数组 | `checklist` |
| `tabs` | 当前标签页 value | `tabs` |
| `diagram` | 当前节点 ID | `diagram` |
| `multi-select` | 按源码顺序排列的选项 value 数组，独占 | `multi-select` |
| `steps` | 当前步骤 value，独占 | `steps` |
| `selection` | 稳定行标识，空字符串表示未选 | 带 key 的 `table`、`chart` |

range-slider 和 coordinate 的每个数值槽位也独占拥有绑定；范围、步长、默认值和原子批量写入见[扩展声明](../reference/local-components-v2-ch.md)。selection 允许表格和图表共享，但有序标识集合必须相同。新组件继续遵守以下初始化、拒绝写入、隐藏、重置和销毁条款。

`timer`、`checklist`、`tabs`、`diagram` 同时是独占 family：一个公开参数只能由一个组块拥有，其他控件不能声明同名绑定。宿主仍可通过所属节点调用公开的 `runtime.set`，写入遵守同一套校验。

### CP-STATE-03 共享约束（现有）

同名绑定只有在以下条件全部满足时才合法：

- 所有组块属于同一 family。
- 数值绑定的 `min`、`max`、`step` 完全一致。
- 选择器的 option value 集合与顺序完全一致。
- 独占 family 只有一个组块。
- 同一绑定最多出现一次显式 `initial`。

共享控件的标签文字和组件外观可以不同。违反共享条件时产生编译错误；错误信息指出冲突的位置。

### CP-STATE-04 初始化（现有）

公开值在文档实例创建时初始化一次。条件区域、未激活的标签页和关闭的折叠面板中的组块同样参与初始化；隐藏后重新显示不会再次初始化。

没有显式 `initial` 时，按组块声明生成默认值：

| 初值规则 | 组块 | 结果 |
| --- | --- | --- |
| `empty` | `input`、`textarea`、`date` | 空字符串 |
| `false` | `toggle`、`checkbox` | `false` |
| `min` | `slider`；`range-slider.start` | `min`，默认范围 0 到 100 |
| `max-step` | `range-slider.end` | 不超过 `max` 的最大合法步长值 |
| `nearest-zero` | `number`、`counter`；`coordinate.x` 与 `coordinate.y` | 范围内最接近 0 的合法步长值；等距时取较小值 |
| `first-option` | 选择器 | 第一个 option 的 value |
| `empty-array` | `multi-select` | 空字符串数组 |
| `first-tab` | `tabs` | 第一个标签页的 value |
| `first-step` | `steps` | 第一个步骤的 value |
| `first-node` | `diagram` | 第一个节点的 id |
| `checked` | `checklist` | 任务列表中已勾选的条目 ID |
| `duration` | `timer` | `duration`，默认 60 |
| `none` | `table`、`chart` 选择 | 未选时为空字符串 |

共享绑定没有显式初值时采用源码中首个组块的默认值，并校验所有成员的约束。

### CP-STATE-05 初值校验（现有）

显式初值必须是静态值。编译期校验数值范围、步长、日期格式、选项成员、文本长度、邮箱格式和共享约束。越界、不在步长上、未知选项或类型不符都产生错误，不静默修正。合法的空字符串可以表示尚未选择；该值在读者输入前保持公开。

`initial` 只属于文档初始化数据，不是持久化格式。源码变化后创建新实例，重新按新源码初始化。

### CP-STATE-06 写入与原子性（现有）

运行时 `set(node, value)` 以编译文档登记的控件为准，忽略调用方伪造的节点元数据。写入会依次检查：

1. 组块是否有可写绑定。
2. 值的类型和资源预算。
3. 绑定自身的范围、步长和选项约束。
4. 所有共享控件的附加约束，例如必填、长度、邮箱和日期范围。

全部通过后只提交一次，所有依赖内容看到同一个新状态；任一控件拒绝时不改变状态、不增加 revision，并返回运行时诊断。清单数组值按条目的源码顺序规范化。写入与当前值相同时不提交，也不通知订阅者。

### CP-STATE-07 输入草稿（现有）

数字框和文本框中尚未合法的中间输入保存在渲染器本地草稿中，不进入公开状态。例如数字框的空串、负号，文本框中未通过邮箱或长度检查的内容。合法后立即提交；失焦时仍不合法则显示提示，其他内容继续读取最后一次合法值。面板重置会清除草稿。

### CP-STATE-08 重置（现有）

`runtime.reset(node)` 一次恢复该节点子树内的全部绑定和内部组件状态，只提交一次并只通知一次。范围规则：

- 子树内控件的绑定恢复到编译初值；共享变量在子树外的显示同步更新。
- 子树内组块通过 `resetToken` 感知重置，恢复本地选择、表格查询、排序、分页、图表图例、绘图读数、标签页、折叠状态和计时器状态。
- 条件中尚未显示的子控件也属于重置范围。
- 面板的“恢复默认”调用同一机制；嵌套面板的内层重置只影响内层，外层重置覆盖整个子树。
- 未绑定组块的内部状态同样重置；其内部键仍不属于公开参数。

### CP-STATE-09 展示状态不是权限（现有）

`disabled` 和 `if` 只控制界面展示与输入。它们不是授权、数据校验或服务端权限边界。宿主必须在提交到服务端时重新校验权限和业务约束。

### CP-STATE-10 slider 的代表性规范点（现有）

`slider` 是简单数值控件的代表：

- family 为 `number`，`min`、`max`、`step` 是静态数值属性，默认 `0`、`100`、`1`。
- 省略 `initial` 时取 `min`；显式初值必须在范围内并落在以 `min` 为基点的步长上。
- 运行时拒绝越界、非有限数字和不在步长上的写入，且拒绝时保持上一次合法状态。
- 与其他数值控件共享绑定时，所有成员的 `min`、`max`、`step` 必须完全一致。
- 无 `bind` 时仍可操作，状态保存在内部键，不公开给表达式。

### CP-STATE-11 tabs 的代表性规范点（现有）

`tabs` 是容器型公开状态组块的代表：

- 公开值类型为字符串，family 为 `tabs`，独占拥有，第二个组块不能声明同名绑定。
- `tab.value` 是静态唯一值；省略时按源码顺序生成 `tab-1`、`tab-2` 等。
- 无 `initial` 时选择第一个标签页；显式初值必须指向现有标签页。
- 无 `bind` 时选择只保留在组件内部；有 `bind` 时切换写入公开值。
- 隐藏标签页的内容仍参与编译和初始化，保留子内容状态；其中的计时器暂停，恢复显示后由读者再次启动。
- 面板重置恢复标签页初值，同时恢复子内容状态。

### CP-STATE-12 plot 的代表性规范点（现有）

`plot` 是计算型可视化的代表：

- 正文只能是空白和一个或多个 `$$...$$` 公式块；每块定义一条显式 `y = 表达式` 曲线、一条参数方程 `\begin{cases} x = f(t) \\ y = g(t) \end{cases}` 曲线，或一条关于 `x` 和 `y` 的隐式方程。
- `min`、`max` 可以动态，要求 `min < max`；静态范围在编译期校验，动态范围在渲染时校验，非法范围显示局部错误，不静默截断。对显式曲线它们是横轴范围，对参数方程是 `t` 的范围，对隐式方程决定方形追踪区域。
- `samples` 是静态整数，范围 2 到 2000；每个 `plot` 最多 16 条曲线。
- 显式或参数曲线请求 `samples` 个采样点；隐式曲线每轴追踪 `samples`×`samples` 网格（上限 100、下限 32），按网格面积计入请求点数。
- 整篇文档的曲线采样点总数最多 20,000，包括隐藏区域；绘图计算共享 2,000,000 步预算。
- 公式只能引用已声明的数字参数；未声明参数或非数字参数在编译期诊断。参数方程块内的 `t` 是局部参数，在那里不能读取为文档参数。
- 非有限采样形成断点，不把断点两侧直接连线；没有有效值时显示空态。
- 参考适配器提供图例、指针和键盘读数；真实指针、键盘和窄屏行为按第 11 节人工检查。

## 5. 诊断与降级

### CP-DIAG-01 诊断契约（现有）

`Diagnostic` 包含 `code`、`message`、`severity`、`range`、`line`、`column`。`line` 和 `column` 从 1 开始；`range` 是当前源码字符串中的索引。`code` 是字符串标识；`message` 是默认英文显示文本，调用方不得解析 message 或按完整文本做业务判断。

### CP-DIAG-02 编译结果与严重程度（现有）

编译结果只有两种：

- 成功：`ok: true`，带有文档和诊断；诊断可以包含警告。
- 失败：`ok: false`，只有诊断；交互预览停用。

结构完整但未知的标签产生警告；组件结构不完整、标签错配、已知组块的未知属性或类型错误、绑定错误、表达式错误和预算超限产生错误。错误阻止编译成功，警告不阻止。正常脚注不产生不支持警告。

### CP-DIAG-03 降级隔离（现有）

结构完整的未知标签按原始源码显示，给出 `local.component.unknown` 警告。降级区域内的控件、插值和公式不执行，不初始化绑定，也不产生网络动作。脚注支持 Markdown 排版、编号和返回链接；脚注正文中的控件与插值仍按文字显示，不初始化绑定。其他正文和交互继续工作。

无法可靠恢复的未知标签和标签结构错误仍然阻止编译，不能通过降级绕过校验。

### CP-DIAG-04 运行时错误隔离（现有）

控件写入被拒绝时返回 `local.runtime.value` 或 `local.runtime.binding` 诊断，公开状态保持上一次合法值。表达式、表格、图表或绘图中的局部计算错误显示在对应内容附近，显示“无法计算”或相应空态，其他独立内容继续更新。单个组块的渲染异常由错误边界隔离，并在 revision 变化后重试。

### CP-DIAG-05 隐藏分支仍是编译范围（现有）

条件为假、标签页未激活或折叠面板关闭只影响显示，不影响编译。隐藏分支中的未声明变量、类型错误、结构错误和预算超限仍是编译错误。运行时隐藏只保留状态和暂停计时，不跳过校验。

### CP-DIAG-06 诊断码稳定性（契约）

同一 0.x minor 系列内，现有诊断 `code` 的含义保持稳定；允许新增码。删除、改名或改变含义须在新 minor 版本中说明迁移。`message` 是可本地化的显示文案，测试和机器验收按 `code` 与结构化字段判断。计数单位与预算作用域见[诊断与计数规则](../reference/diagnostics-counting-ch.md)。

## 6. 可访问性、主题与样式

### CP-A11Y-01 可访问名称与状态（现有）

每个交互组块必须提供可访问名称，并暴露当前状态。输入控件使用 `label` 作为名称；需要独立操作的容器和可视化在省略可选标签时使用稳定的回退名称。选择器、标签页、折叠、清单、进度、计时器、表格、图表、绘图和图解必须把选中、展开、进度、剩余时间、排序或读数等状态暴露给辅助技术。只靠颜色区分状态不符合要求。

### CP-A11Y-02 键盘与焦点（现有）

交互组块必须可键盘到达和操作。标签页支持方向键、Home 和 End；图解节点支持 Tab 聚焦和回车选择；绘图支持方向键、Home 和 End 读数；表格排序和分页使用可聚焦控件。条件区域隐藏时，如果焦点位于其中，参考适配器把焦点移出隐藏内容。新组块不得把焦点留在不可见元素中。

### CP-A11Y-03 人工检查（现有 / 边界）

本协议的机器验收数据不覆盖真实键盘、输入法组合输入、375px 窄屏、读屏软件和计时器暂停等浏览器行为。这些项目需要对应的浏览器自动检查或第 11 节的人工检查。未完成的检查必须记录，不能写成已通过。

### CP-STYLE-01 全局样式与主题（现有）

`reactive-md/styles.css` 是全局样式表，不通过 Shadow DOM 或 CSS Modules 隔离。宿主显式引入一次。主题变量声明在 `.md-document` 和 `.reactive-md-theme` 上。文档级主题选择、登记与深浅模式遵从[主题协议](../reference/theme-protocol-ch.md)；`colorScheme="auto"` 读取最近祖先的显式模式或系统偏好，兼容 `data-theme="dark|light"`。

### CP-STYLE-02 样式钩子不是 API（现有）

主题优先使用公共 CSS 变量；组件外层 `.md-*`、`.local-*` 类和语义状态属性按主题协议作为样式接口。内部节点排列不属于扩展接口。两个 React 组件都不接受 `className` 或 `style`；作者也不能写 class 或 style。新组块使用现有前缀和主题变量，并在内置默认主题与两种模式下可用。

### CP-STYLE-03 新组块的样式要求（要求）

新组块必须：

- 在 375px 宽度下可用，不产生横向溢出或不可达操作。
- 使用现有主题变量和 `.md-*`、`.local-*` 前缀，不覆盖文档外的全局选择器。
- 为键盘焦点提供可见样式，为选中、禁用、错误和空态提供非颜色线索。
- 不在 JavaScript 导入时自动注入新的全局样式；样式随 `styles.css` 分发。
- 在提案中列出新增或修改的样式文件和人工检查截图或记录。

## 7. 可见性、实例与销毁

### CP-VIS-01 隐藏保留状态（现有）

`if` 为假、标签页未激活、折叠面板关闭时，内容不显示，但参数、标签页选择和清单勾选保留。隐藏不会重新初始化绑定，也不会跳过诊断。切换显示只更新视图，不创建新的文档状态。

### CP-VIS-02 计时与焦点（现有）

隐藏区域中的计时器暂停，公开秒数停在暂停点；恢复显示后保持暂停，由读者再次启动。条件区域隐藏时不得让键盘焦点停留在隐藏内容中。隐藏区域仍计入整篇文档的绘图采样点预算。

### CP-LIFE-01 实例隔离（现有）

每个 `LocalReactiveDocument` 实例创建独立的运行时和状态。同一页面可以嵌入多份相同源码，参数、计时器、标签页、表格查询和图解选择互不影响。`LocalDocumentView` 使用宿主传入的运行时；需要实例隔离时，宿主必须为每份文档分别创建运行时。标题锚点按渲染实例隔离，目录链接指向当前实例。

### CP-LIFE-02 源码变化（现有）

`LocalReactiveDocument` 在 `source` 变化时重新编译，并尝试在原运行时中采用新文档，保留仍符合契约的绑定状态。影响编译语义的选项变化或文档无法采用时创建新运行时；切换为独立文档时可更换 React `key`。宿主自行管理生命周期时，用 `LocalDocumentView` 传入已编译文档和运行时，并在卸载时销毁运行时。React StrictMode 下的重复挂载由延迟销毁逻辑处理，不重复释放仍在使用的运行时。

### CP-LIFE-03 销毁（现有）

`runtime.dispose()` 幂等，清理订阅、表达式缓存和重置标记；React 组件卸载时清理其计时器和事件监听。销毁后宿主应停止使用该实例；`snapshot`、`get`、`set` 等受生命周期检查的方法会抛出错误。宿主管理的运行时必须在卸载时调用 `dispose()`，并处理仍在途中的回调。

### CP-LIFE-04 SSR 与持久化范围（边界）

静态 SSR 渲染由发布前的 packed 检查覆盖。单文件导出的静态首屏水合由 Playwright Chromium 和本地 Edge 覆盖；该路径之外的通用 SSR 水合未验证。文档状态只存在于当前实例内存中，没有 localStorage、Cookie、服务端写入或跨实例共享。持久化原始 `.reactive.md` 源码；公开参数还可以导出为经过校验的 `reactive-md-state/v1` 文件。不要持久化 `LocalDocument`、`LocalNode`、`node.id`、`LocalSnapshot` 或内部运行时键，它们跨版本不保证结构。

## 8. 安全与资源预算

### CP-SEC-01 不可信文档（现有）

渲染器和求值器把文档内容视为不可信输入：

- 不执行作者脚本。公式 HTML 仅来自按固定选项配置的 KaTeX 渲染器；作者源码与错误消息均作为文本处理。
- 表达式使用自己的解析器和 AST 求值器，不使用 `eval`、`new Function`，不支持赋值、方法调用、属性访问、原型路径或导入。
- LaTeX 由 KaTeX 排版，输出 HTML、用于辅助技术的 MathML 以及随包提供的字体。输入、宏展开和输出尺寸受限；作者自定义宏、文件、网络和 HTML 入口关闭。绘图求值保留独立的受预算限制解析器。
- 表达式、模板、表格和图表不会发起网络请求。

### CP-SEC-02 URL 与网络（现有）

图片默认全部拒绝，包括相对路径；只有宿主 `urlPolicy` 返回 `true` 时才加载。带协议的图片只允许 `http:` 和 `https:`；危险协议即使策略放行也拒绝。链接默认允许相对地址和 `http:`、`https:`、`mailto:`、`tel:`；外部 HTTP 链接以新标签打开并带 `noopener noreferrer`。策略抛异常时拒绝该地址。

`urlPolicy` 是 URL 允许列表，不是服务端授权或沙箱。宿主仍需配置 CSP、网络出口、图片代理或沙箱 iframe。

### CP-SEC-03 资源预算（现有）

| 限制 | 值 |
| --- | --- |
| 单份文档源码 | 1,000,000 字符 |
| 解析期间累计创建的语法节点 | 默认 10,000，可由宿主按次配置 |
| 单个字符串值、属性或模板 | 100,000 字符 |
| 单个数组 | 10,000 项 |
| 数组内字符串总长度 | 100,000 字符 |
| 邮箱地址 | 254 字符，线性校验 |
| 诊断数量 | 100 条 |
| 单条诊断文本 | 2,000 字符 |
| 每个绘图组块的曲线数 | 16 |
| 整篇文档请求的曲线采样点 | 20,000 |
| 绘图共享计算步数 | 2,000,000 |
| 每份文档的校验规则 | 100 条，包含隐藏区域 |
| 每张 `<data-table>` 声明的生成行 | 最多 1,000；默认 100 |
| 每张 `<data-table>` 的列数 | 20 |
| 整份文档的生成行预算 | 2,000 |
| 整份文档的生成单元格预算 | 10,000 |
| 生成表格文字 | 每张表 100,000 个 UTF-16 代码单元 |

表中的“字符”均指 UTF-16 代码单元；文本控件的 `min-length` / `max-length` 与字符串 `len()` 按 Unicode 码点计数。超限写入被拒绝，运行时保持上一次合法状态；编译期超限返回诊断。表达式和数学计算另有长度、节点、深度和记号预算，完整单位与累计范围见[诊断与计数规则](../reference/diagnostics-counting-ch.md)。隐藏区域仍计入绘图预算。宿主仍需控制请求大小、并发与超时。

### CP-SEC-04 宿主责任（现有）

宿主决定谁可以编写、提交和分享文档；限制不可信作者的请求大小、并发和执行时间；配置 `urlPolicy`、CSP 和网络出口；在服务端重新校验表单值、权限和业务约束；在静态渲染不可信文档前评估渲染进程的资源上限。

### CP-SEC-05 扩展信任边界（边界）

本语言不为可信宿主扩展代码提供沙箱。若宿主自行注册或包装组块，安全边界由宿主负责，不能把作者文档中的 `disabled`、条件显示或客户端状态当作权限控制。`hostComponents` 选项只为单次编译登记纯 schema 数据，不携带可执行代码。SDK 同样将数据 manifest 与宿主显式导入的实现分开；宿主 renderer 和 SDK 实现都由宿主管理代码权限。

## 9. 核心与渲染器分离

### CP-CORE-01 入口分离（现有）

`reactive-md` 核心入口提供 `compileLocal`、`createLocalRuntime`、表达式、LaTeX 和版本常量，不依赖 React，可在 Node 中运行。`reactive-md/react` 提供 `LocalReactiveDocument` 和 `LocalDocumentView`，要求 React 19。样式通过独立的 `reactive-md/styles.css` 引入。

### CP-CORE-02 权威分层（现有）

- 声明表和编译器决定哪些标签、属性、结构和初值合法。
- 运行时决定写入是否被接受、共享值是否原子提交。
- 渲染器负责呈现和收集用户输入，不重新解释被编译器拒绝的源码，也不创建编译器未登记的公开绑定。
- 核心和参考渲染器对同一文档给出相同的绑定语义和状态结果。

### CP-CORE-03 HTML 不是跨实现协议（边界）

机器验收中的 SSR HTML、类名和 DOM 结构是 React 参考适配器的证据，不是跨实现的 HTML 字节协议。跨实现兼容以绑定、状态、诊断码和文本结果为准；视觉呈现由各实现自行负责，但必须满足可访问性和窄屏要求。

### CP-CORE-04 新增组块的实现面（要求）

新增组块必须检查以下接入点，按其行为修改对应实现；复用现有通用校验时，应在提案中说明：

1. 公开 manifest 的 `form`；解析器从实例配置读取形态。
2. 组件定义与实例注册；默认组件定义位于 `src/presets/default-components.ts`，`src/local/configuration/schema.ts` 是其兼容投影。
3. manifest 的属性、结构、绑定、初值与规则；编译器统一执行声明。
4. 通用内核原语的写入约束（若现有公开规则无法表达新的值或状态）。
5. 通过公开 React SDK 注册的实现；默认实现位于 `src/components/`。
6. `src/local/configuration/limits.ts` 的预算（若引入新的计算或集合）。
7. 样式、测试、示例、语法文档、集成文档和验收数据。

使用现有公开规则的组件只需定义、实现和注册。新增内核原语时，同时补充其公开契约与验收用例。

### CP-CORE-05 扩展接口边界（边界）

本修订描述组件贡献要求和第 14 节的旧宿主接口。`LOCAL_COMPONENTS` 是默认预设的内部兼容投影；`hostComponents` 为单次编译接受纯 schema 数据，并作为输入适配到统一内核，组件实现由宿主提供。

[扩展 SDK](../integration/extension-sdk-ch.md)随 `reactive-md@0.7.0` 发布，使用独立的 `reactive-md-component/v1` 数据契约和实例级配置，提供注册校验、React 实现绑定、编辑器目录、离线构建、版本恢复和公开合规工具。46 个默认渲染与结构组件采用同一公开契约。组件代码由宿主主动安装，文档声明不会装载代码。

## 10. 兼容、名称治理、修订和迁移

### CP-COMPAT-01 变更分类（要求）

| 类别 | 例子 | 处理 |
| --- | --- | --- |
| 能力新增 | 新组块；现有组块的新可选属性且默认保持已有合法写法的行为 | 作者可见的语法新增仍建立新语法修订、提升包次版本，并补充验收与迁移说明 |
| 破坏性变更 | 删除或重命名组块；改变形态、必需属性、默认值、结构规则或绑定 family；改变初值规则；降低既有预算；改变现有文档的编译结果或公开值 | 需要新语法修订，写迁移说明和旧/新示例 |
| 实现或编辑性变更 | 调整诊断 message、内部类名、DOM 结构、`node.id` 或性能实现，同时保持既有语义、可访问性和资源边界 | 通常不提升语法或协议修订；公开 API 变化另按兼容规则处理 |

新增标签会让旧实现中惰性显示的同名区域开始执行，因此不能承诺所有旧源码保持原行为。迁移说明必须交代该变化。新增或调整诊断码也会改变机器数据的 `codes`，需要同步验收与变更记录；诊断码的跨版本承诺继续遵守兼容说明。

### CP-COMPAT-02 语法修订（现有）

作者可见的语法变化会建立新的语法修订，例如 `local-draft-3`，同时提升包次版本并更新 `LOCAL_SYNTAX_VERSION`。项目不自动改写源码；升级后由作者或宿主按变更记录迁移。一个包版本只接受一个语法修订。

### CP-COMPAT-03 协议修订（要求）

以下变化提升协议修订，例如从 `component-protocol-2` 到 `component-protocol-3`：

- 修改 MUST 或 MUST NOT 条款。
- 新增必填的组块声明信息或验收门槛。
- 改变机器验收数据的根字段、必填字段或比对语义。
- 改变兼容分类规则或名称治理规则。

编辑性变更不提升协议修订。协议修订可以独立于语法修订发布，但必须在文档中写明适用语法和包版本。

### CP-COMPAT-04 名称治理（要求）

- 新名称必须是小写 kebab-case，语义明确，避免与现有 49 个名称冲突。
- 不使用 `script`、`style`、`div`、`span`、`a` 等 HTML 名称，也不使用 `on-*`、`class`、`style` 作为作者属性。
- 在 `component-protocol-1` 内，现有 48 个名称保留给现有语义；复用名称表示破坏性变更。
- 不提供隐式别名。别名需要单独名称、文档和验收证据。
- 结构子项的名称和父级约束一并治理，不能只改父组块。

### CP-COMPAT-05 迁移（要求）

- 已符合本协议的组块在协议修订后保持原有语义；新增 MUST 默认适用于新增或修改的组块。
- 若新要求追溯适用于现有组块，必须按破坏性变更处理，提供迁移说明、旧/新行为对比和验收更新。
- 破坏性变更不得在没有新语法修订的情况下悄悄改变作者写法。
- 迁移说明面向使用者和贡献者，至少包括旧写法、新写法、受影响范围和验证方式。

### CP-COMPAT-06 可持久化内容（现有）

只持久化原始 `.reactive.md` 源码和所用语法修订。`LocalDocument`、`LocalNode`、`node.id`、`initialState`、`LocalSnapshot` 和运行时参数状态都是当前运行时对象，跨版本不保证结构或字段含义。诊断的行号、列号和偏移量用于定位当前源码，不是持久化标识。

## 11. 验收矩阵

### CP-ACCEPT-01 验收面（要求）

| 验收面 | 证据 | 通过条件 | 相关条款 |
| --- | --- | --- | --- |
| 标签形态与结构 | 解析器/编译器测试，机器用例 | 合法文档通过；错配、缺子项、错误父级失败 | CP-SYNTAX-01 至 08 |
| 属性与表达式 | 编译器测试，机器用例 | 静态/动态、类型、空插值、未知属性按条款诊断 | CP-SYNTAX-03、04 |
| 绑定与初值 | 运行时测试，机器用例 | 共享约束、默认值、显式初值校验一致 | CP-STATE-01 至 05 |
| 写入与原子性 | 运行时测试，机器用例 | 拒绝时状态不变；接受时一次提交；共享控件一致 | CP-STATE-06 |
| 草稿与重置 | 渲染器/运行时测试，机器用例 | 草稿不进入公开值；重置一次提交并恢复子树 | CP-STATE-07、08 |
| 可见性与生命周期 | 运行时/渲染器测试，机器用例 | 隐藏保留状态；计时暂停；实例隔离；销毁清理 | CP-VIS-01、02，CP-LIFE-01 至 03 |
| 降级与错误隔离 | 编译器/渲染器测试，机器用例 | 未知完整标签惰性降级；局部错误不影响其他内容 | CP-DIAG-02 至 05 |
| 可视化 | 渲染器测试，机器用例，人工检查 | plot/chart/table/diagram/timeline 的语义和预算正确 | CP-STATE-12，CP-SEC-03 |
| 可访问性 | 人工浏览器检查，部分自动检查 | 名称、角色、状态、键盘、焦点和 375px 可用 | CP-A11Y-01 至 03 |
| 安全与预算 | 安全测试、预算测试、机器用例 | 无脚本/网络入口；超限拒绝且保留合法状态 | CP-SEC-01 至 04 |
| 核心与渲染器分离 | 构建、包检查、Node 消费测试 | 核心不依赖 React；React 入口可独立安装 | CP-CORE-01、02 |
| 文档与链接 | `npm run test:docs` | 相对链接和标题锚点有效 | CP-SCOPE-02 |
| 机器数据格式 | 验收运行器 | 根字段、唯一 id、必填字段、精确 codes 校验通过 | CP-ACCEPT-02 |

### CP-ACCEPT-02 机器验收数据（要求）

机器验收集的根对象只包含 `protocolVersion`、`syntaxVersion` 和非空 `cases`。冻结的作者组块集 `examples/conformance/component-protocol-1.json` 仍为 `component-protocol-1` / `local-draft-2`；当前可移植语法集为 `examples/conformance/local-draft-3.json`。两者都按各自声明的修订校验。

每个 case 至少包含唯一字符串 `id`、组块名 `component`、源码 `source`、布尔 `ok` 和去重诊断码集合 `codes`。可选字段 `initial`、`bindingNames`、`actions`、`reset`、`text`、`expectedText`、`htmlIncludes`、`htmlExcludes` 按[语言验收数据说明](../../examples/conformance/README.md)和仓库附带的 JSON Schema 使用。完整格式以该说明和 Schema 为准，本协议只规定语义门槛。

运行器必须：

- 精确检查 `protocolVersion` 和 `syntaxVersion`。
- 校验唯一 id、必填字段和 `codes` 为无重复字符串集合；无效数据直接失败，不静默跳过。
- 按顺序执行 `actions`，每步检查写入是否被接受；`reset` 在动作之后按组块名和从 0 开始的 `index` 查找已编译节点并调用 `runtime.reset`。
- 在 `actions`/`reset` 之后求值 `text` 和 `expectedText`，并在最终状态检查 SSR HTML 包含/排除项。
- 对每个运行时在 `finally` 中调用 `dispose()`。
- 失败编译的 case 只检查 `ok` 和 `codes`，不携带成功状态、动作或渲染期望。

`initial` 和 `reset.expectedState` 做部分匹配；`bindingNames` 检查完整公开绑定名集合；`text` 与 `expectedText` 必须成对。

冻结的作者组块集覆盖 `slider`、`tabs`、`plot` 的代表性用例和至少一个完整未知标签降级用例。它仍是代表性门槛，不是全部标签名的全面认证；宿主组块没有可移植机器用例。

### CP-ACCEPT-03 组件级证据（要求）

新增或修改组块必须提供与其声明规模相称的证据：

- 至少一个编译成功用例和一个失败用例，覆盖新增属性、结构或绑定约束。
- 若引入公开值，至少一个初始化和一个写入拒绝用例。
- 若引入内部状态，至少一个重置或隐藏保留用例。
- 若引入计算或集合，至少一个预算边界用例。
- 若引入可视化，至少一个渲染或 SSR 证据，并列出人工浏览器检查项。
- 若改变现有语义，提供旧/新行为对比和迁移证据。

### CP-ACCEPT-04 人工浏览器检查（要求）

涉及以下行为的组块贡献必须提供真实浏览器证据。已有自动浏览器检查可覆盖对应操作；读屏体验等尚未覆盖的项目需要人工检查。第 11.2 节的机器数据不能代替这些证据：

- 真实键盘操作、焦点顺序和焦点移出隐藏内容。
- 中文输入法组合输入和失焦校验。
- 375px 窄屏布局、横向溢出和触控目标。
- 计时器开始、暂停、恢复和切到后台后的行为。
- 读屏名称和动态状态播报。
- 深色主题、主题变量覆盖和样式隔离。

本地浏览器验证使用 Microsoft Edge（Chromium 内核）；Linux CI 使用 Playwright Chromium。Firefox、Safari/WebKit 和单文件导出之外的通用 SSR 水合未验证。

### CP-ACCEPT-05 命令门槛与豁免（要求）

协议样例门槛使用 `npm run test:components`，运行 `examples/conformance/component-protocol-1.json` 和语言 conformance；它不替代完整测试、构建、文档检查或人工浏览器检查。完整检查命令见[贡献指南](../../CONTRIBUTING-ch.md)和[组块开发指南](component-development-ch.md)。

只有 SHOULD 条款可以豁免；豁免必须在提案中记录理由、替代证据和影响范围。MUST 条款不能豁免，只能通过协议修订改变。

## 12. 当前实现映射

### CP-IMPL-01 代码位置（现有）

| 契约面 | 主要位置 | 说明 |
| --- | --- | --- |
| 标签词法与形态 | `src/local/parsing/parser.ts` | `VOID`、`PAIRED`、`INLINE`，未知标签降级，脚注屏蔽 |
| 组块声明 | `src/local/configuration/schema.ts` | 名称、形态、子项规则、属性、绑定、初值规则 |
| 编译校验 | `src/local/compilation/compiler.ts` | 结构、属性、初值、共享约束、表达式、表格和绘图预算 |
| 运行时 | `src/local/runtime/runtime.ts` | `get`、`set`、`evaluate`、`text`、`reset`、`resetToken`、`dispose` |
| React 参考适配器 | `src/local/rendering/LocalDocumentView.tsx` | 文档容器、控件、布局、可访问名称、重置和生命周期 |
| 可视化适配器 | `src/local/widgets/visuals.tsx`、`src/local/evaluation/math.ts`、`src/local/widgets/math-view.tsx` | 表格、图表、绘图、时间轴、图解和数学渲染 |
| 样式 | `src/styles.css`、`src/theme.css`、`src/base.css`、`src/local/rendering/local.css`、`src/local/widgets/visuals.css` | 全局样式表、主题变量和组件样式 |
| 预算 | `src/local/configuration/limits.ts` | 共享资源上限 |
| 版本 | `src/local/contracts/version.ts`、`package.json` | 语法修订和包版本 |
| 验收 | `tests/`、`examples/conformance/` | 语言测试和机器验收数据 |
| 文档 | `docs/`、`README.md`、`CONTRIBUTING-ch.md`、`SECURITY-ch.md` | 语法、集成、兼容、安全和贡献规则 |

### CP-IMPL-02 当前覆盖范围（现有 / 边界）

当前实现已覆盖解析、声明、编译、运行时、React 渲染、资源预算和发布检查。真实键盘、输入法、375px 和计时器暂停需要对应的浏览器自动检查或人工检查；单文件导出之外的通用 SSR 水合未验证。`component-protocol-1` 的机器数据是代表性门槛，不是全部标签名的认证。

### CP-IMPL-03 扩展接口（边界）

第 14 节保留旧 schema 与 renderer 接口；新组件使用[扩展 SDK](../integration/extension-sdk-ch.md)的 manifest、实例配置和适配器。SDK 协议、组件版本、主题协议、恢复载荷与 `local-draft-3` 语法修订分别管理。

manifest 与绑定测试使用 `reactive-md/testing`，渲染与生命周期证据分别使用 `testing/react` 和 `testing/browser`。组件仍须满足本协议的预算、可访问性与行为要求。宿主显式安装实现并负责其代码权限；SDK 校验契约和资源，不提供第三方代码沙箱。

## 13. 新组块提案模板

以下表格供评审使用。完整流程、可复制提案模板和检查命令见[组块开发指南](component-development-ch.md)。

### 13.1 基本信息

| 项目 | 填写内容 |
| --- | --- |
| 组块名 | `<name>`（小写 kebab-case） |
| 协议修订 | `component-protocol-3` |
| 用途 | 解决什么问题，读者如何使用 |
| 非目标 | 本组块不承担的能力 |
| 版本影响 | 包版本、语法修订、协议修订 |
| 名称与形态 | 名称、leaf/inline/container、父级、子项规则 |
| 语法样例 | 最小可运行源码 |
| 绑定 | 公开值类型、family、是否独占、初值规则、共享条件 |
| 子项与结构 | 允许的直接子项和结构约束 |
| 状态与重置 | 公开状态、内部状态、面板重置行为 |
| 可见性与销毁 | 条件隐藏、标签页切换、计时器和卸载行为 |
| 诊断与降级 | 结构、属性、初值和运行时错误，未知标签降级 |
| 安全与预算 | 新增输入、循环、递归、计算或集合的预算 |
| 可访问性 | 可访问名称、角色、状态、键盘和焦点 |
| 窄屏与样式 | 375px 行为、主题变量、样式文件和截图 |
| 兼容分类 | 能力新增、破坏性变更或实现/编辑性变更 |
| 迁移 | 旧写法、新写法、受影响范围和验证方式 |
| 验收证据 | 自动测试、机器数据、SSR/人工检查 |
| 变更文件 | 解析器、声明表、编译器、运行时、渲染器、样式、测试、文档 |
| 条款核对 | 逐条列出适用的 CP-* 条款和证据 |

### 13.2 属性表

| 属性 | 类型 | 静态/动态 | 必填 | 默认 | 约束 | 失败诊断 |
| --- | --- | --- | --- | --- | --- | --- |
| `name` | string/number/boolean/enum | 静态/动态 | 是/否 | 值 | 范围、枚举、长度 | 预期 code |
| ... | | | | | | |

### 13.3 绑定表

| 公开值 | family | 独占 | 初值规则 | 共享条件 | 重置行为 |
| --- | --- | --- | --- | --- | --- |
| `bindName` | text/number/boolean/date/choice/timer/checklist/tabs/diagram | 是/否 | 规则 | 同 family、范围/步长/选项一致 | 恢复初值并触发 reset token |

### 13.4 条款核对

| 条款 | 证据 | 结论 |
| --- | --- | --- |
| CP-SYNTAX-01 至 08 | 解析/编译测试、语法文档 | 通过/待补 |
| CP-STATE-01 至 09 | 运行时测试、机器数据 | 通过/待补 |
| CP-DIAG-01 至 05 | 失败用例、降级用例 | 通过/待补 |
| CP-A11Y-01 至 03 | 人工浏览器记录 | 通过/待补 |
| CP-STYLE-01 至 03 | 样式文件、窄屏截图 | 通过/待补 |
| CP-VIS-01、02，CP-LIFE-01 至 03 | 隐藏/重置/销毁用例 | 通过/待补 |
| CP-SEC-01 至 04 | 安全测试、预算用例 | 通过/待补 |
| CP-CORE-01、02、04 | 构建、Node 消费、渲染测试 | 通过/待补 |
| CP-COMPAT-01 至 05 | 兼容说明、迁移示例 | 通过/待补 |
| CP-ACCEPT-01 至 05 | 验收矩阵和命令结果 | 通过/待补 |

## 14. 宿主组件扩展轴

### CP-HOST-01 宿主组件是可选扩展（现有）

`compileLocal(source, { hostComponents })` 为编译器增加一条宿主拥有的扩展轴。不传 `hostComponents` 时，作者行为不变：49 个作者标签名照常解析，集合之外的标签仍是未知标签，并按 CP-DIAG-03 降级为原文。该选项只改变本次调用识别的标签名，不增加作者语法。协议修订为 `component-protocol-3`。

### CP-HOST-02 宿主 Schema 是普通数据（要求）

`LocalHostComponentSchema` 是宿主提供的普通、可结构化克隆的数据，不含函数、类实例或运行时句柄。

| 字段 | 内容 |
| --- | --- |
| `name` | 小写 kebab-case，在集合内唯一，不能是 49 个作者标签名、P0 HTML 标签名或主题声明名 `theme` |
| `form` | `'leaf'`、`'inline'` 或 `'container'`；inline 与 container 的正文按普通 Markdown 编译，可包含组件 |
| `props` | 宿主属性表；属性名使用小写 kebab-case |

每次编译最多接受 32 个宿主组块 Schema。每个属性声明 `kind`（`string`、`number`、`boolean` 或 `enum`）、`required`、`static`、`enum` 和 `pattern`。`enum` 用于 `enum` 属性，`pattern` 用于 `string` 属性。P0 HTML 标签名保留给解析器优先处理的 HTML，不得复用。`pattern` 限制在线性时间安全子集内：拒绝反向引用、环视、命名组、嵌套量词和被量词修饰的分支。非法 Schema 以 `local.options.invalid` 诊断拒绝；编译失败，该集合不会部分生效。

### CP-HOST-03 宿主组块不是作者语法（边界）

宿主组块不属于作者语法修订，不能当作可移植的作者语法。使用它们的文档只有在登记了相同名称和兼容 Schema 的宿主中才能渲染；普通读者会把每个名称当作未知组块，按 CP-DIAG-03 的既有降级处理。作者不能假定宿主组块一定存在，面向可移植的文档不应使用它们。

### CP-HOST-04 属性校验与预算（要求）

编译器按登记的 Schema 校验每个宿主属性：必填属性必须存在，`enum` 值必须属于声明的集合，`pattern` 必须匹配字面字符串值，字面值必须符合声明的 `kind`，声明为 `static` 的属性拒绝 `{{ ... }}`。声明了 `pattern` 的属性，非静态值只能用恰好一个完整插值代替字面值；混合字面文本与插值会被拒绝。其他字符串属性可以混合字面文本和插值。校验失败在属性位置产生 `local.host.attribute` 诊断。

合法宿主节点在既有语法节点预算中只计为一个语法节点；属性、props 和 leaf 形态不增加更多节点，也不改变其他预算的计算。

### CP-HOST-05 React 分发与宿主数据（要求）

React 视图把 `hostComponent` 节点分发给 `hostRenderer(node, data, ctx)`。`data` 从 `hostData` 读取，后者是 JSON 安全的宿主数据，按节点属性中的 `${kind}:${ref}` 索引。这两个 props 都留在宿主/React 一侧：渲染函数不进入 worker，`hostData` 也不进入 worker，因为编译只需要 Schema。

缺少渲染器、缺少 `${kind}:${ref}` 键或渲染器抛出异常时，显示可见的诊断占位，不得让异常冒出文档或使其余内容变空白。`mode === 'static'` 走同一分发路径，因此宿主未提供渲染器或数据时，静态渲染显示相同的占位。

可移植的机器用例仍是 `examples/conformance/component-protocol-1.json`，它作为作者组块的基线保持冻结；当前语法用例位于 `examples/conformance/local-draft-3.json`。宿主组块不提供可移植验收用例，因为渲染由宿主拥有，普通读者只能看到未知组块降级。

## 15. 修订记录

| 修订 | 日期 | 说明 |
| --- | --- | --- |
| `component-protocol-3` | 2026-10-29 | 宿主组件新增 inline/container 形态和标量绑定；`local-draft-3` 增加 `<external>` 和动态约束。 |
| `component-protocol-2` | 2026-10-25 | 新增宿主组件扩展轴；作者语法仍为 `local-draft-2`。 |
| `component-protocol-1` | 2026-10-23 | 初版；最初适用于 `local-draft-1` 和包版本 `0.3.0`，定义组块贡献、验收和扩展边界。现在适用于 `local-draft-2` 和 `0.4.0` 预览版，MUST 条款和机器格式不变。 |


新增组块、颜色、槽位状态与迁移规则见[local-draft-2 扩展说明](../reference/local-components-v2-ch.md)，升级清单见[0.4.0 发布与迁移](../releases/release-0.4.0-ch.md)。`0.6.0` 同时提供于 `latest` 与 `next` 渠道。
