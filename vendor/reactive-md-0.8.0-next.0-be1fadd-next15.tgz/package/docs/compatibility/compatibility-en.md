# Versions and compatibility

**English** · [中文](compatibility-ch.md)

Reactive MD is currently a 0.x preview. This page covers package versions, syntax versions, what can be persisted, the diagnostics contract and the current platform scope. See [Source revisions and migration](source-versioning-en.md) for explicit revision declarations, the migration API and `reactive-md migrate`, [Local mode integration](../integration/local-integration-en.md) for the public API and style integration, the [0.7.0 release notes](../releases/release-0.7.0-en.md) for the current release, and [0.4.0 release and migration](../releases/release-0.4.0-en.md) for that minor series.

## Version mapping

| Item | Current value | Notes |
| --- | --- | --- |
| Package version | `0.7.0` | 0.x preview; 0.7.0 is available on both `latest` and `next` |
| Distribution tags | `latest` → `0.7.0`; `next` → `0.7.0` | Default installs use `latest` |
| Syntax version | `local-draft-3` | `LOCAL_SYNTAX_VERSION`; this revision is the only one accepted by the package |
| Source revision directive | Optional `<!-- reactive-md: local-draft-3 -->` | One line in the document prologue; unversioned source keeps current-revision behavior |
| Component protocol | `component-protocol-3` | Contribution and acceptance contract, see [Component protocol](../development/component-protocol-en.md); not a runtime version selection parameter |
| Theme protocol | `reactive-md-theme-1` | Document themes and host CSS integration |
| Authoring entry | `reactive-md/authoring` | Schema, catalog and editor helpers, without React or CSS |
| Unstyled React entry | `reactive-md/react/unstyled` | React renderer without a stylesheet dependency |
| Core entry | `reactive-md` | Compilation, expressions and runtime, without loading React |
| React entry | `reactive-md/react` | `LocalReactiveDocument`, `LocalDocumentView` |
| Editor entry | `reactive-md-editor` | `ReactiveMarkdownEditor` and its types; requires React 19 |
| Renderer style entry | `reactive-md/styles.css` | Document and component styles, explicitly imported by the host |
| Screen style entry | `reactive-md/screen.css` | Alias of `reactive-md/styles.css` |
| Print style entry | `reactive-md/print.css` | Optional document print layout and page margins |
| Editor style entry | `reactive-md-editor/styles.css` | Independent editor styles, scoped to the editor root |

One package version corresponds to exactly one syntax revision. Before upgrading the package, record the `LOCAL_SYNTAX_VERSION` your application uses. If document sources come from another syntax revision, keep rendering them with the old package version or rewrite them according to the migration notes below. `compileLocal(source, options?)` has no syntax version parameter; hosts can adjust the syntax node budget for a single compilation through `options.limits.maxSyntaxNodes`, see [Local mode integration](../integration/local-integration-en.md).

## Explicit source revisions

A source may declare its revision with one `<!-- reactive-md: local-draft-3 -->` line in the prologue. Unversioned source is read as the current revision, without a new warning. An explicit older (for example `local-draft-1` or `local-draft-2`) or unknown revision is rejected with a `local.version.*` diagnostic and no runtime is created; declaring an old revision does not select an old parser. Malformed, duplicate and misplaced directives are rejected the same way.

Readers built before this directive existed, including `0.3.1`, treat it as an ordinary comment and do not enforce the check. Migrate old documents before relying on it. `inspectLocalSourceVersion`, `checkLocalUpgrade` and `migrateLocalSource` expose the declaration outside the compiler, and `reactive-md migrate` performs the single-source metadata migration. See [Source revisions and migration](source-versioning-en.md).

## Compatibility rules for 0.x

- Minor versions (`0.3` to `0.4`) may contain breaking changes; patch versions contain only compatibility and security fixes.
- The 0.x phase does not promise a fixed deprecation period. Every breaking change is recorded in the [changelog](../../CHANGELOG.md), with the old form, new form and migration steps.
- Before 1.0, treat every upgrade as potentially requiring changes to document sources or host code.
- Applications should pin the package version, keep the original `.reactive.md` sources, and rerun compile and render checks with their own documents and examples after upgrading.

## Core semantic compatibility

Within a syntax revision, compatible package updates preserve the meaning of accepted source:

- Controls keep their public value types, initial-value rules, shared-binding constraints and validation rules. Hidden controls still initialize, and showing them again does not reset their values.
- Expressions keep strict operand types, operator precedence, short-circuit evaluation and finite-number rules. A failed local calculation does not replace a valid input or stop unrelated content.
- Invalid parameter writes leave the last valid state unchanged; multi-value writes commit atomically. Panel reset restores its own controls and component state, and dependent content updates consistently.
- Prose, formulas and visualizations read the same parameter values. Code and inert fallback regions stay literal. Source locations remain one-based with UTF-16 offsets and half-open ranges.
- Rendered content, control labels and interactions are semantic outputs. Generated node/DOM IDs, internal `@` keys, AST layout, caches, pixel layout and diagnostic wording are outside the stable source contract.

From `local-draft-1` to `local-draft-2`, this promise covers the common supported language after upgrade checks. New reserved identifiers and newly active tags require manual source changes. Text-length counting is an explicit compatibility exception that the migrator requires you to accept; completed-checklist styling is a visual exception. A semantic change outside these recorded exceptions requires a syntax revision and migration notes.

Regression data in [the historical corpus](../../examples/conformance/history/v0.3.1/provenance.json) preserves actual `v0.3.1` sources, their source commit and SHA256 digests. The regression suite checks the original conformance expectations, public values, rejected writes, initialization, resets and migration rendering. Internal IDs are excluded from comparisons.

## Breaking changes and migration

`0.5.0` added the `reactive-md-editor` entry and its independent stylesheet. `0.5.1` adds editor views, theme palettes and HTML compatibility. They keep `local-draft-2`, `component-protocol-1` and `reactive-md-theme-1`. Existing `reactive-md`, `reactive-md/react` and `reactive-md/styles.css` imports keep working, and documents written for 0.4.x need no migration. The editor requires React 19; see the [editor guide](../integration/editor-en.md) for its history and rendering boundaries.

`0.6.1` switches formula display to KaTeX with bundled WOFF2 fonts and accessible MathML. Plot evaluation and protocol revisions are unchanged. Invalid formulas fall back to bounded source text with a warning. `align` now numbers rows; use `align*` or `aligned` to omit automatic numbers. See the [0.6.1 release notes](../releases/release-0.6.1-en.md).

`0.7.0` establishes `local-draft-3` and raises the component protocol to `component-protocol-3`. `local-draft-3` adds `<external>` read-only declarations and dynamic `min`/`max`/`required` constraints; `component-protocol-3` adds host inline/container forms and scalar bindings. Explicit `local-draft-1` and `local-draft-2` declarations are rejected; use `reactive-md migrate` before upgrading, and note that migration from `local-draft-2` blocks newly active `<external>` tags. The editor uses CM6 only, removes `textareaRef` / `getTextarea`, and keeps `reactive-md-editor/codemirror` as an alias. The public extension SDK ships in this release. See the [0.7.0 release notes](../releases/release-0.7.0-en.md).

`0.6.0` adds native HTML tables, `align` and link `target`/`rel`, more math environments and commands, mhchem chemistry and expanded code highlighting, and switches diagrams to a layered layout. Unparseable native HTML now falls back to source. `compileLocal` returns only plain objects and arrays, and the editor adds `insertText`. Syntax, component and theme revisions remain unchanged, and existing imports keep working. See the [0.6.0 release notes](../releases/release-0.6.0-en.md).

`0.5.3` adds host authoring tools, consistent compile options, math fallback diagnostics and separate screen/print stylesheets. Existing entries remain available; import `reactive-md/print.css` explicitly for document print layout. Syntax, component and theme revisions remain unchanged. See the [0.5.3 release notes](../releases/release-0.5.3-en.md).

`0.5.2` adds the opt-in host component extension axis and raises the component protocol to `component-protocol-2`. The syntax revision and theme protocol remain unchanged, existing imports keep working, and documents written for 0.5.x need no migration. See the [0.5.2 release notes](../releases/release-0.5.2-en.md).

`0.4.0` adds [constraints and collections](../reference/constraints-collections-en.md): `LocalRuntime.validate()`, serializable `LocalValidation` rules, numeric arrays and generated tables. Hosts implementing a runtime adapter need the new `validate()` method; exhaustive value-kind checks need `number-array`. Rename bindings colliding with `sum`, `average`, `minOf` or `maxOf`.

`0.4.0` adds [named calculations and formatting functions](../reference/computations-formatting-en.md). `computed`/`const` use the existing local tag syntax. The new built-in function names become reserved; rename colliding input bindings and their references before using this release. `document.bindings` and `initialState` still contain writable controls; snapshots also expose successful calculated values.

`0.4.0` establishes `local-draft-2`. Unversioned source that uses supported `local-draft-1` forms remains valid; an explicit `local-draft-1` declaration is rejected until migrated. The build now recognizes 15 additional tag names: the ten `local-draft-2` components plus `computed`, `const`, `validation`, `data-table` and `column`. Text that previously displayed as an unknown or literal tag now parses as a component or declaration; move literal examples into code spans or fences. The leading `<theme>` declaration is document metadata and is not counted as a component. See [0.4.0 release and migration](../releases/release-0.4.0-en.md) for the complete rename and upgrade checklist.

Author-visible syntax changes establish a new syntax revision, such as `local-draft-3`, and raise the minor version and update `LOCAL_SYNTAX_VERSION`. Changes to the core or React API are also recorded in the changelog. The project does not rewrite document bodies automatically. `reactive-md migrate` moves one source's metadata declaration and blocks body-level conflicts; after upgrading, authors or hosts complete any remaining source changes according to the record.

Legacy configuration syntax is not part of `local-draft-3`. Common replacements:

| Old form | What to do in `local-draft-3` |
| --- | --- |
| Directives such as `:::card`, `:::row` | Tags such as `<card>`, `<grid>` |
| YAML `state:` declaring parameters | `bind` and `initial` on controls |
| YAML `computed:` | `{{ expression }}` in the prose |
| `actions:`, button actions, `on-*` events | No equivalent entry point; use component built-in interactions and panel reset |
| `data:` or external API data | Markdown tables written directly in the prose; parameters are declared by controls |
| Persisted runtime state | The host saves the original source. Public parameters may additionally be exported as a validated `reactive-md-state/v1` file; it is tied to the source digest, syntax revision and exact public parameter set and is not a document format. |

## What to persist

Persist the original `.reactive.md` source. A `reactive-md-state/v1` file may preserve public parameter values for the same source and syntax revision; it is rejected when the digest, revision or parameter set differs. Migration changes the source digest, so export a fresh state file after migrating; migration never rewrites state files. Do not persist `LocalDocument`, `LocalNode`, `node.id`, `initialState`, `LocalSnapshot` or internal `@` runtime keys: they belong to the current runtime object and their structure and field meanings are not guaranteed across versions. `node.id` is regenerated when the source changes. Diagnostic line numbers, columns and offsets locate the current source and are not stable persistence identifiers.

## Diagnostics contract

`Diagnostic` contains `code`, `message`, `severity`, `range`, `line` and `column`.

- Lines and columns are one-based. Columns and half-open ranges count UTF-16 code units in the original source.
- `line`, `column` and `range` can be used for programmatic location and editor jumps.
- `code` is a string identifier, such as `local.type`, `expression-type` or `latex-plot-range`. Existing codes keep their meaning within one 0.x minor series. New codes may be added; removal, renaming or a change of meaning requires a new minor version and migration notes.
- `message` contains default English display text. Use `formatLocalDiagnostic(diagnostic, 'zh')` for Chinese. Wording may improve; do not parse messages or make business decisions based on their complete text. Language changes preserve machine fields.
- `severity` is `warning` or `error`. Structurally complete unknown tags keep their source and produce fallback warnings, and compilation can still succeed; footnotes render normally. Compile errors make `result.ok` `false` and disable the preview. Runtime local errors affect only the corresponding content.

See [Diagnostics and counting rules](../reference/diagnostics-counting-en.md) for units and resource-budget scopes.

## Platforms and runtimes

| Environment | Current status |
| --- | --- |
| Node.js 22.12+ | Minimum for development and Node-side consumption; CI targets both 22.12 and 24 |
| ESM | The only module format; no CommonJS entry |
| React 19 | Required by `reactive-md/react` and `reactive-md-editor`; the core entry does not depend on React |
| Microsoft Edge (Chromium-based) | Local browser verification has used Edge |
| Playwright Chromium | Full Linux CI browser suite |
| Playwright Firefox and WebKit | Core workflows at 1280px and 375px, including personal documents and interactive HTML export; included in the browser release gate and CI |
| Safari on Apple devices | Device testing remains separate from Playwright WebKit engine checks |
| Shareable state format | `reactive-md-state/v1`: public parameter values with a syntax version and source digest; see [Shareable documents](../integration/shareable-export-en.md) |
| Single-file HTML format | `reactive-md-html/v1`: interactive or static export, with an inline standalone runtime only in interactive mode |
| SSR | `react-dom/server` static rendering is covered by the packed check. The editor entry has no top-level DOM access and can be imported and rendered on the server; editing interactions run on the client. Static-first hydration of the single-file export is covered in Playwright Chromium/Edge; general SSR hydration is unverified and should be checked before use |

Node-side consumption means importing `reactive-md` in Node and calling `compileLocal` and `createLocalRuntime` without a DOM. React rendering requires a browser environment, or the host must handle server output itself.

See the [syntax specification](../reference/local-interaction-syntax-en.md) for the language scope, and the [security policy](../../SECURITY.md) for the security boundary and host responsibilities.


See [local-draft-2 components and migration](../reference/local-components-v2-en.md) for new tags, colors and slot state, and [0.4.0 release and migration](../releases/release-0.4.0-en.md) for the upgrade checklist. 0.7.0 is available on both `latest` and `next`.
