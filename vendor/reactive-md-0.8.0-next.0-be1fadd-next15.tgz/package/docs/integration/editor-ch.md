# React 源码编辑器

**中文** · [English](editor-en.md)

`0.7.0` 已将 `reactive-md-editor` 统一为 CodeMirror 6 编辑器，并删除旧 textarea 源码编辑器。CM6 的事务、共享分析和坐标约定见 [CM6 集成](codemirror-ch.md)。

`reactive-md-editor` 是用于 Reactive MD 源码的受控 React 19 编辑器，由 Playground 编辑器抽出。它提供源码高亮、格式与插入工具栏、补全、绑定导航、重命名与格式化、撤销重做、行号及滚动同步。编辑器内置字数底栏及编辑、并排、预览三种视图。宿主保存源码，并提供预览内容、持久化和导出。

编辑器有独立样式表 `reactive-md-editor/styles.css`，与 `reactive-md/styles.css` 分开。只编辑源码的页面不会加载文档渲染样式。

编辑器属于 `0.6.0`，同时提供于 `latest` 与 `next` 渠道。现有 `reactive-md`、`reactive-md/react` 和 `reactive-md/styles.css` 导入保持不变。

## 安装

```sh
npm install reactive-md
npm install react@19 react-dom@19
```

需要固定版本时使用 `npm install reactive-md@0.6.0`。包只提供 ESM，工具和服务端渲染需要 Node.js 22.12 或更新版本。

## 最小受控编辑器

```tsx
import { useState } from 'react';
import { ReactiveMarkdownEditor } from 'reactive-md-editor';
import 'reactive-md-editor/styles.css';

const initialSource = `# 费用估算

<slider bind="people" label="人数" initial="2" min="1" max="20">

每月费用：**{{ people * 100 }} 元**。`;

export function SourceEditor() {
  const [source, setSource] = useState(initialSource);

  return (
    <ReactiveMarkdownEditor
      value={source}
      onChange={setSource}
      ariaLabel="文档源码"
    />
  );
}
```

`value` 和 `onChange` 为必需属性。组件使用 CM6 按视口创建源码行 DOM，并使用 CM6 原生历史；源码文本保存在宿主状态中。内置文案默认为英文。

## 入口

| 入口 | 内容 | 依赖 |
| --- | --- | --- |
| `reactive-md-editor` | `ReactiveMarkdownEditor` 及其类型 | React 19 |
| `reactive-md-editor/styles.css` | 编辑器样式，作用域限定在编辑器根节点 | 由宿主显式引入 |

样式表在应用或渲染编辑器的组件模块中引入一次即可。支持 CSS 导入的构建工具或框架可以把它放在编辑器模块旁边。

## ref 句柄

```tsx
import { useRef, useState } from 'react';
import {
  ReactiveMarkdownEditor,
  type ReactiveMarkdownEditorHandle,
} from 'reactive-md-editor';

export function SourceEditor() {
  const [source, setSource] = useState('');
  const editor = useRef<ReactiveMarkdownEditorHandle>(null);

  return (
    <>
      <button type="button" onClick={() => editor.current?.focus()}>聚焦</button>
      <button type="button" onClick={() => editor.current?.undo()}>撤销</button>
      <button type="button" onClick={() => editor.current?.selectRange({ start: 0, end: 5 })}>
        选中标题
      </button>
      <ReactiveMarkdownEditor ref={editor} value={source} onChange={setSource} />
    </>
  );
}
```

| 方法 | 行为 |
| --- | --- |
| `focus(selection?)` | 聚焦源码编辑区，可同时应用选区。 |
| `selectRange(range)` | 选中一段源码。区间与编译诊断一样使用 UTF-16 半开区间偏移。 |
| `insertText(text)` | 用文本替换当前选区，记录为一次可撤销编辑，并将光标放到插入内容之后。只读或禁用时不执行。 |
| `getSelection()` | 返回当前选区。 |
| `getSource()` | 返回完整原始源码，包含视口外文本。 |
| `getEditorElement()` | 返回可编辑 DOM 元素；挂载前为 `null`。 |
| `getVisibleRanges()` | 返回当前可见源码区间。 |
| `undo()` / `redo()` | 在该实例的历史中前后移动，并通过 `onChange` 发出结果值。到达历史两端或 `readOnly`、`disabled` 时不执行操作。 |

入口同时导出 `ReactiveMarkdownEditorProps`、`ReactiveMarkdownEditorHandle`、`EditorLocale`、`EditorTheme` 和 `EditorSelection` 类型。

## 属性

| 属性 | 类型 | 默认值 | 说明 |
| --- | --- | --- | --- |
| `value` | `string` | 必需 | 受控源码文本。 |
| `onChange` | `(value: string) => void` | 必需 | 接收输入、工具栏命令及撤销重做后的新源码。 |
| `locale` | `'en' \| 'zh'` | `'en'` | 该实例的内置文案语言，不改变源码内容。 |
| `theme` | `'light' \| 'dark' \| 'auto'` | `'auto'` | 在编辑器根节点设置 `data-editor-theme`。`auto` 跟随系统偏好。 |
| `preview` | `ReactNode` | 无 | 在编辑器内部渲染的预览内容。提供后启用底栏三种视图切换。 |
| `viewMode` | `EditorViewMode` | 无 | 受控视图：`'edit'`、`'split'` 或 `'preview'`。 |
| `defaultViewMode` | `EditorViewMode` | `'edit'` | 非受控视图的初始模式。 |
| `onViewModeChange` | `(mode: EditorViewMode) => void` | 无 | 用户点击底栏视图按钮时调用。 |
| `id` | `string` | 自动生成 | 源码可编辑元素的 id。 |
| `className` | `string` | 无 | 加到 `.reactive-md-editor` 根节点。 |
| `style` | `CSSProperties` | 无 | 根节点的内联样式。 |
| `height` | `number \| string` | `560` | 数字按像素计算，字符串可使用任意 CSS 长度。 |
| `minHeight` | `number \| string` | `280` | 最小高度，单位规则与 `height` 相同。 |
| `placeholder` | `string` | 无 | 源码为空时的占位提示。 |
| `ariaLabel` | `string` | 本地化标签 | 源码编辑区的可访问名称。 |
| `readOnly` | `boolean` | `false` | 文本仍可选中和复制，但不能修改。 |
| `disabled` | `boolean` | `false` | 阻止聚焦和编辑。 |
| `documentKey` | `string \| number` | 无 | 切换到独立源码文档时修改该值。变化会重置撤销历史与选区。 |
| `diagnostics` | `readonly Diagnostic[]` | 无 | 在行号栏标记诊断所在行，不阻止输入，也不代替宿主校验。 |
| `document` | `LocalDocument \| null` | `null` | 已编译文档，用于作者工具显示绑定值类型。编辑器不会编译它。 |
| `toolbar` | `boolean` | `true` | 显示格式与插入工具栏，包括导出操作。 |
| `authoring` | `boolean` | `true` | 启用补全、绑定导航、重命名和格式化工具。 |
| `onExport` | `() => void` | 无 | 工具栏导出操作调用该回调，用于打开宿主导出对话框或自行写文件。 |
| `analysis` | `EditorAuthorAnalysis \| null` | 无 | 省略时使用私有分析 Worker；`null` 表示等待宿主共享分析。 |
| `onTransaction` | `(transaction: EditorTransaction) => void` | 无 | 接收原始源码坐标下的编辑事务。 |
| `createAnalysisWorker` | `() => Worker` | 无 | 提供符合宿主 CSP 的分析 Worker 工厂。 |

## 编辑器内置视图

底栏位于编辑器边框内，紧贴编辑区域下缘，显示 Unicode 字符数和视图按钮。提供 `preview` 后，编辑器管理编辑、并排和预览布局。容器宽度不超过 600px 时，仅显示编辑和预览选项；并排模式暂时显示为编辑模式，恢复宽屏后回到并排。

```tsx
<ReactiveMarkdownEditor
  value={source}
  onChange={setSource}
  preview={<LocalDocumentView document={compiledDocument} />}
  defaultViewMode="split"
/>
```

切换视图会保留源码选区、撤销历史及预览组件的状态。需要从外部控制视图时，同时传入 `viewMode` 和 `onViewModeChange`。只编辑源码时可省略 `preview`，底栏保留字符数及键盘提示。在源码中按 Esc，再按 Tab 可聚焦工具栏。

## 预览定位源码

`LocalDocumentView` 与 `LocalReactiveDocument` 接受 `onSourceNavigate`。提供回调后，渲染出的段落、标题、插值、公式、控件标签和图表框会携带源码元数据，普通点击会报告目标：

```tsx
<LocalDocumentView
  document={document}
  runtime={runtime}
  onSourceNavigate={(target) => {
    editor.current?.selectRange(target.range);
    editor.current?.focus();
  }}
/>
```

`target` 包含 `range`（UTF-16 半开区间）、`nodeId`、`nodeType`，组件还包含 `componentName`。输入框、按钮、链接和表格控件等交互后代会被忽略，因此拖动滑块或点击表头排序不会误触跳转；点击控件标签才会定位到其标签源码。定位不会增加 Tab 停靠点；隐藏内容不渲染，原生 HTML iframe 内容没有可靠映射。

省略回调时 DOM 与静态导出保持原样。容器宽度不超过 600px 时编辑器可能只显示编辑和预览；定位预览目标前先切换到并排视图，确保选区可见。`selectRange` 只聚焦源码，不会产生编辑或撤销步骤。

## 受控值与历史

每次编辑都会以新源码调用 `onChange`，包括输入、工具栏格式化、插入模板、重命名、格式化及撤销重做。把该值回传给 `value`。编辑器把自己发出的修改视为当前会话的一部分，常规受控值回传会保留撤销步骤。

外部修改 `value` 会更新显示的文本。宿主用另一份独立文档替换文本时，在同一次渲染中修改 `documentKey`。键变化会清空撤销重做、重置选区并采用新值。

```tsx
const [documentKey, setDocumentKey] = useState('estimate');
const [source, setSource] = useState(loadSource('estimate'));

function openDocument(key: string, text: string) {
  setDocumentKey(key);
  setSource(text);
}

<ReactiveMarkdownEditor
  value={source}
  onChange={setSource}
  documentKey={documentKey}
/>
```

撤销历史属于当前挂载实例，不保存、不跨实例共享，也不从整个 `value` 属性推导。切换文档时修改 `documentKey`，不要在每次输入时重新挂载组件。

## 语言与主题

每个实例使用自己的语言和主题。编辑器不修改文档的 `data-theme` 属性，不写入浏览器存储，也不读取 Playground 的语言设置。

```tsx
<ReactiveMarkdownEditor
  value={source}
  onChange={setSource}
  locale="zh"
  theme="dark"
/>
```

`theme="auto"` 跟随系统颜色偏好，并响应偏好变化。同一页面的两个编辑器可以使用不同设置。主题通过 `.reactive-md-editor` 根节点上的本地 `data-editor-theme` 属性设置。

## 只读与禁用

`readOnly` 保留源码显示、聚焦和选择，输入、工具栏、补全、重命名、格式化以及 ref 的 `undo`、`redo` 都不能改变值。

`disabled` 同时阻止聚焦和指针交互。两种模式均会禁用工具栏导出操作，不会自行改变值或历史。宿主不允许编辑源码时使用它们，例如展示只读预览期间。

宿主从外部替换 `value` 或改变 `documentKey` 时，编辑器重置历史、选区和滚动位置；回传 `onChange` 收到的值会保留这些状态。未提供 `onExport` 时隐藏导出按钮。

## 诊断与已编译文档

可选的作者工具会在本地分析源码并检查语法。预览文档的编译由宿主管理；需要行标记或绑定值类型时，可把该结果传入：

```tsx
import { compileLocal } from 'reactive-md';

const result = compileLocal(source);

<ReactiveMarkdownEditor
  value={source}
  onChange={setSource}
  diagnostics={result.diagnostics}
  document={result.ok ? result.document : null}
/>
```

`diagnostics` 在行号栏标记报告所在行。未完成的源码仍可继续输入，编译错误不会锁住编辑器。`document` 为作者检查面板提供绑定值类型。两个属性都可省略；只编辑 Markdown 时无需传入。

## 尺寸与布局

编辑器填满容器宽度。`height` 默认 `560px`，`minHeight` 默认 `280px`；数字按像素处理，字符串可以使用 `vh`、`rem` 等 CSS 长度。行号栏随行数变化，软换行时行号和高亮仍与滚动位置同步。

在宿主布局中使用 `className` 或 `style` 控制外边距和位置。内部元素类名属于实现细节。

## 工具栏与作者工具

`toolbar={false}` 移除格式与插入工具栏，包括导出操作。`authoring={false}` 保留 CM6 和工具栏，停用作者分析、绑定导航、重命名和格式化；基础 Markdown 高亮继续可用。两者默认启用。

工具栏处理 Markdown 格式，插入列表、表格、链接、图片和内置组块模板，并提供撤销重做。格式化命令基于当前选区，通过 `onChange` 返回新源码。

## 宿主职责

编辑器负责编辑源码，其余由宿主处理：

- 预览：编译 `value`，用 `reactive-md/react` 或自己的运行时渲染。
- 持久化：保存源码。编辑器不自动保存、不写入本地存储，也不把源码发送到任何地方。
- 导出：通过 `onExport` 把工具栏操作接到 HTML 导出、下载对话框或文件服务。编辑器不生成可分享的 HTML 文件。

编译调度和防抖同样属于宿主。见[本地模式集成](local-integration-ch.md)与[可分享文档与静态导出](shareable-export-ch.md)。包含编辑器、预览和文档切换的完整示例见 [react-editor.tsx](../../examples/integration/react-editor.tsx)。

## 服务端渲染

编辑器入口没有顶层 `window` 或 `document` 访问。服务端渲染输出编辑器外框，CM6 编辑视图在客户端挂载。聚焦、选区、补全、布局测量和工具栏菜单需要浏览器环境。

## 样式与作用域

`reactive-md-editor/styles.css` 包含编辑器自己的 token 和规则，所有选择器限定在 `.reactive-md-editor` 及其后代，不会改写宿主的按钮、输入框或页面正文。主题由上面的实例属性提供。

同一页面还渲染文档预览时，再引入 `reactive-md/styles.css`。两份样式表彼此独立，加载顺序不限。

## 兼容性

从 textarea 编辑器迁移时，移除 `textareaRef`，以 ref 的 `getSource()` 读取完整源码、`getSelection()` 读取选区、`selectRange()` 设置选区。`getEditorElement()` 提供可编辑 DOM 元素。`reactive-md-editor/codemirror` 保留为同一组件的兼容别名，共用样式和运行时代码。文档中的 `<textarea>` 表单组件继续受支持。

0.5.3 新增接受编译配置的作者工具及显式屏幕、打印样式入口，见 [0.5.3 宿主集成](../releases/release-0.5.3-ch.md)。0.6.0 为 ref 句柄新增 `insertText`，见 [0.6.0 发布说明](../releases/release-0.6.0-ch.md)。
