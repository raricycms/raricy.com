// src/local/configuration/limits.ts
var e = 1e6, t = 1e4, n = 2e7, r = 1e3, i = 1e5, a = 1e4, o = 1e5, s = 2e3, c = 16, l = 2e4, u = 2e6, d = 1e3, f = 100, p = 20, m = 2e3, h = 1e4;
function g(e) {
	if (e.length > 254 || /\s/.test(e)) return !1;
	let t = e.indexOf("@");
	if (t < 1 || t !== e.lastIndexOf("@")) return !1;
	let n = e.lastIndexOf(".");
	return n > t + 1 && n < e.length - 1;
}
// src/sdk/hash.ts
function _(e) {
	let t = 2166136261, n = 16777619;
	for (let r = 0; r < e.length; r += 1) {
		let i = e.charCodeAt(r);
		t ^= i, t = Math.imul(t, 16777619) >>> 0, n ^= i + r, n = Math.imul(n, 2246822507) >>> 0;
	}
	let r = e.length;
	return t ^= r, t = Math.imul(t, 16777619) >>> 0, n ^= r, n = Math.imul(n, 3266489909) >>> 0, `rmd-${t.toString(16).padStart(8, "0")}${n.toString(16).padStart(8, "0")}`;
}
// src/sdk/pattern.ts
function v(e, t) {
	let n = e[t];
	if (n === "*" || n === "+" || n === "?") return { length: e[t + 1] === "?" ? 2 : 1 };
	if (n !== "{") return null;
	let r = /^\{(\d+)(?:,(\d*))?\}/.exec(e.slice(t));
	return r ? { length: r[0].length + +(e[t + r[0].length] === "?") } : null;
}
function y(e) {
	let t = [], n = !1, r = !1;
	for (let i = 0; i < e.length; i += 1) {
		let a = e[i];
		if (n) {
			n = !1;
			continue;
		}
		if (a === "\\") {
			let t = e[i + 1];
			if (t !== void 0 && t >= "1" && t <= "9" || t === "k" && e[i + 2] === "<") return !1;
			n = !0;
			continue;
		}
		if (r) {
			a === "]" && (r = !1);
			continue;
		}
		if (a === "[") {
			r = !0;
			continue;
		}
		if (a === "(") {
			if (e[i + 1] === "?") {
				if (e[i + 2] !== ":") return !1;
				t.push({
					quantified: !1,
					alternation: !1
				}), i += 2;
				continue;
			}
			t.push({
				quantified: !1,
				alternation: !1
			});
			continue;
		}
		if (a === "|") {
			let e = t[t.length - 1];
			e && (e.alternation = !0);
			continue;
		}
		if (a === ")") {
			let n = t.pop();
			if (!n) return !1;
			let r = v(e, i + 1);
			if (r && (n.quantified || n.alternation)) return !1;
			let a = t[t.length - 1];
			a && (a.quantified = a.quantified || n.quantified || r !== null, a.alternation = a.alternation || n.alternation), r && (i += r.length);
			continue;
		}
		let o = v(e, i);
		if (o) {
			let e = t[t.length - 1];
			e && (e.quantified = !0), i += o.length - 1;
		}
	}
	return t.length === 0 && !n && !r;
}
// src/sdk/version.ts
var b = "0.7.0", x = "reactive-md-component/v1", ee = "reactive-md-config/v1", te = "reactive-md-config/v2", S = "reactive-md-preset/v1", ne = "reactive-md-react-preset/v1", re = "reactive-md-assembly/v1", ie = "reactive-md-extensions/v1", ae = 128, oe = 8, se = /^(\d+)\.(\d+)\.(\d+)(?:-([0-9A-Za-z.-]+))?(?:\+[0-9A-Za-z.-]+)?$/, ce = /^0\d+$/;
function le(e) {
	if (e === void 0) return Object.freeze([]);
	let t = e.split("."), n = [];
	for (let e of t) {
		if (e.length === 0 || ce.test(e) && e !== "0" && /^\d+$/.test(e) || /^\d+$/.test(e) && !Number.isSafeInteger(Number(e))) return null;
		n.push(/^\d+$/.test(e) ? Number(e) : e);
	}
	return Object.freeze(n);
}
function C(e) {
	let t = se.exec(e);
	if (!t) return null;
	let [, n, r, i, a] = t;
	for (let e of [
		n,
		r,
		i
	]) if (e.length > 1 && e.startsWith("0") || !Number.isSafeInteger(Number(e))) return null;
	let o = le(a);
	return o === null ? null : {
		major: Number(n),
		minor: Number(r),
		patch: Number(i),
		prerelease: o
	};
}
function ue(e, t) {
	return typeof e == "number" && typeof t == "number" ? e === t ? 0 : e < t ? -1 : 1 : typeof e == "number" ? -1 : typeof t == "number" ? 1 : e === t ? 0 : e < t ? -1 : 1;
}
function de(e, t) {
	for (let n of [
		"major",
		"minor",
		"patch"
	]) if (e[n] !== t[n]) return e[n] < t[n] ? -1 : 1;
	if (e.prerelease.length === 0 && t.prerelease.length === 0) return 0;
	if (e.prerelease.length === 0) return 1;
	if (t.prerelease.length === 0) return -1;
	let n = Math.min(e.prerelease.length, t.prerelease.length);
	for (let r = 0; r < n; r += 1) {
		let n = ue(e.prerelease[r], t.prerelease[r]);
		if (n !== 0) return n;
	}
	return e.prerelease.length === t.prerelease.length ? 0 : e.prerelease.length < t.prerelease.length ? -1 : 1;
}
function w(e, t, n) {
	return {
		major: e,
		minor: t,
		patch: n,
		prerelease: Object.freeze([])
	};
}
function fe(e, t) {
	if (e === "^") {
		let e = t.major > 0 ? w(t.major + 1, 0, 0) : t.minor > 0 ? w(0, t.minor + 1, 0) : w(0, 0, t.patch + 1);
		return [{
			operator: ">=",
			version: t
		}, {
			operator: "<",
			version: e
		}];
	}
	return e === "~" ? [{
		operator: ">=",
		version: t
	}, {
		operator: "<",
		version: w(t.major, t.minor + 1, 0)
	}] : [{
		operator: e,
		version: t
	}];
}
function T(e) {
	if (typeof e != "string") return null;
	let t = e.trim();
	if (t.length === 0 || t.length > 128) return null;
	let n = t.split(/\s+/);
	if (n.length === 0 || n.length > 8) return null;
	let r = [];
	try {
		for (let e of n) {
			let t = "=", n = e;
			e.startsWith(">=") || e.startsWith("<=") ? (t = e.slice(0, 2), n = e.slice(2)) : (e.startsWith(">") || e.startsWith("<") || e.startsWith("=") || e.startsWith("^") || e.startsWith("~")) && (t = e[0], n = e.slice(1));
			let i = C(n);
			if (i === null || (r.push(...fe(t, i)), r.length > 16)) return null;
		}
	} catch {
		return null;
	}
	return Object.freeze({
		source: t,
		comparators: Object.freeze(r)
	});
}
function E(e) {
	return typeof e == "string" && C(e) !== null;
}
function pe(e, t) {
	try {
		let n = C(e);
		if (n === null) return !1;
		let r = typeof t == "string" ? T(t) : t;
		if (!r || !Array.isArray(r.comparators) || r.comparators.length === 0 || n.prerelease.length && !r.comparators.some(({ version: e }) => e.prerelease.length && e.major === n.major && e.minor === n.minor && e.patch === n.patch)) return !1;
		for (let e of r.comparators) {
			let t = de(n, e.version);
			switch (e.operator) {
				case "=":
					if (t !== 0) return !1;
					break;
				case ">":
					if (t <= 0) return !1;
					break;
				case ">=":
					if (t < 0) return !1;
					break;
				case "<":
					if (t >= 0) return !1;
					break;
				case "<=":
					if (t > 0) return !1;
					break;
				default: return !1;
			}
		}
		return !0;
	} catch {
		return !1;
	}
}
function me(e) {
	return typeof e == "object" && !!e && typeof e.source == "string" && Array.isArray(e.comparators);
}
// src/sdk/manifest.ts
var he = 64, ge = 64, _e = 128, ve = 160, ye = 64, be = 64, xe = 512, D = 4096, Se = 16, Ce = 32, we = 256, Te = 65536, O = /^[a-z][a-z0-9]*(?:-[a-z0-9]+)*$/, k = /^[a-z0-9][a-z0-9._-]*(?:\/[a-z0-9][a-z0-9._-]*)*$/, Ee = /^\d+\.\d+\.\d+(?:-[0-9A-Za-z.-]+)?$/, De = /^[a-z]{2,3}(?:-[A-Za-z0-9]{2,8})*$/, A = /* @__PURE__ */ new Set([
	"__proto__",
	"constructor",
	"prototype"
]), j = /* @__PURE__ */ new WeakSet(), Oe = /* @__PURE__ */ new Set([
	"string",
	"number",
	"boolean",
	"enum"
]), ke = /* @__PURE__ */ new Set([
	"leaf",
	"inline",
	"container"
]), Ae = /* @__PURE__ */ new Set([
	"string",
	"number",
	"boolean",
	"null",
	"array",
	"number-array"
]), je = /* @__PURE__ */ new Set([
	"text",
	"number",
	"boolean",
	"choice",
	"date",
	"timer",
	"checklist",
	"tabs",
	"diagram",
	"multi-select",
	"selection",
	"steps",
	"collection"
]), Me = /* @__PURE__ */ new Set([
	"empty",
	"false",
	"max-step",
	"nearest-zero",
	"min",
	"first-option",
	"first-tab",
	"first-step",
	"first-node",
	"checked",
	"duration",
	"empty-array",
	"none"
]), Ne = /* @__PURE__ */ new Set([
	"none",
	"inline",
	"markdown"
]), Pe = /* @__PURE__ */ new Set([
	"none",
	"any",
	"inline",
	"content",
	"table",
	"plot",
	"diagram",
	"quiz",
	"options",
	"tabs",
	"steps",
	"components"
]), Fe = /* @__PURE__ */ new Set(/* @__PURE__ */ "numeric-range.text-length.date-bounds.nonempty.progress-bounds.timer-duration.option-count.selection-requires.inline-body.no-components.single-table.math-body.options-body.value-sequence.only-children.diagram-body.quiz-body.checklist-body.dynamic-constraints.require-full-interpolation.scoped-expressions.row-values.validation-rule.anchor.navigation.data-table.plot-math.chart-table.timeline-table.table-selection.retain.self-binding-read.inline-math-reads.value-date.value-length.value-required.value-email".split(".")), Ie = /* @__PURE__ */ new Set([
	"none",
	"required",
	"optional"
]), Le = /* @__PURE__ */ new Set([
	"id",
	"name",
	"version",
	"protocol",
	"form",
	"props",
	"bindings",
	"children",
	"structure",
	"rules",
	"slotRelations",
	"legacyHost",
	"capabilities",
	"authoring",
	"dependencies",
	"styles",
	"requires",
	"replaces"
]), Re = /* @__PURE__ */ new Set([
	"kind",
	"required",
	"static",
	"dynamic",
	"default",
	"nullable",
	"enum",
	"values",
	"pattern",
	"min",
	"max",
	"integer",
	"positive",
	"color",
	"coerce",
	"description"
]), ze = /* @__PURE__ */ new Set([
	"kind",
	"family",
	"bind",
	"initial",
	"initialRule",
	"required",
	"exclusive",
	"constraints",
	"options",
	"maxItems",
	"requiresAttributes",
	"compare",
	"retain"
]), Be = /* @__PURE__ */ new Set([
	"min",
	"max",
	"step"
]), Ve = /* @__PURE__ */ new Set([
	"interactive",
	"static",
	"ssr",
	"offline"
]), He = /* @__PURE__ */ new Set([
	"title",
	"description",
	"category",
	"insertText"
]), Ue = /* @__PURE__ */ new Set(["kind", "required"]), We = /* @__PURE__ */ new Set([
	"rule",
	"label",
	"parents",
	"child",
	"children",
	"min",
	"max",
	"inlineOnly",
	"noComponents",
	"valueAttribute",
	"generatedPrefix",
	"forbidSeparator",
	"maxItems"
]), Ge = /* @__PURE__ */ new Set(["id", "version"]), Ke = /* @__PURE__ */ new Set(["kernel"]), qe = /* @__PURE__ */ new Set(["id", "version"]), Je = /^[A-Za-z0-9][A-Za-z0-9._/-]*$/, Ye = /^[A-Za-z][A-Za-z0-9]*$/, M = /* @__PURE__ */ new Set(["setMany"]), Xe = 16, Ze = 32, Qe = 16, $e = 32, et = /* @__PURE__ */ new Set([
	"bind",
	"initial",
	"disabled"
]);
function N(e, t) {
	throw Error(`Invalid local component manifest (${e}): ${t}`);
}
function tt(e) {
	try {
		let t = JSON.stringify(e);
		return typeof t == "string" ? typeof TextEncoder == "function" ? new TextEncoder().encode(t).length : t.length * 2 : Infinity;
	} catch {
		return Infinity;
	}
}
function P(e) {
	if (typeof e != "object" || !e || Array.isArray(e)) return !1;
	let t = Object.getPrototypeOf(e);
	return t === Object.prototype || t === null;
}
function F(e, t, n) {
	for (let r of Object.keys(e)) A.has(r) && N(n, `field "${r}" is not allowed.`), t.has(r) || N(n, `unknown field "${r}".`);
}
function I(e, t) {
	return typeof e != "boolean" && N(t, "must be a boolean."), e;
}
function L(e, t, n = D) {
	return typeof e != "string" && N(t, "must be a string."), e.length > n && N(t, `exceeds the ${n}-character limit.`), e;
}
function R(e, t) {
	return typeof e == "number" && Number.isFinite(e) || N(t, "must be a finite number."), e;
}
function z(e, t) {
	return typeof e != "string" && N(t, "must be a string."), e.length > 128 && N(t, "exceeds the 128-character limit."), O.test(e) || N(t, "must use lowercase kebab-case."), e;
}
function B(e, t) {
	P(e) || N(t, "must be an object.");
	let n = {}, r = Object.keys(e).sort();
	for (let i of r) A.has(i) && N(t, `locale "${i}" is not allowed.`), De.test(i) || N(t, `locale "${i}" must look like "en" or "zh-CN".`), n[i] = L(e[i], `${t}.${i}`, 256);
	return n;
}
function nt(e, t) {
	P(e) || N(t, "must be an object."), F(e, He, t);
	let n = {};
	return e.title !== void 0 && (n.title = B(e.title, `${t}.title`)), e.description !== void 0 && (n.description = B(e.description, `${t}.description`)), e.category !== void 0 && (n.category = L(e.category, `${t}.category`, 64)), e.insertText !== void 0 && (n.insertText = L(e.insertText, `${t}.insertText`, D)), n;
}
function rt(e, t, n) {
	P(e) || N(n, "must be an object."), F(e, Ue, n);
	let r = e.kind;
	typeof r == "string" && Ne.has(r) || N(`${n}.kind`, "must be \"none\", \"inline\" or \"markdown\".");
	let i = r;
	e.required !== void 0 && I(e.required, `${n}.required`);
	let a = e.required === !0;
	return t === "leaf" && i !== "none" && N(n, "a leaf component cannot declare body content."), t === "inline" && i === "markdown" && N(n, "an inline component cannot declare Markdown block content."), a && i === "none" && N(n, "cannot require body content of kind \"none\"."), {
		kind: i,
		...a ? { required: !0 } : {}
	};
}
function it(e) {
	if (e !== void 0) return e.kind === "none" ? Object.freeze({
		rule: "none",
		label: "none"
	}) : e.kind === "inline" ? Object.freeze({
		rule: "inline",
		label: "none",
		inlineOnly: !0,
		noComponents: !0,
		...e.required ? { min: 1 } : {}
	}) : Object.freeze({
		rule: "any",
		label: "none",
		...e.required ? { min: 1 } : {}
	});
}
function V(e, t) {
	Array.isArray(e) || N(t, "must be an array of component names."), e.length > 32 && N(t, "accepts at most 32 names.");
	let n = /* @__PURE__ */ new Set(), r = [];
	for (let i of e) {
		let e = z(i, t);
		n.has(e) && N(t, `name "${e}" is declared more than once.`), n.add(e), r.push(e);
	}
	return r;
}
function at(e, t) {
	let n = R(e, t);
	return (!Number.isInteger(n) || n < 0) && N(t, "must be a nonnegative integer."), n;
}
function ot(e, t, n) {
	P(e) || N(n, "must be an object."), F(e, We, n);
	let r = e.rule;
	typeof r == "string" && Pe.has(r) || N(`${n}.rule`, "is not a supported child rule.");
	let i = r;
	t === "leaf" && i !== "none" && N(n, "a leaf component cannot declare body content."), t === "inline" && i !== "none" && i !== "inline" && i !== "any" && N(n, "an inline component only supports \"none\", \"inline\" or \"any\".");
	let o = { rule: i };
	if (e.label !== void 0 && (typeof e.label == "string" && Ie.has(e.label) || N(`${n}.label`, "must be \"none\", \"required\" or \"optional\"."), o.label = e.label), e.parents !== void 0 && (o.parents = V(e.parents, `${n}.parents`)), e.child !== void 0 && (o.child = z(e.child, `${n}.child`)), e.children !== void 0 && (o.children = V(e.children, `${n}.children`)), e.min !== void 0 && (o.min = U(e.min, `${n}.min`, a)), e.max !== void 0 && (o.max = U(e.max, `${n}.max`, a)), o.min !== void 0 && o.max !== void 0 && o.min > o.max && N(n, "\"min\" cannot exceed \"max\"."), e.inlineOnly !== void 0 && (o.inlineOnly = I(e.inlineOnly, `${n}.inlineOnly`)), e.noComponents !== void 0 && (o.noComponents = I(e.noComponents, `${n}.noComponents`)), e.valueAttribute !== void 0 && (o.valueAttribute = z(e.valueAttribute, `${n}.valueAttribute`)), e.generatedPrefix !== void 0) {
		let t = L(e.generatedPrefix, `${n}.generatedPrefix`, 128);
		t.length === 0 && N(`${n}.generatedPrefix`, "must not be empty."), o.generatedPrefix = t;
	}
	if (e.forbidSeparator !== void 0) {
		let t = L(e.forbidSeparator, `${n}.forbidSeparator`, 4);
		t.length === 0 && N(`${n}.forbidSeparator`, "must not be empty."), o.forbidSeparator = t;
	}
	return e.maxItems !== void 0 && (o.maxItems = U(e.maxItems, `${n}.maxItems`, a)), o;
}
function H(e, t) {
	return z(e, t);
}
function st(e, t) {
	return at(e, t);
}
function U(e, t, n) {
	let r = at(e, t);
	return r > n && N(t, `cannot exceed the kernel limit ${n}.`), r;
}
function W(e, t) {
	return V(e, t);
}
function ct(e, t) {
	return Array.isArray(e) || N(t, "must be an array of strings."), e.length > 32 && N(t, "accepts at most 32 values."), e.map((e) => L(e, t, 128));
}
function lt(e, t) {
	P(e) || N(t, "must be an object.");
	let n = e.kind;
	typeof n == "string" && Fe.has(n) || N(`${t}.kind`, "is not a supported rule.");
	let r = (n) => F(e, /* @__PURE__ */ new Set(["kind", ...n]), t), i = (n) => {
		let r = {};
		for (let i of n) e[i] !== void 0 && (r[i] = H(e[i], `${t}.${i}`));
		return r;
	};
	switch (n) {
		case "numeric-range": {
			r([
				"min",
				"max",
				"step",
				"order",
				"integer",
				"positiveInteger"
			]);
			let a;
			return e.order !== void 0 && (e.order !== "nondecreasing" && e.order !== "increasing" && N(`${t}.order`, "must be \"nondecreasing\" or \"increasing\"."), a = e.order), {
				kind: n,
				...i([
					"min",
					"max",
					"step",
					"integer",
					"positiveInteger"
				]),
				...a ? { order: a } : {}
			};
		}
		case "text-length": return r(["min", "max"]), {
			kind: n,
			...i(["min", "max"])
		};
		case "date-bounds": return r([
			"min",
			"max",
			"required"
		]), {
			kind: n,
			...i([
				"min",
				"max",
				"required"
			])
		};
		case "nonempty": return r(["attribute"]), {
			kind: n,
			attribute: H(e.attribute, `${t}.attribute`)
		};
		case "progress-bounds": return r([
			"value",
			"max",
			"defaultMax"
		]), {
			kind: n,
			value: H(e.value, `${t}.value`),
			max: H(e.max, `${t}.max`),
			defaultMax: R(e.defaultMax, `${t}.defaultMax`)
		};
		case "timer-duration": return r(["attribute", "default"]), {
			kind: n,
			attribute: H(e.attribute, `${t}.attribute`),
			default: R(e.default, `${t}.default`)
		};
		case "option-count": return r(["max"]), {
			kind: n,
			...e.max === void 0 ? {} : { max: H(e.max, `${t}.max`) }
		};
		case "selection-requires": return r(["key", "attributes"]), {
			kind: n,
			key: H(e.key, `${t}.key`),
			attributes: W(e.attributes, `${t}.attributes`)
		};
		case "inline-body": return r(["strict"]), {
			kind: n,
			...e.strict === void 0 ? {} : { strict: I(e.strict, `${t}.strict`) }
		};
		case "no-components":
		case "math-body":
		case "inline-math-reads": return r([]), { kind: n };
		case "single-table": return r(["fallbackSingle"]), {
			kind: n,
			...e.fallbackSingle === void 0 ? {} : { fallbackSingle: I(e.fallbackSingle, `${t}.fallbackSingle`) }
		};
		case "options-body": return r([
			"child",
			"valueAttribute",
			"unique",
			"max",
			"forbidSeparator"
		]), {
			kind: n,
			child: H(e.child, `${t}.child`),
			valueAttribute: H(e.valueAttribute, `${t}.valueAttribute`),
			unique: e.unique === void 0 || I(e.unique, `${t}.unique`),
			...e.max === void 0 ? {} : { max: U(e.max, `${t}.max`, a) },
			...e.forbidSeparator === void 0 ? {} : { forbidSeparator: L(e.forbidSeparator, `${t}.forbidSeparator`, 4) }
		};
		case "value-sequence": return r([
			"child",
			"valueAttribute",
			"min",
			"generatedPrefix",
			"unique",
			"duplicateCode"
		]), {
			kind: n,
			child: H(e.child, `${t}.child`),
			valueAttribute: H(e.valueAttribute, `${t}.valueAttribute`),
			min: st(e.min, `${t}.min`),
			generatedPrefix: L(e.generatedPrefix, `${t}.generatedPrefix`, 128),
			unique: e.unique === void 0 || I(e.unique, `${t}.unique`),
			...e.duplicateCode === void 0 ? {} : { duplicateCode: L(e.duplicateCode, `${t}.duplicateCode`, 128) }
		};
		case "only-children": return r([
			"children",
			"min",
			"max",
			"maxCode",
			"onlyCode"
		]), {
			kind: n,
			children: W(e.children, `${t}.children`),
			min: st(e.min, `${t}.min`),
			...e.max === void 0 ? {} : { max: U(e.max, `${t}.max`, a) },
			...e.maxCode === void 0 ? {} : { maxCode: L(e.maxCode, `${t}.maxCode`, 128) },
			...e.onlyCode === void 0 ? {} : { onlyCode: L(e.onlyCode, `${t}.onlyCode`, 128) }
		};
		case "diagram-body": return r([
			"node",
			"edge",
			"id",
			"from",
			"to",
			"label"
		]), {
			kind: n,
			node: H(e.node, `${t}.node`),
			edge: H(e.edge, `${t}.edge`),
			id: H(e.id, `${t}.id`),
			from: H(e.from, `${t}.from`),
			to: H(e.to, `${t}.to`),
			...e.label === void 0 ? {} : { label: H(e.label, `${t}.label`) }
		};
		case "quiz-body": return r([
			"type",
			"answer",
			"tolerance",
			"child",
			"valueAttribute",
			"max"
		]), {
			kind: n,
			type: H(e.type, `${t}.type`),
			answer: H(e.answer, `${t}.answer`),
			tolerance: H(e.tolerance, `${t}.tolerance`),
			child: H(e.child, `${t}.child`),
			valueAttribute: H(e.valueAttribute, `${t}.valueAttribute`),
			...e.max === void 0 ? {} : { max: U(e.max, `${t}.max`, a) }
		};
		case "checklist-body": return r(["itemLimit"]), {
			kind: n,
			itemLimit: U(e.itemLimit, `${t}.itemLimit`, a)
		};
		case "dynamic-constraints":
		case "require-full-interpolation": return r(["attributes"]), {
			kind: n,
			attributes: W(e.attributes, `${t}.attributes`)
		};
		case "scoped-expressions": return r(["attributes", "scope"]), e.scope !== "row" && e.scope !== "validation" && N(`${t}.scope`, "must be \"row\" or \"validation\"."), {
			kind: n,
			attributes: W(e.attributes, `${t}.attributes`),
			scope: e.scope
		};
		case "row-values": return r([
			"rows",
			"key",
			"child",
			"childValue"
		]), {
			kind: n,
			rows: H(e.rows, `${t}.rows`),
			key: H(e.key, `${t}.key`),
			child: H(e.child, `${t}.child`),
			childValue: H(e.childValue, `${t}.childValue`)
		};
		case "validation-rule": return r([
			"when",
			"fields",
			"message",
			"placement",
			"max"
		]), e.placement !== "container" && e.placement !== "prose" && N(`${t}.placement`, "must be \"container\" or \"prose\"."), {
			kind: n,
			when: H(e.when, `${t}.when`),
			fields: H(e.fields, `${t}.fields`),
			message: H(e.message, `${t}.message`),
			placement: e.placement,
			max: U(e.max, `${t}.max`, 100)
		};
		case "anchor": return r(["id"]), {
			kind: n,
			id: H(e.id, `${t}.id`)
		};
		case "navigation": return r(["target"]), {
			kind: n,
			target: H(e.target, `${t}.target`)
		};
		case "data-table": return r([
			"rows",
			"key",
			"child",
			"childValue",
			"label",
			"maxRows",
			"defaultMaxRows",
			"documentRows",
			"documentCells",
			"maxColumns"
		]), {
			kind: n,
			rows: H(e.rows, `${t}.rows`),
			key: H(e.key, `${t}.key`),
			child: H(e.child, `${t}.child`),
			childValue: H(e.childValue, `${t}.childValue`),
			label: H(e.label, `${t}.label`),
			maxRows: H(e.maxRows, `${t}.maxRows`),
			defaultMaxRows: U(e.defaultMaxRows, `${t}.defaultMaxRows`, d),
			documentRows: U(e.documentRows, `${t}.documentRows`, m),
			documentCells: U(e.documentCells, `${t}.documentCells`, h),
			maxColumns: U(e.maxColumns, `${t}.maxColumns`, 20)
		};
		case "plot-math": return r([
			"min",
			"max",
			"samples",
			"curves",
			"points"
		]), {
			kind: n,
			min: H(e.min, `${t}.min`),
			max: H(e.max, `${t}.max`),
			samples: H(e.samples, `${t}.samples`),
			curves: U(e.curves, `${t}.curves`, 16),
			points: U(e.points, `${t}.points`, l)
		};
		case "chart-table": return r([
			"chartKind",
			"x",
			"y"
		]), {
			kind: n,
			chartKind: H(e.chartKind, `${t}.chartKind`),
			x: H(e.x, `${t}.x`),
			y: H(e.y, `${t}.y`)
		};
		case "timeline-table": return r(["headerSets"]), Array.isArray(e.headerSets) || N(`${t}.headerSets`, "must be an array."), {
			kind: n,
			headerSets: e.headerSets.map((e, n) => ct(e, `${t}.headerSets[${n}]`))
		};
		case "table-selection": return r(["key", "bindings"]), {
			kind: n,
			key: H(e.key, `${t}.key`),
			bindings: W(e.bindings, `${t}.bindings`)
		};
		case "retain": return r(["value"]), {
			kind: n,
			value: I(e.value, `${t}.value`)
		};
		case "self-binding-read": return r(["mode", "attribute"]), e.mode !== "always" && e.mode !== "attribute" && N(`${t}.mode`, "must be \"always\" or \"attribute\"."), {
			kind: n,
			mode: e.mode,
			...e.attribute === void 0 ? {} : { attribute: H(e.attribute, `${t}.attribute`) }
		};
		case "value-date": return r([
			"min",
			"max",
			"required"
		]), {
			kind: n,
			...i([
				"min",
				"max",
				"required"
			])
		};
		case "value-length": return r([
			"min",
			"max",
			"email",
			"emailType"
		]), {
			kind: n,
			...i([
				"min",
				"max",
				"email"
			]),
			...e.emailType === void 0 ? {} : { emailType: L(e.emailType, `${t}.emailType`, 128) }
		};
		case "value-required": return r(["required"]), {
			kind: n,
			required: H(e.required, `${t}.required`)
		};
		case "value-email": return r(["type", "value"]), {
			kind: n,
			...i(["type"]),
			...e.value === void 0 ? {} : { value: L(e.value, `${t}.value`, 128) }
		};
		default: N(`${t}.kind`, "is not a supported rule.");
	}
}
function ut(e) {
	Array.isArray(e) || N("rules", "must be an array."), e.length > 32 && N("rules", "accepts at most 32 rules.");
	let t = [];
	for (let n = 0; n < e.length; n += 1) t.push(lt(e[n], `rules[${n}]`));
	return t;
}
function dt(e) {
	Array.isArray(e) || N("slotRelations", "must be an array."), e.length > 16 && N("slotRelations", "accepts at most 16 relations.");
	let t = [];
	for (let n = 0; n < e.length; n += 1) {
		let r = e[n], i = `slotRelations[${n}]`;
		P(r) || N(i, "must be an object."), F(r, /* @__PURE__ */ new Set(["lower", "upper"]), i), t.push({
			lower: z(r.lower, `${i}.lower`),
			upper: z(r.upper, `${i}.upper`)
		});
	}
	return t;
}
function ft(e, t) {
	P(e) || N(t, "must be an object."), F(e, Ve, t);
	let n = (n) => e[n] !== void 0 && I(e[n], `${t}.${n}`);
	return {
		interactive: n("interactive"),
		static: n("static"),
		ssr: n("ssr"),
		offline: n("offline")
	};
}
function pt(e, t) {
	P(e) || N(t, "must be an object."), F(e, Re, t);
	let n = e.kind;
	typeof n == "string" && Oe.has(n) || N(`${t}.kind`, "must be \"string\", \"number\", \"boolean\" or \"enum\".");
	let r = n, i = { kind: r };
	for (let n of [
		"required",
		"static",
		"dynamic",
		"integer",
		"positive",
		"color",
		"nullable"
	]) e[n] !== void 0 && (i[n] = I(e[n], `${t}.${n}`));
	i.static === !0 && i.dynamic === !0 && N(t, "cannot be both static and dynamic."), e.coerce !== void 0 && (e.coerce !== "text" && N(`${t}.coerce`, "must be \"text\"."), r !== "string" && N(`${t}.coerce`, "is only valid for kind \"string\"."), i.coerce = "text");
	let a = e.enum === void 0 ? e.values : e.enum, o = a !== void 0;
	if (r !== "enum") o && N(t, `"enum" is only valid for kind "enum", not "${r}".`);
	else {
		e.enum !== void 0 && e.values !== void 0 && N(t, "use \"enum\" or \"values\", not both."), Array.isArray(a) && a.length !== 0 || N(`${t}.enum`, "must be a non-empty string array."), a.length > 64 && N(`${t}.enum`, "accepts at most 64 values.");
		let n = /* @__PURE__ */ new Set(), r = [];
		for (let e of a) {
			let i = L(e, `${t}.enum`, 128);
			n.has(i) && N(`${t}.enum`, `value "${i}" is declared more than once.`), n.add(i), r.push(i);
		}
		i.enum = r;
	}
	let s = e.pattern !== void 0;
	if (r !== "string") s && N(t, `"pattern" is only valid for kind "string", not "${r}".`);
	else if (s) {
		typeof e.pattern != "string" && N(`${t}.pattern`, "must be a string."), e.pattern.length > 512 && N(`${t}.pattern`, "exceeds the 512-character limit.");
		try {
			new RegExp(e.pattern);
		} catch {
			N(`${t}.pattern`, "is not a valid regular expression.");
		}
		y(e.pattern) || N(`${t}.pattern`, "uses unsupported regex syntax; nested quantifiers, quantified alternation, backreferences and lookarounds are rejected."), i.pattern = e.pattern;
	}
	let c = e.min !== void 0, l = e.max !== void 0;
	if (r === "number" ? (c && (i.min = R(e.min, `${t}.min`)), l && (i.max = R(e.max, `${t}.max`)), i.min !== void 0 && i.max !== void 0 && i.min > i.max && N(t, "\"min\" cannot exceed \"max\".")) : ((c || l) && N(t, "\"min\" and \"max\" are only valid for kind \"number\"."), i.integer === !0 && N(t, "\"integer\" is only valid for kind \"number\"."), i.positive === !0 && N(t, "\"positive\" is only valid for kind \"number\".")), i.color === !0 && r !== "string" && N(t, "\"color\" is only valid for kind \"string\"."), e.description !== void 0 && (i.description = B(e.description, `${t}.description`)), e.default !== void 0) {
		let n = e.default;
		if (n === null) i.nullable !== !0 && N(`${t}.default`, "is null but the prop is not nullable."), i.default = null;
		else if (r === "string") i.default = L(n, `${t}.default`);
		else if (r === "number") {
			let e = R(n, `${t}.default`);
			i.integer === !0 && !Number.isInteger(e) && N(`${t}.default`, "must be an integer."), i.positive === !0 && !(e > 0) && N(`${t}.default`, "must be greater than zero."), i.min !== void 0 && e < i.min && N(`${t}.default`, `is below the minimum ${i.min}.`), i.max !== void 0 && e > i.max && N(`${t}.default`, `exceeds the maximum ${i.max}.`), i.default = e;
		} else if (r === "boolean") i.default = I(n, `${t}.default`);
		else {
			let e = L(n, `${t}.default`, 128);
			i.enum?.includes(e) || N(`${t}.default`, `"${e}" is not an allowed enum value.`), i.default = e;
		}
		if (i.pattern !== void 0 && r === "string" && typeof i.default == "string") {
			let e = !0;
			try {
				e = new RegExp(i.pattern).test(i.default);
			} catch {
				e = !1;
			}
			e || N(`${t}.default`, `does not match pattern ${i.pattern}.`);
		}
	}
	return i;
}
function mt(e, t) {
	P(e) || N(t, "must be an object with \"literal\" or \"prop\".");
	let n = Object.keys(e);
	n.length !== 1 && N(t, "must contain exactly one of \"literal\" or \"prop\".");
	let r = n[0];
	if (A.has(r) && N(t, `field "${r}" is not allowed.`), r === "literal") return { literal: R(e.literal, `${t}.literal`) };
	if (r === "prop") return { prop: z(e.prop, `${t}.prop`) };
	N(t, `unknown field "${r}"; use "literal" or "prop".`);
}
function ht(e, t, n, r) {
	P(e) || N(r, "must be an object."), F(e, Be, r);
	let i = {};
	for (let n of [
		"min",
		"max",
		"step"
	]) {
		if (e[n] === void 0) continue;
		let a = mt(e[n], `${r}.${n}`);
		if ("prop" in a) {
			let e = t[a.prop];
			e === void 0 && N(`${r}.${n}`, `references undeclared prop "${a.prop}".`), e.kind !== "number" && N(`${r}.${n}`, `references prop "${a.prop}", which is not a number.`);
		}
		n === "step" && "literal" in a && !(a.literal > 0) && N(`${r}.step`, "must be greater than 0."), i[n] = a;
	}
	return n !== "number" && (i.min || i.max || i.step) && N(r, "\"min\", \"max\" and \"step\" are only valid for number bindings."), i.min && "literal" in i.min && i.max && "literal" in i.max && i.min.literal > i.max.literal && N(r, "\"min\" cannot exceed \"max\"."), i;
}
function gt(e, t) {
	if (e === "number") return t === "timer" ? /* @__PURE__ */ new Set([
		"duration",
		"min",
		"nearest-zero"
	]) : /* @__PURE__ */ new Set([
		"min",
		"nearest-zero",
		"max-step"
	]);
	if (e === "boolean") return /* @__PURE__ */ new Set(["false"]);
	if (e === "null") return /* @__PURE__ */ new Set(["empty"]);
	if (e === "array") return t === "checklist" ? /* @__PURE__ */ new Set(["checked", "empty-array"]) : /* @__PURE__ */ new Set(["empty-array"]);
	if (e === "number-array") return /* @__PURE__ */ new Set(["empty-array"]);
	switch (t) {
		case "choice":
		case "selection": return /* @__PURE__ */ new Set(["first-option", "none"]);
		case "tabs": return /* @__PURE__ */ new Set(["first-tab"]);
		case "steps": return /* @__PURE__ */ new Set(["first-step"]);
		case "diagram": return /* @__PURE__ */ new Set(["first-node"]);
		case "date": return /* @__PURE__ */ new Set(["empty"]);
		default: return /* @__PURE__ */ new Set(["empty"]);
	}
}
function _t(e, t, n, r = !1) {
	P(e) || N(n, "must be an object."), F(e, ze, n);
	let i = e.kind;
	typeof i == "string" && Ae.has(i) || N(`${n}.kind`, "must be \"string\", \"number\", \"boolean\", \"array\", \"number-array\" or \"null\".");
	let a = i, o = e.family;
	typeof o == "string" && je.has(o) || N(`${n}.family`, "must be a supported binding family.");
	let s = o;
	({
		number: /* @__PURE__ */ new Set(["number", "timer"]),
		boolean: /* @__PURE__ */ new Set(["boolean"]),
		string: /* @__PURE__ */ new Set([
			"text",
			"choice",
			"date",
			"tabs",
			"diagram",
			"steps",
			"selection"
		]),
		array: /* @__PURE__ */ new Set([
			"multi-select",
			"checklist",
			"collection"
		]),
		"number-array": /* @__PURE__ */ new Set(["collection"]),
		null: /* @__PURE__ */ new Set(["text"])
	})[a]?.has(s) || N(`${n}.family`, `"${s}" is not supported for a ${a} binding.`);
	let c;
	if (e.options !== void 0) {
		a !== "string" && N(`${n}.options`, "is only valid for a string binding."), s !== "choice" && N(`${n}.options`, "requires family \"choice\".");
		let t = e.options;
		Array.isArray(t) && t.length !== 0 || N(`${n}.options`, "must be a non-empty string array."), t.length > 64 && N(`${n}.options`, "accepts at most 64 values.");
		let r = /* @__PURE__ */ new Set(), i = [];
		for (let e of t) {
			let t = L(e, `${n}.options`, 128);
			t.length === 0 && N(`${n}.options`, "values must be non-empty."), r.has(t) && N(`${n}.options`, `value "${t}" is declared more than once.`), r.add(t), i.push(t);
		}
		c = i;
	}
	a === "string" && s === "choice" && c === void 0 && !r && N(`${n}.options`, "is required for a choice binding."), s !== "choice" && c !== void 0 && N(`${n}.options`, "is only valid for family \"choice\".");
	let l = z(e.bind, `${n}.bind`), u = z(e.initial, `${n}.initial`);
	l === u && N(n, "\"bind\" and \"initial\" must name different attributes."), (M.has(l) || M.has(u)) && N(n, "binding attributes cannot use a reserved slot name."), (Object.hasOwn(t, l) || Object.hasOwn(t, u)) && N(n, "binding attributes are reserved and cannot be declared as props.");
	let d = gt(a, s), f;
	if (e.initialRule === void 0) switch (a) {
		case "number":
			f = s === "timer" ? "duration" : "nearest-zero";
			break;
		case "boolean":
			f = "false";
			break;
		case "array":
			f = s === "checklist" ? "checked" : "empty-array";
			break;
		case "number-array":
			f = "empty-array";
			break;
		case "null":
			f = "empty";
			break;
		default: f = s === "choice" ? "first-option" : s === "tabs" ? "first-tab" : s === "steps" ? "first-step" : s === "diagram" ? "first-node" : s === "selection" ? "none" : "empty";
	}
	else typeof e.initialRule == "string" && Me.has(e.initialRule) || N(`${n}.initialRule`, "is not a supported initial rule."), f = e.initialRule;
	d.has(f) || N(`${n}.initialRule`, `is not supported for a ${a} ${s} binding.`), e.required !== void 0 && I(e.required, `${n}.required`), e.exclusive !== void 0 && I(e.exclusive, `${n}.exclusive`), e.retain !== void 0 && I(e.retain, `${n}.retain`);
	let p;
	e.constraints !== void 0 && (p = ht(e.constraints, t, a, `${n}.constraints`));
	let m;
	if (e.maxItems !== void 0) {
		if (a !== "array" && a !== "number-array" && N(`${n}.maxItems`, "is only valid for array or number-array bindings."), m = mt(e.maxItems, `${n}.maxItems`), "prop" in m) {
			let e = t[m.prop];
			e === void 0 && N(`${n}.maxItems`, `references undeclared prop "${m.prop}".`), e.kind !== "number" && N(`${n}.maxItems`, `references prop "${m.prop}", which is not a number.`), e.dynamic === !0 && N(`${n}.maxItems`, "requires a static numeric property.");
		} else (!Number.isInteger(m.literal) || m.literal < 0) && N(`${n}.maxItems`, "must be a nonnegative integer.");
	}
	let h;
	if (e.requiresAttributes !== void 0) {
		h = V(e.requiresAttributes, `${n}.requiresAttributes`);
		for (let e of h) Object.hasOwn(t, e) || N(`${n}.requiresAttributes`, `references undeclared prop "${e}".`);
	}
	let g;
	if (e.compare !== void 0) {
		g = V(e.compare, `${n}.compare`);
		for (let e of g) Object.hasOwn(t, e) || N(`${n}.compare`, `references undeclared prop "${e}".`);
	}
	return {
		kind: a,
		family: s,
		bind: l,
		initial: u,
		initialRule: f,
		...e.required === !0 ? { required: !0 } : {},
		...e.exclusive === !0 ? { exclusive: !0 } : {},
		...c ? { options: c } : {},
		...p ? { constraints: p } : {},
		...m ? { maxItems: m } : {},
		...h ? { requiresAttributes: h } : {},
		...g ? { compare: g } : {},
		...e.retain === !1 ? { retain: !1 } : {}
	};
}
function vt(e, t) {
	P(e) || N(t, "must be an object."), F(e, Ge, t);
	let n = e.id;
	(typeof n != "string" || !k.test(n) || n.length > 160) && N(`${t}.id`, "must be a lowercase namespaced id.");
	let r;
	if (e.version !== void 0) {
		let n = e.version, i = T(n);
		i === null && N(`${t}.version`, "must be an exact version or a supported range (exact, ^, ~, >=, <=, >, <)."), r = i.source;
	}
	return {
		id: n,
		...r ? { version: r } : {}
	};
}
function yt(e) {
	P(e) || N("requires", "must be an object."), F(e, Ke, "requires");
	let t;
	if (e.kernel !== void 0) {
		let n = T(e.kernel);
		n === null && N("requires.kernel", "must be a supported kernel version range (exact, ^, ~, >=, <=, >, <)."), t = n.source;
	}
	return { ...t ? { kernel: t } : {} };
}
function bt(e, t) {
	P(e) || N("replaces", "must be an object."), F(e, qe, "replaces");
	let n = e.id;
	(typeof n != "string" || !k.test(n) || n.length > 160) && N("replaces.id", "must be a lowercase namespaced id."), n !== t && N("replaces.id", "must equal the declaring manifest id.");
	let r;
	if (e.version !== void 0) {
		let t = T(e.version);
		t === null && N("replaces.version", "must be an exact version or a supported range (exact, ^, ~, >=, <=, >, <)."), r = t.source;
	}
	return {
		id: n,
		...r ? { version: r } : {}
	};
}
function xt(e) {
	Array.isArray(e) || N("styles", "must be an array of style-resource ids."), e.length > 32 && N("styles", "accepts at most 32 resources.");
	let t = /* @__PURE__ */ new Set(), n = [];
	for (let r = 0; r < e.length; r += 1) {
		let i = e[r];
		(typeof i != "string" || i.length === 0 || i.length > 256) && N(`styles[${r}]`, "must be a non-empty string of at most 256 characters."), Je.test(i) || N(`styles[${r}]`, "must be a bounded resource id."), t.has(i) && N("styles", `resource "${i}" is declared more than once.`), t.add(i), n.push(i);
	}
	return n;
}
function G(e) {
	if (typeof e == "object" && e && j.has(e)) return e;
	P(e) || N("manifest", "must be an object."), F(e, Le, "manifest");
	let t = e.id;
	(typeof t != "string" || t.length > 160 || !k.test(t)) && N("id", "must be a lowercase namespaced id such as \"example/rating\".");
	let n = z(e.name, "name"), r = e.version;
	(typeof r != "string" || r.length > 64 || !Ee.test(r)) && N("version", "must be a semantic version such as 1.0.0."), e.protocol !== "reactive-md-component/v1" && N("protocol", `must be "${x}".`);
	let i = e.form;
	typeof i == "string" && ke.has(i) || N("form", "must be \"leaf\", \"inline\" or \"container\".");
	let a = i;
	P(e.props) || N("props", "must be an object.");
	let o = Object.keys(e.props).sort();
	o.length > 64 && N("props", "accepts at most 64 properties.");
	let s = {};
	for (let t of o) A.has(t) && N("props", `property "${t}" is not allowed.`), (!O.test(t) || t.length > 128) && N("props", `property "${t}" must use lowercase kebab-case.`), s[t] = pt(e.props[t], `props.${t}`);
	let c;
	if (e.bindings !== void 0) {
		P(e.bindings) || N("bindings", "must be an object.");
		let t = Object.keys(e.bindings);
		t.length === 0 && N("bindings", "must declare at least one binding slot."), t.length > 16 && N("bindings", "accepts at most 16 slots.");
		let n = {}, r = /* @__PURE__ */ new Set();
		for (let i of t) {
			A.has(i) && N("bindings", `field "${i}" is not allowed.`), Ye.test(i) || N("bindings", `slot "${i}" must be a letter followed by letters or digits.`), M.has(i) && N("bindings", `slot "${i}" is reserved by the runtime.`);
			let t = _t(e.bindings[i], s, `bindings.${i}`, a === "container" && Array.isArray(e.rules) && e.rules.some((e) => P(e) && e.kind === "options-body"));
			i !== "value" && (t.kind !== "number" || t.family !== "number") && N(`bindings.${i}`, "numeric named slots support kind \"number\" with family \"number\" in this contract."), i !== "value" && P(e.bindings[i]) && e.bindings[i].exclusive === !1 && N(`bindings.${i}.exclusive`, "named slots require exclusive ownership in this contract.");
			for (let e of [t.bind, t.initial]) r.has(e) && N("bindings", `attribute "${e}" is claimed by more than one binding.`), r.add(e);
			n[i] = i === "value" ? t : {
				...t,
				exclusive: !0
			};
		}
		c = n;
	}
	let l = e.children === void 0 ? void 0 : rt(e.children, a, "children");
	e.children !== void 0 && e.structure !== void 0 && N("manifest", "cannot declare both \"children\" and \"structure\"; use \"structure\".");
	let u = e.structure === void 0 ? it(l) : ot(e.structure, a, "structure"), d = e.rules === void 0 ? void 0 : ut(e.rules), f = e.slotRelations === void 0 ? void 0 : dt(e.slotRelations);
	e.legacyHost !== void 0 && I(e.legacyHost, "legacyHost");
	let p = ft(e.capabilities, "capabilities"), m = e.authoring === void 0 ? void 0 : nt(e.authoring, "authoring"), h = e.styles === void 0 ? void 0 : xt(e.styles), g = e.requires === void 0 ? void 0 : yt(e.requires), _ = e.replaces === void 0 ? void 0 : bt(e.replaces, t), v;
	if (e.dependencies !== void 0) {
		Array.isArray(e.dependencies) || N("dependencies", "must be an array."), e.dependencies.length > 16 && N("dependencies", "accepts at most 16 entries.");
		let t = /* @__PURE__ */ new Set(), n = [];
		for (let r = 0; r < e.dependencies.length; r += 1) {
			let i = vt(e.dependencies[r], `dependencies[${r}]`);
			t.has(i.id) && N("dependencies", `"${i.id}" is declared more than once.`), t.add(i.id), n.push(i);
		}
		v = n;
	}
	let y = {
		id: t,
		name: n,
		version: r,
		protocol: x,
		form: a,
		props: s,
		...c ? { bindings: c } : {},
		...l ? { children: l } : {},
		...u && !l ? { structure: u } : {},
		...d ? { rules: d } : {},
		...f ? { slotRelations: f } : {},
		...e.legacyHost === !0 ? { legacyHost: !0 } : {},
		capabilities: p,
		...m ? { authoring: m } : {},
		...h ? { styles: h } : {},
		...g ? { requires: g } : {},
		...v ? { dependencies: v } : {},
		..._ ? { replaces: _ } : {}
	};
	tt(y) > 65536 && N("manifest", `serialized size exceeds the ${Te}-byte budget.`);
	let b = Ct(y);
	return j.add(b), b;
}
function St(e) {
	return G(e);
}
function Ct(e) {
	if (typeof e != "object" || !e) return e;
	for (let t of Object.keys(e)) Ct(e[t]);
	return Object.freeze(e);
}
function wt(e) {
	return {
		kind: e.kind,
		...e.required === !0 ? { required: !0 } : {},
		...e.static === !0 ? { static: !0 } : {},
		...e.dynamic === void 0 ? {} : { dynamic: e.dynamic },
		...e.default === void 0 ? {} : { default: e.default },
		...e.nullable === !0 ? { nullable: !0 } : {},
		...e.enum ? { enum: [...e.enum] } : {},
		...e.pattern === void 0 ? {} : { pattern: e.pattern },
		...e.min === void 0 ? {} : { min: e.min },
		...e.max === void 0 ? {} : { max: e.max },
		...e.integer === !0 ? { integer: !0 } : {},
		...e.positive === !0 ? { positive: !0 } : {},
		...e.color === !0 ? { color: !0 } : {},
		...e.coerce === void 0 ? {} : { coerce: e.coerce }
	};
}
function K(e) {
	return "literal" in e ? { literal: e.literal } : { prop: e.prop };
}
function Tt(e) {
	return {
		...e.min ? { min: K(e.min) } : {},
		...e.max ? { max: K(e.max) } : {},
		...e.step ? { step: K(e.step) } : {}
	};
}
function Et(e) {
	let t = e.constraints;
	return {
		kind: e.kind,
		family: e.family,
		bind: e.bind,
		initial: e.initial,
		initialRule: e.initialRule,
		...e.required === !0 ? { required: !0 } : {},
		...e.exclusive === !0 ? { exclusive: !0 } : {},
		...e.options ? { options: [...e.options] } : {},
		...t ? { constraints: Tt(t) } : {},
		...e.maxItems ? { maxItems: K(e.maxItems) } : {},
		...e.requiresAttributes ? { requiresAttributes: [...e.requiresAttributes] } : {},
		...e.compare ? { compare: [...e.compare] } : {},
		...e.retain === !1 ? { retain: !1 } : {}
	};
}
function Dt(e) {
	return {
		rule: e.rule,
		...e.label === void 0 ? {} : { label: e.label },
		...e.parents ? { parents: [...e.parents] } : {},
		...e.child === void 0 ? {} : { child: e.child },
		...e.children ? { children: [...e.children] } : {},
		...e.min === void 0 ? {} : { min: e.min },
		...e.max === void 0 ? {} : { max: e.max },
		...e.inlineOnly === void 0 ? {} : { inlineOnly: e.inlineOnly },
		...e.noComponents === void 0 ? {} : { noComponents: e.noComponents },
		...e.valueAttribute === void 0 ? {} : { valueAttribute: e.valueAttribute },
		...e.generatedPrefix === void 0 ? {} : { generatedPrefix: e.generatedPrefix },
		...e.forbidSeparator === void 0 ? {} : { forbidSeparator: e.forbidSeparator },
		...e.maxItems === void 0 ? {} : { maxItems: e.maxItems }
	};
}
function Ot(e) {
	let t = e, n = Object.keys(t).sort(), r = {};
	for (let e of n) {
		let n = t[e];
		r[e] = Array.isArray(n) ? n.map((e) => Array.isArray(e) ? [...e] : e) : n;
	}
	return r;
}
function kt(e) {
	let t = {};
	for (let n of Object.keys(e.props).sort()) t[n] = wt(e.props[n]);
	let n = {};
	if (e.bindings) for (let t of Object.keys(e.bindings).sort()) n[t] = Et(e.bindings[t]);
	return {
		protocol: e.protocol,
		id: e.id,
		name: e.name,
		version: e.version,
		form: e.form,
		props: t,
		...e.bindings ? { bindings: n } : {},
		...e.children ? { children: {
			kind: e.children.kind,
			...e.children.required ? { required: !0 } : {}
		} } : {},
		...e.structure ? { structure: Dt(e.structure) } : {},
		...e.rules ? { rules: e.rules.map(Ot) } : {},
		...e.slotRelations ? { slotRelations: e.slotRelations.map((e) => ({ ...e })) } : {},
		capabilities: {
			interactive: e.capabilities.interactive,
			static: e.capabilities.static,
			ssr: e.capabilities.ssr,
			offline: e.capabilities.offline
		},
		...e.styles ? { styles: [...e.styles] } : {},
		...e.requires?.kernel ? { requires: { kernel: e.requires.kernel } } : {},
		...e.dependencies ? { dependencies: [...e.dependencies].map((e) => ({ ...e })).sort((e, t) => e.id < t.id ? -1 : +(e.id > t.id)) } : {},
		...e.replaces ? { replaces: {
			id: e.replaces.id,
			...e.replaces.version ? { version: e.replaces.version } : {}
		} } : {}
	};
}
var At = /* @__PURE__ */ new WeakMap();
function q(e) {
	let t = j.has(e) ? e : G(e), n = At.get(t);
	if (n !== void 0) return n;
	let r = _(JSON.stringify(kt(t)));
	return At.set(t, r), r;
}
function jt(e) {
	return Object.freeze({
		id: e.id,
		name: e.name,
		version: e.version,
		digest: q(e)
	});
}
function Mt(e) {
	return typeof e == "string" && e.length <= 128 && O.test(e);
}
function J(e) {
	return typeof e == "string" && e.length > 0 && e.length <= 160 && k.test(e);
}
// src/sdk/preset-core.ts
var Nt = 160, Pt = 256, Ft = 32, It = 256, Lt = 4096, Rt = /^[a-z0-9][a-z0-9._-]*(?:\/[a-z0-9][a-z0-9._-]*)*$/, zt = /* @__PURE__ */ new Set([
	"__proto__",
	"constructor",
	"prototype"
]), Bt = /* @__PURE__ */ new Set([
	"protocol",
	"id",
	"version",
	"components",
	"authoring",
	"themes",
	"dependencies",
	"metadata"
]), Vt = /* @__PURE__ */ new Set([
	"title",
	"description",
	"category",
	"insertText"
]), Ht = /* @__PURE__ */ new Set(["title", "description"]), Ut = /* @__PURE__ */ new Set(["id", "version"]), Wt = /* @__PURE__ */ new WeakSet();
function Y(e, t) {
	throw Error(`Invalid local preset (${e}): ${t}`);
}
function X(e) {
	if (typeof e != "object" || !e || Array.isArray(e)) return !1;
	let t = Object.getPrototypeOf(e);
	return t === Object.prototype || t === null;
}
function Z(e, t, n) {
	for (let r of Object.keys(e)) zt.has(r) && Y(n, `field "${r}" is not allowed.`), t.has(r) || Y(n, `unknown field "${r}".`);
}
function Q(e, t) {
	X(e) || Y(t, "must be a locale-keyed string map.");
	let n = {};
	for (let r of Object.keys(e).sort()) {
		zt.has(r) && Y(t, `locale "${r}" is not allowed.`), /^[a-z]{2,3}(?:-[A-Za-z0-9]{2,8})*$/.test(r) || Y(t, `locale "${r}" must look like "en" or "zh-CN".`);
		let i = e[r];
		(typeof i != "string" || i.length > Lt) && Y(t, `locale "${r}" must be a bounded string.`), n[r] = i;
	}
	return Object.freeze(n);
}
function Gt(e) {
	X(e) || Y("authoring", "must be an object."), Z(e, Vt, "authoring");
	let t = {};
	return e.title !== void 0 && (t.title = Q(e.title, "authoring.title")), e.description !== void 0 && (t.description = Q(e.description, "authoring.description")), e.category !== void 0 && ((typeof e.category != "string" || e.category.length > 64) && Y("authoring.category", "must be a bounded string."), t.category = e.category), e.insertText !== void 0 && ((typeof e.insertText != "string" || e.insertText.length > Lt) && Y("authoring.insertText", "must be a bounded string."), t.insertText = e.insertText), Object.freeze(t);
}
function Kt(e, t) {
	Array.isArray(e) || Y("authoring", "must be an array."), e.length > It && Y("authoring", `accepts at most ${It} entries.`);
	let n = new Set(t.map((e) => e.id)), r = /* @__PURE__ */ new Set(), i = [];
	for (let t = 0; t < e.length; t += 1) {
		let a = e[t];
		X(a) || Y(`authoring[${t}]`, "must be an object."), Z(a, /* @__PURE__ */ new Set(["componentId", "authoring"]), `authoring[${t}]`);
		let o = a.componentId;
		typeof o == "string" && J(o) || Y(`authoring[${t}].componentId`, "must be a lowercase namespaced id."), n.has(o) || Y(`authoring[${t}].componentId`, `"${o}" is not declared by this preset.`), r.has(o) && Y("authoring", `component "${o}" is declared more than once.`), r.add(o), i.push(Object.freeze({
			componentId: o,
			authoring: Gt(a.authoring)
		}));
	}
	return Object.freeze(i.sort((e, t) => e.componentId < t.componentId ? -1 : +(e.componentId > t.componentId)));
}
function qt(e) {
	Array.isArray(e) || Y("dependencies", "must be an array."), e.length > Ft && Y("dependencies", `accepts at most ${Ft} entries.`);
	let t = /* @__PURE__ */ new Set(), n = [];
	for (let r = 0; r < e.length; r += 1) {
		let i = e[r];
		X(i) || Y(`dependencies[${r}]`, "must be an object."), Z(i, Ut, `dependencies[${r}]`);
		let a = i.id;
		typeof a == "string" && J(a) || Y(`dependencies[${r}].id`, "must be a lowercase namespaced id."), t.has(a) && Y("dependencies", `"${a}" is declared more than once.`), t.add(a);
		let o = i.version;
		typeof o == "string" && E(o) || Y(`dependencies[${r}].version`, "must be an exact semantic version."), n.push(Object.freeze({
			id: a,
			version: o
		}));
	}
	return Object.freeze(n.sort((e, t) => e.id < t.id ? -1 : +(e.id > t.id)));
}
function Jt(e) {
	Array.isArray(e) || Y("themes", "must be an array.");
	let t = [], n = /* @__PURE__ */ new Set(), r = /* @__PURE__ */ new Set();
	for (let i = 0; i < e.length; i += 1) {
		let a = e[i];
		X(a) || Y(`themes[${i}]`, "must be an object.");
		let o = a.id, s = a.name, c = a.version;
		(typeof o != "string" || o.length === 0) && Y(`themes[${i}].id`, "must be a non-empty string."), (typeof s != "string" || s.length === 0) && Y(`themes[${i}].name`, "must be a non-empty string."), typeof c == "string" && E(c) || Y(`themes[${i}].version`, "must be a semantic version."), n.has(o) && Y("themes", `theme id "${o}" is declared more than once.`), r.has(s) && Y("themes", `theme name "${s}" is declared more than once.`), n.add(o), r.add(s), t.push(Object.freeze({ ...a }));
	}
	return Object.freeze(t.sort((e, t) => e.id < t.id ? -1 : +(e.id > t.id)));
}
function Yt(e) {
	return X(e) || Y("metadata", "must be an object."), Z(e, Ht, "metadata"), Object.freeze({
		...e.title === void 0 ? {} : { title: Q(e.title, "metadata.title") },
		...e.description === void 0 ? {} : { description: Q(e.description, "metadata.description") }
	});
}
function $(e) {
	if (X(e) && Wt.has(e)) return e;
	X(e) || Y("preset", "must be an object."), Z(e, Bt, "preset"), e.protocol !== "reactive-md-preset/v1" && Y("protocol", `must be "${S}".`);
	let t = e.id;
	(typeof t != "string" || t.length > Nt || !Rt.test(t)) && Y("id", "must be a lowercase namespaced id.");
	let n = e.version;
	typeof n == "string" && E(n) || Y("version", "must be a semantic version such as \"1.0.0\"."), Array.isArray(e.components) || Y("components", "must be an array."), e.components.length > Pt && Y("components", `accepts at most ${Pt} components.`);
	let r = [], i = /* @__PURE__ */ new Set(), a = /* @__PURE__ */ new Set();
	for (let t = 0; t < e.components.length; t += 1) {
		let n;
		try {
			n = St(e.components[t]);
		} catch (e) {
			Y(`components[${t}]`, e instanceof Error ? e.message : String(e));
		}
		i.has(n.id) && Y("components", `component id "${n.id}" is declared more than once.`), a.has(n.name) && Y("components", `component name "${n.name}" is declared more than once.`), i.add(n.id), a.add(n.name), r.push(n);
	}
	let o = e.authoring === void 0 ? void 0 : Kt(e.authoring, r), s = e.themes === void 0 ? void 0 : Jt(e.themes), c = e.dependencies === void 0 ? void 0 : qt(e.dependencies), l = e.metadata === void 0 ? void 0 : Yt(e.metadata), u = e.components, d = Object.isFrozen(u) && u.length === r.length && u.every((e, t) => e === r[t]) ? u : Object.freeze(r), f = Object.freeze({
		protocol: S,
		id: t,
		version: n,
		components: d,
		...o ? { authoring: o } : {},
		...s ? { themes: s } : {},
		...c ? { dependencies: c } : {},
		...l ? { metadata: l } : {}
	});
	return Wt.add(f), f;
}
function Xt(e) {
	return $(e);
}
function Zt(e) {
	let t = $(e);
	return _(JSON.stringify({
		protocol: S,
		id: t.id,
		version: t.version,
		components: [...t.components].map((e) => ({
			id: e.id,
			version: e.version,
			digest: q(e)
		})).sort((e, t) => e.id < t.id ? -1 : +(e.id > t.id)),
		dependencies: [...t.dependencies ?? []].map((e) => ({
			id: e.id,
			version: e.version
		})).sort((e, t) => e.id < t.id ? -1 : +(e.id > t.id))
	}));
}
// src/presets/identity.ts
var Qt = "reactive-md/default", $t = b;
export { h as $, it as A, oe as B, kt as C, q as D, Mt as E, te as F, T as G, E as H, ie as I, f as J, y as K, S as L, re as M, x as N, jt as O, ee as P, a as Q, ne as R, ye as S, J as T, me as U, ae as V, pe as W, n as X, r as Y, t as Z, Qe as _, $ as a, c as at, Ce as b, he as c, i as ct, ve as d, m as et, Te as f, Ze as g, ge as h, Zt as i, e as it, G as j, tt as k, Se as l, o as lt, xe as m, $t as n, d as nt, et as o, l as ot, _e as p, _ as q, Xt as r, s as rt, Xe as s, u as st, Qt as t, p as tt, be as u, g as ut, D as v, St as w, we as x, $e as y, b as z };
