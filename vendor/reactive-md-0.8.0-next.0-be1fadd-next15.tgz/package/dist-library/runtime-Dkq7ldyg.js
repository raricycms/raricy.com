import { C as e, D as t, S as n, l as r } from "./component-state-Cq2K5gkS.js";
// src/runtime-services/scheduler.ts
var i = 64, a = 16;
function o() {
	let e = () => typeof performance < "u" && typeof performance.now == "function" ? performance.now() : Date.now(), t = (e, t) => globalThis.setTimeout(e, t), n = (e) => {
		globalThis.clearTimeout(e);
	}, r = typeof globalThis.requestAnimationFrame == "function" ? globalThis.requestAnimationFrame.bind(globalThis) : void 0, i = typeof globalThis.cancelAnimationFrame == "function" ? globalThis.cancelAnimationFrame.bind(globalThis) : void 0, a = typeof document > "u" ? void 0 : document;
	return {
		now: e,
		setTimeout: t,
		clearTimeout: n,
		...r === void 0 ? {} : { requestAnimationFrame: r },
		...i === void 0 ? {} : { cancelAnimationFrame: i },
		isHidden: () => a !== void 0 && a.visibilityState === "hidden",
		subscribeVisibility: (e) => {
			if (a === void 0) return () => {};
			let t = () => e(a.visibilityState === "hidden");
			return a.addEventListener("visibilitychange", t), () => a.removeEventListener("visibilitychange", t);
		}
	};
}
function s(e) {
	let t = o(), n = e?.ports ?? {};
	return {
		now: n.now ?? t.now,
		setTimeout: n.setTimeout ?? t.setTimeout,
		clearTimeout: n.clearTimeout ?? t.clearTimeout,
		...n.requestAnimationFrame ?? t.requestAnimationFrame ? { requestAnimationFrame: n.requestAnimationFrame ?? t.requestAnimationFrame } : {},
		...n.cancelAnimationFrame ?? t.cancelAnimationFrame ? { cancelAnimationFrame: n.cancelAnimationFrame ?? t.cancelAnimationFrame } : {},
		...n.isHidden ?? t.isHidden ? { isHidden: n.isHidden ?? t.isHidden } : {},
		...n.subscribeVisibility ?? t.subscribeVisibility ? { subscribeVisibility: n.subscribeVisibility ?? t.subscribeVisibility } : {}
	};
}
function c(e) {
	let t = s(e), n = e?.maxSubscriptions ?? i, r = e?.minIntervalMs ?? a, o = e?.onError ?? (() => {}), c = /* @__PURE__ */ new Map(), l = 1, u = !1, d = !1, f = 0, p = 0, m = 0, h = null, g = () => {
		let e = t.now();
		return m = Math.max(m, e), m;
	}, _ = () => {
		let e = g();
		return e - p - (d ? e - f : 0);
	}, v = (e) => {
		e.timer !== null && (t.clearTimeout(e.timer), e.timer = null), e.frame !== null && t.cancelAnimationFrame && (t.cancelAnimationFrame(e.frame), e.frame = null);
	}, y = (e, t) => {
		try {
			e.kind === "frame" ? e.run(t ?? 0) : e.run();
		} catch (e) {
			try {
				o(e);
			} catch {}
		}
	}, b = (e, n) => {
		if (u || d || e.removed) return;
		let r = Math.max(0, n);
		e.deadline = g() + r, e.timer = t.setTimeout(() => {
			e.timer = null, !(u || d || e.removed) && (y(e), e.kind === "every" ? (e.deadline = g() + e.interval, b(e, e.interval)) : (e.removed = !0, c.delete(e.id)));
		}, r);
	}, x = (e) => {
		if (u || d || e.removed) return;
		let n = (t) => {
			if (e.frame = null, u || d || e.removed) return;
			let n = e.lastFrameAt;
			e.lastFrameAt = t, y(e, Math.max(0, t - n)), x(e);
		};
		t.requestAnimationFrame && t.cancelAnimationFrame ? e.frame = t.requestAnimationFrame(n) : e.timer = t.setTimeout(() => {
			e.timer = null, n(g());
		}, r);
	}, S = (e) => {
		e.removed = !0, v(e), c.delete(e.id);
	}, C = (e, t, r, i) => {
		if (u) throw Error("The local scheduler has been disposed.");
		if (c.size >= n) throw RangeError(`Local scheduler subscriptions exceed the limit of ${n}.`);
		let a = {
			id: l,
			kind: e,
			interval: t,
			background: r,
			run: i,
			timer: null,
			frame: null,
			deadline: g() + t,
			remaining: t,
			lastFrameAt: g(),
			removed: !1
		};
		return l += 1, c.set(a.id, a), e === "frame" ? x(a) : d || b(a, t), () => S(a);
	}, w = () => {
		if (!(u || d)) {
			d = !0, f = g();
			for (let e of c.values()) v(e), e.kind !== "frame" && e.background === "pause" && (e.remaining = Math.max(0, e.deadline - g()));
		}
	}, T = () => {
		if (!u && d) {
			d = !1, p += Math.max(0, g() - f);
			for (let e of [...c.values()]) e.removed || (e.kind === "frame" ? (e.lastFrameAt = g(), x(e)) : e.background === "pause" ? b(e, e.remaining) : g() >= e.deadline ? (y(e), e.kind === "every" ? (e.deadline = g() + e.interval, b(e, e.interval)) : S(e)) : b(e, e.deadline - g()));
		}
	};
	return t.subscribeVisibility && (h = t.subscribeVisibility((e) => {
		e ? w() : T();
	})), t.isHidden?.() === !0 && w(), Object.freeze({
		now: g,
		activeNow: _,
		get suspended() {
			return d;
		},
		get size() {
			return c.size;
		},
		every(e, t, n) {
			return C("every", Number.isFinite(e) ? Math.max(r, e) : r, n?.background ?? "pause", t);
		},
		after(e, t, n) {
			return C("after", Number.isFinite(e) ? Math.max(0, e) : 0, n?.background ?? "wall-clock", t);
		},
		frame(e) {
			return C("frame", r, "pause", e);
		},
		suspend: w,
		resume: T,
		dispose() {
			if (!u) {
				u = !0;
				for (let e of c.values()) v(e);
				c.clear(), h?.(), h = null;
			}
		}
	});
}
// src/runtime-services/runtime.ts
function l(e) {
	return {
		now: () => e.now(),
		activeNow: () => e.activeNow(),
		get suspended() {
			return e.suspended;
		}
	};
}
function u(e) {
	let i = t(e), a = e.scheduler ?? c(e.schedulerOptions), o = typeof e.randomSeed == "number" && Number.isFinite(e.randomSeed) ? Math.trunc(e.randomSeed) >>> 0 : n(i);
	return Object.freeze({
		documentId: i,
		sourceDigest: e.sourceDigest,
		randomSeed: o,
		clock: l(a),
		scheduler: a,
		state: r({
			documentId: i,
			sourceDigest: e.sourceDigest,
			initial: e.componentState,
			...e.componentStateStorage === void 0 ? {} : { storage: e.componentStateStorage },
			...e.componentStateWriteDelayMs === void 0 ? {} : { writeDelayMs: e.componentStateWriteDelayMs },
			...e.knownStateKeys === void 0 ? {} : { knownKeys: e.knownStateKeys },
			...e.configKey === void 0 ? {} : { configKey: e.configKey },
			...e.legacyConfigKeys === void 0 ? {} : { legacyConfigKeys: e.legacyConfigKeys }
		})
	});
}
function d(t) {
	let n = t?.sourceDigest ?? e(""), r = c({ ports: {
		now: () => 0,
		setTimeout: () => 0,
		clearTimeout: () => {},
		isHidden: () => !1,
		subscribeVisibility: () => () => {}
	} });
	return u({
		...t,
		sourceDigest: n,
		scheduler: r
	});
}
export { u as n, c as r, d as t };
