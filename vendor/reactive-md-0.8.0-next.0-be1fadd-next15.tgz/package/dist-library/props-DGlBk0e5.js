// src/local/theme/colors.ts
var e = /* @__PURE__ */ new Set(/* @__PURE__ */ "aliceblue.antiquewhite.aqua.aquamarine.azure.beige.bisque.black.blanchedalmond.blue.blueviolet.brown.burlywood.cadetblue.chartreuse.chocolate.coral.cornflowerblue.cornsilk.crimson.cyan.darkblue.darkcyan.darkgoldenrod.darkgray.darkgreen.darkgrey.darkkhaki.darkmagenta.darkolivegreen.darkorange.darkorchid.darkred.darksalmon.darkseagreen.darkslateblue.darkslategray.darkslategrey.darkturquoise.darkviolet.deeppink.deepskyblue.dimgray.dimgrey.dodgerblue.firebrick.floralwhite.forestgreen.fuchsia.gainsboro.ghostwhite.gold.goldenrod.gray.green.greenyellow.grey.honeydew.hotpink.indianred.indigo.ivory.khaki.lavender.lavenderblush.lawngreen.lemonchiffon.lightblue.lightcoral.lightcyan.lightgoldenrodyellow.lightgray.lightgreen.lightgrey.lightpink.lightsalmon.lightseagreen.lightskyblue.lightslategray.lightslategrey.lightsteelblue.lightyellow.lime.limegreen.linen.magenta.maroon.mediumaquamarine.mediumblue.mediumorchid.mediumpurple.mediumseagreen.mediumslateblue.mediumspringgreen.mediumturquoise.mediumvioletred.midnightblue.mintcream.mistyrose.moccasin.navajowhite.navy.oldlace.olive.olivedrab.orange.orangered.orchid.palegoldenrod.palegreen.paleturquoise.palevioletred.papayawhip.peachpuff.peru.pink.plum.powderblue.purple.rebeccapurple.red.rosybrown.royalblue.saddlebrown.salmon.sandybrown.seagreen.seashell.sienna.silver.skyblue.slateblue.slategray.slategrey.snow.springgreen.steelblue.tan.teal.thistle.tomato.turquoise.violet.wheat.white.whitesmoke.yellow.yellowgreen".split(".")), t = /^#(?:[0-9A-Fa-f]{3}|[0-9A-Fa-f]{6})$/;
function n(n) {
	return typeof n == "string" ? t.test(n) || e.has(n.toLowerCase()) : !1;
}
// src/sdk/props.ts
var r = /^[+-]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?$/;
function i(e) {
	let t = /* @__PURE__ */ new Set();
	for (let n of Object.values(e.bindings ?? {})) t.add(n.bind), t.add(n.initial);
	return t;
}
function a(e) {
	let t = e.trim();
	if (!r.test(t)) return null;
	let n = Number(t);
	return Number.isFinite(n) ? n : null;
}
function o(e) {
	for (let t = 0; t < e.length - 1; t += 1) if (e[t] === "\\") t += 1;
	else if (e[t] === "{" && e[t + 1] === "{") return !0;
	return !1;
}
function s(e) {
	let t = e.trim();
	if (t.length < 5 || !t.startsWith("{{") || !t.endsWith("}}")) return null;
	let n = t.slice(2, -2);
	if (n.includes("{{") || n.includes("}}")) return null;
	let r = n.trim();
	return r === "" ? null : r;
}
function c(e, t, n) {
	return /* @__PURE__ */ Error(`Local component <${e.name}> prop "${t}" ${n}`);
}
function l(e, t, n, r) {
	try {
		return r.evaluate(n);
	} catch (n) {
		throw c(e, t, `expression failed: ${n instanceof Error ? n.message : String(n)}`);
	}
}
function u(e, t, n, r) {
	if (!Number.isFinite(r)) throw c(e, t, "must be a finite number.");
	if (n.integer === !0 && !Number.isInteger(r)) throw c(e, t, "must be an integer.");
	if (n.positive === !0 && !(r > 0)) throw c(e, t, "must be greater than zero.");
	if (n.min !== void 0 && r < n.min) throw c(e, t, `must be at least ${n.min}.`);
	if (n.max !== void 0 && r > n.max) throw c(e, t, `must be at most ${n.max}.`);
	return r;
}
function d(e, t, n, r) {
	if (n.pattern === void 0) return r;
	let i = !0;
	try {
		i = new RegExp(n.pattern).test(r);
	} catch {
		i = !1;
	}
	if (!i) throw c(e, t, `must match pattern ${n.pattern}.`);
	return r;
}
function f(e, t, n, r) {
	let i = n.enum ?? [];
	if (!i.includes(r)) throw c(e, t, `must be one of ${i.join(" / ")}, got "${r}".`);
	return r;
}
function p(e, t, r, i) {
	if (r.color === !0 && i !== "" && !n(i)) throw c(e, t, `must be a standard CSS named color or #RGB/#RRGGBB, got "${i}".`);
	return i;
}
function m(e, t, n, r) {
	return n.kind === "enum" ? p(e, t, n, f(e, t, n, r)) : p(e, t, n, d(e, t, n, r));
}
function h(e, t, n, r, i) {
	if (r === void 0) {
		if (n.required === !0 && n.default === void 0) throw c(e, t, "is required but was not provided.");
		if (n.default !== void 0) {
			if (n.default === null) return null;
			if (n.kind === "number") return u(e, t, n, n.default);
			if (n.kind === "boolean") return n.default;
			let r = n.default;
			return m(e, t, n, r);
		}
		return null;
	}
	let d = o(r);
	if (d) {
		if (n.static === !0) throw c(e, t, "is static and cannot contain interpolations.");
		if (n.dynamic === !1) throw c(e, t, "does not accept interpolations.");
	}
	let f = s(r);
	if (n.kind === "string" || n.kind === "enum") {
		let a;
		if (f !== null) {
			let r = l(e, t, f, i);
			if (n.coerce === "text" && n.kind === "string") {
				if (r === null) a = "";
				else if (typeof r == "string") a = r;
				else if (typeof r == "number" || typeof r == "boolean") a = String(r);
				else throw c(e, t, `expected a scalar, got ${typeof r}.`);
			} else {
				if (typeof r != "string") throw c(e, t, `expected a string, got ${typeof r}.`);
				a = r;
			}
			return m(e, t, n, a);
		}
		return d ? (a = i.text(r), m(e, t, n, a)) : m(e, t, n, r);
	}
	if (n.kind === "number") {
		if (f !== null) {
			let r = l(e, t, f, i);
			if (typeof r != "number" || !Number.isFinite(r)) throw c(e, t, "expected a finite number.");
			return u(e, t, n, r);
		}
		if (d) throw c(e, t, "requires a number literal or one full numeric interpolation.");
		let o = a(r);
		if (o === null) throw c(e, t, `requires a number, got "${r}".`);
		return u(e, t, n, o);
	}
	if (f !== null) {
		let n = l(e, t, f, i);
		if (typeof n != "boolean") throw c(e, t, "expected a boolean.");
		return n;
	}
	if (d) throw c(e, t, "requires true, false, or one full boolean interpolation.");
	let p = r.trim();
	if (p === "true") return !0;
	if (p === "false") return !1;
	throw c(e, t, `requires true or false, got "${r}".`);
}
function g(e, t, n) {
	if (!e || typeof e != "object") throw TypeError("resolveLocalComponentProps requires a component definition.");
	if (!t || typeof t != "object" || Array.isArray(t)) throw TypeError(`Local component <${e.name}> attributes must be an object.`);
	let r = i(e);
	for (let n of Object.keys(t)) if (!r.has(n) && !Object.hasOwn(e.props, n)) throw Error(`Local component <${e.name}> does not declare attribute "${n}".`);
	let a = {};
	for (let r of Object.keys(e.props)) a[r] = _(e, r, Object.hasOwn(t, r) && typeof t[r] == "string" ? t[r] : void 0, n);
	return Object.freeze(a);
}
function _(e, t, n, r) {
	let i = e.props[t];
	if (!i) throw c(e, t, "is not declared.");
	return e.rules?.some((e) => e.kind === "scoped-expressions" && e.attributes.includes(t) || e.kind === "row-values" && (e.rows === t || e.key === t)) && n !== void 0 && i.kind === "string" ? n : h(e, t, i, n, r);
}
function v(e, t, n) {
	if (n === void 0) return;
	if ("literal" in n) return n.literal;
	let r = e.props[n.prop];
	if (r === void 0 || r.kind !== "number") return;
	let i = Object.hasOwn(t, n.prop) ? t[n.prop] : void 0;
	return typeof i == "string" ? o(i) ? void 0 : a(i) ?? void 0 : typeof r.default == "number" ? r.default : void 0;
}
function y(e, t) {
	let n = e.bindings?.value;
	if (n === void 0 || n.kind !== "number") return {};
	let r = n.constraints;
	if (r === void 0) return {};
	let i = v(e, t, r.min), a = v(e, t, r.max), o = v(e, t, r.step);
	return {
		...i === void 0 ? {} : { min: i },
		...a === void 0 ? {} : { max: a },
		...o !== void 0 && o > 0 ? { step: o } : {}
	};
}
function b(e) {
	let t = e.bindings?.value;
	if (t === void 0 || t.kind !== "number" && t.kind !== "string" && t.kind !== "boolean") return;
	let n = [
		"empty",
		"false",
		"first-option",
		"min",
		"nearest-zero"
	].find((e) => e === t.initialRule), r = t.constraints, i = (e) => e !== void 0 && "literal" in e ? e.literal : void 0, a = i(r?.min), o = i(r?.max), s = i(r?.step);
	return {
		kind: t.kind,
		...n ? { initialRule: n } : {},
		...t.options ? { options: [...t.options] } : {},
		...a === void 0 ? {} : { min: a },
		...o === void 0 ? {} : { max: o },
		...t.kind === "number" ? { step: s ?? 1 } : {}
	};
}
export { g as a, _ as i, b as n, n as o, y as r, i as t };
