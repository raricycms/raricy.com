import { A as e, D as t, F as n, G as r, H as i, M as a, O as o, P as s, Q as c, W as l, a as u, i as d, j as f, ot as ee, q as p, rt as te, z as m } from "./identity-MYJXKSkB.js";
// src/local/configuration/diagnostic-messages.ts
var h = {
	"local.version.unsupported": {
		en: "This reader accepts {supported}; migrate {declared} or use a compatible reader.",
		zh: "此阅读器支持 {supported}；请迁移 {declared} 或使用兼容的阅读器。"
	},
	"local.version.malformed": {
		en: "Use <!-- reactive-md: local-draft-3 --> on one line.",
		zh: "请在单独一行使用 <!-- reactive-md: local-draft-3 -->。"
	},
	"local.version.duplicate": {
		en: "Only one source syntax declaration is allowed.",
		zh: "源码只能声明一次语法版本。"
	},
	"local.version.placement": {
		en: "The syntax declaration must be on its own line before the theme and document body.",
		zh: "语法版本声明必须独占一行，位于主题声明和正文之前。"
	},
	"local.upgrade.from-version": {
		en: "Cannot migrate from {from}: {detail}.",
		zh: "无法从 {from} 迁移：{detail}。"
	},
	"local.upgrade.reserved-binding": {
		en: "Binding {name} becomes reserved in local-draft-2; rename it with a compatible old editor before migration.",
		zh: "绑定 {name} 在 local-draft-2 中成为保留名；迁移前请用兼容旧版本的编辑器重命名。"
	},
	"local.upgrade.tag": {
		en: "Tag {name} was inert in the older revision and becomes active in a newer one; preserve it as literal code before migration.",
		zh: "标签 {name} 在旧版本中不执行，在较新版本中会激活；迁移前请将其保留为代码原文。"
	},
	"local.upgrade.text-length": {
		en: "Text length constraints change from UTF-16 units to Unicode code points; explicitly accept this semantic change before migration.",
		zh: "文本长度约束从 UTF-16 单元改为 Unicode 码点计数；迁移前须明确接受这一语义变化。"
	},
	"local.upgrade.expression": {
		en: "This expression uses array syntax or a function introduced in local-draft-2; it is outside automatic draft-1 migration.",
		zh: "此表达式使用了 local-draft-2 新增的数组语法或函数，不属于 draft-1 自动迁移范围。"
	},
	"local.upgrade.version-missing": {
		en: "The source has no syntax declaration; migration will pin {version}.",
		zh: "源码尚未声明语法版本；迁移将固定为 {version}。"
	},
	"capability.html": {
		en: "This compiler assembly does not include the native HTML document branch.",
		zh: "当前编译器装配不包含原生 HTML 文档分支。"
	},
	"capability.plot": {
		en: "This compiler assembly does not include plot formula support.",
		zh: "当前编译器装配不包含绘图公式支持。"
	},
	"parse.sourceType": {
		en: "Document source must be a string.",
		zh: "文档源必须是字符串。"
	},
	"parse.markdownFailed": {
		en: "Cannot parse the Markdown document.",
		zh: "无法解析 Markdown 文档。"
	},
	"parse.failed": {
		en: "Cannot parse document: {detail}",
		zh: "无法解析文档：{detail}"
	},
	"budget.document": {
		en: "Document exceeds the {limit}-character limit.",
		zh: "文档超过 {limit} 个字符的上限。"
	},
	"budget.syntaxNodes": {
		en: "Syntax nodes exceed the limit of {limit}.",
		zh: "语法节点数量超过上限 {limit}。"
	},
	"budget.parseWork": {
		en: "Parsing work exceeds the limit of {limit}.",
		zh: "解析工作量超过上限 {limit}。"
	},
	"budget.markdownDepth": {
		en: "Markdown nesting exceeds the {limit}-level limit.",
		zh: "Markdown 嵌套超过 {limit} 层上限。"
	},
	"budget.nesting": {
		en: "Component nesting exceeds the {limit}-level limit.",
		zh: "组件嵌套超过 {limit} 层上限。"
	},
	"options.notObject": {
		en: "Compile options must be an object.",
		zh: "编译选项必须是对象。"
	},
	"options.limitsNotObject": {
		en: "Compile option limits must be an object.",
		zh: "编译选项 limits 必须是对象。"
	},
	"options.maxSyntaxNodes": {
		en: "Compile option limits.maxSyntaxNodes must be a positive safe integer.",
		zh: "编译选项 limits.maxSyntaxNodes 必须是正安全整数。"
	},
	"options.maxParseWork": {
		en: "Compile option limits.maxParseWork must be a positive safe integer.",
		zh: "编译选项 limits.maxParseWork 必须是正安全整数。"
	},
	"options.maxMarkdownDepth": {
		en: "Compile option limits.maxMarkdownDepth must be a positive safe integer.",
		zh: "编译选项 limits.maxMarkdownDepth 必须是正安全整数。"
	},
	"options.unknownLimit": {
		en: "Compile option limits.{detail} is not supported.",
		zh: "编译选项 limits.{detail} 不受支持。"
	},
	"options.hostComponents": {
		en: "Compile option hostComponents is invalid: {detail}",
		zh: "编译选项 hostComponents 无效：{detail}"
	},
	"theme.expression": {
		en: "Theme names must be static text, not expressions.",
		zh: "主题名称必须是静态文本，不能是表达式。"
	},
	"theme.nameRequired": {
		en: "A theme declaration requires a quoted name attribute.",
		zh: "主题声明需要一个带引号的 name 属性。"
	},
	"theme.attributeOnly": {
		en: "Theme declarations only accept a quoted name attribute.",
		zh: "主题声明只接受带引号的 name 属性。"
	},
	"theme.nameInvalid": {
		en: "Theme name \"{name}\" must use lowercase letters, digits and single hyphens (maximum {limit} characters).",
		zh: "主题名称“{name}”只能使用小写字母、数字和单个连字符（最多 {limit} 个字符）。"
	},
	"theme.malformedMissingClose": {
		en: "Theme declaration is missing >.",
		zh: "主题声明缺少 >。"
	},
	"theme.malformedClosing": {
		en: "A theme declaration cannot be a closing tag.",
		zh: "主题声明不能是结束标签。"
	},
	"theme.malformedStandalone": {
		en: "A theme declaration must be on its own line before the document content.",
		zh: "主题声明必须单独占一行并位于文档内容之前。"
	},
	"theme.duplicateDeclaration": {
		en: "Only one theme declaration is allowed before the document content; this declaration is ignored.",
		zh: "文档内容之前只允许一个主题声明；此声明将被忽略。"
	},
	"theme.late": {
		en: "Theme declarations after document content are ignored.",
		zh: "文档内容之后的主题声明将被忽略。"
	},
	"theme.nested": {
		en: "Theme declarations inside document content are ignored.",
		zh: "文档内容内部的主题声明将被忽略。"
	},
	"theme.invalidDeclaration": {
		en: "Invalid theme declaration.",
		zh: "无效的主题声明。"
	},
	"attribute.lowercase": {
		en: "Attribute names must use lowercase kebab-case.",
		zh: "属性名必须使用小写 kebab-case。"
	},
	"budget.attributeName": {
		en: "Attribute name exceeds the {limit}-character limit.",
		zh: "属性名超过 {limit} 个字符的上限。"
	},
	"attribute.nameInvalid": {
		en: "Attribute name {name} must use lowercase kebab-case.",
		zh: "属性名 {name} 必须使用小写 kebab-case。"
	},
	"attribute.valueQuoted": {
		en: "Attribute {name} value must be quoted.",
		zh: "属性 {name} 的值必须加引号。"
	},
	"attribute.valueUnclosed": {
		en: "Attribute {name} is missing a closing quote.",
		zh: "属性 {name} 缺少结束引号。"
	},
	"attribute.duplicate": {
		en: "Duplicate attribute {name}.",
		zh: "重复的属性 {name}。"
	},
	"attribute.separator": {
		en: "Attributes must be separated by whitespace.",
		zh: "属性之间必须用空白分隔。"
	},
	"budget.tagName": {
		en: "Tag name exceeds the {limit}-character limit.",
		zh: "标签名超过 {limit} 个字符的上限。"
	},
	"tag.missingClose": {
		en: "Tag {name} is missing >.",
		zh: "标签 {name} 缺少 >。"
	},
	"tag.closingAttributes": {
		en: "Closing tag </{name}> cannot have attributes.",
		zh: "结束标签 </{name}> 不能带属性。"
	},
	"tag.nameInvalid": {
		en: "Tag name {name} must use lowercase kebab-case.",
		zh: "标签名 {name} 必须使用小写 kebab-case。"
	},
	"tag.unclosedPaired": {
		en: "<{name}> is missing </{name}>.",
		zh: "<{name}> 缺少 </{name}>。"
	},
	"tag.mismatchRoot": {
		en: "Closing tag </{name}> does not match the document root.",
		zh: "结束标签 </{name}> 与文档根不匹配。"
	},
	"tag.mismatchParent": {
		en: "Closing tag </{name}> does not match <{parent}>.",
		zh: "结束标签 </{name}> 与 <{parent}> 不匹配。"
	},
	"tag.requiresClose": {
		en: "<{name}> requires a closing tag.",
		zh: "<{name}> 需要结束标签。"
	},
	"footnote.unsupported": {
		en: "Footnotes are not part of the local interaction syntax and are shown as source.",
		zh: "脚注不属于本地交互语法，将按源文本显示。"
	},
	"interpolation.unclosed": {
		en: "Interpolation is missing }}.",
		zh: "插值缺少 }}。"
	},
	"math.unclosed": {
		en: "Formula is missing its closing delimiter.",
		zh: "公式缺少结束定界符。"
	},
	"math.whitespace": {
		en: "Inline math cannot start or end with whitespace.",
		zh: "行内公式不能以空白开头或结尾。"
	},
	"budget.math": {
		en: "Formula exceeds the {limit}-character limit.",
		zh: "公式超过 {limit} 个字符的上限。"
	},
	"html.raw": {
		en: "Raw HTML is not part of the local interaction syntax.",
		zh: "原始 HTML 不属于本地交互语法。"
	},
	"html.fallback": {
		en: "Native HTML was safely converted to inert source text.",
		zh: "原生 HTML 已安全回退为惰性源码文本。"
	},
	"html.fallbackAttribute": {
		en: "Native HTML attribute {name} is unsupported; the element was safely converted to inert source text.",
		zh: "原生 HTML 属性 {name} 不受支持；该元素已安全回退为惰性源码文本。"
	},
	"html.table.structure": {
		en: "Invalid native HTML table structure in <{tag}>.",
		zh: "原生 HTML 表格的 <{tag}> 结构无效。"
	},
	"html.table.mixed": {
		en: "Keep text and Markdown inside cells or captions; native HTML table structure cannot mix with Markdown table rows.",
		zh: "文字和 Markdown 应写在单元格或标题内；原生 HTML 表格结构不能混用 Markdown 表格行。"
	},
	"html.table.attribute": {
		en: "Attribute {name} is not supported on native HTML <{tag}>. ReactiveMD table options require a Markdown table body.",
		zh: "原生 HTML <{tag}> 不支持属性 {name}。ReactiveMD 表格选项只适用于 Markdown 表格正文。"
	},
	"html.table.value": {
		en: "Invalid value for {name} on native HTML <{tag}>.",
		zh: "原生 HTML <{tag}> 的 {name} 属性值无效。"
	},
	"html.table.unclosed": {
		en: "Native HTML table is missing </table>.",
		zh: "原生 HTML 表格缺少 </table>。"
	},
	"html.extended": {
		en: "HTML element <{name}> requires enableExtendedHtml in this mode; it is shown as source.",
		zh: "此模式下 HTML 元素 <{name}> 需要启用 enableExtendedHtml；已按源码显示。"
	},
	"html.attribute": {
		en: "HTML attribute {name} on <{tag}> is not supported; the element is shown as source.",
		zh: "<{tag}> 上的 HTML 属性 {name} 不受支持；该元素已按源码显示。"
	},
	"html.unsafeUrl": {
		en: "Unsafe URL in attribute {name} was removed.",
		zh: "属性 {name} 中的不安全 URL 已移除。"
	},
	"html.capability": {
		en: "Author {feature} was disabled by the compile options.",
		zh: "编译选项已禁用作者提供的{feature}。"
	},
	"recovery.unclosed": {
		en: "An unclosed RMD fragment was rendered as literal source; its components and expressions are inactive.",
		zh: "未闭合的 RMD 片段已按原文显示，片段中的组件和表达式不执行。"
	},
	"recovery.mismatch": {
		en: "A fragment with mismatched tags was rendered as literal source; its components and expressions are inactive.",
		zh: "标签不匹配的片段已按原文显示，片段中的组件和表达式不执行。"
	},
	"recovery.strayClose": {
		en: "A stray closing tag was rendered as literal source.",
		zh: "孤立的结束标签已按原文显示。"
	},
	"recovery.htmlRepair": {
		en: "Malformed native HTML was structurally repaired for display.",
		zh: "HTML 结构已修复后显示。"
	},
	"recovery.htmlLiteral": {
		en: "Native HTML could not be safely repaired and was rendered as literal source.",
		zh: "HTML 片段无法安全恢复，已按原文显示。"
	},
	"options.htmlFlag": {
		en: "Compile option {name} must be a boolean.",
		zh: "编译选项 {name} 必须是布尔值。"
	},
	"options.markdownBreaks": {
		en: "Compile option markdownBreaks must be a boolean.",
		zh: "编译选项 markdownBreaks 必须为布尔值。"
	},
	"options.strict": {
		en: "Compile option strict must be a boolean.",
		zh: "编译选项 strict 必须为布尔值。"
	},
	"component.unknownSuggestion": {
		en: "Unknown component <{name}>. Did you mean <{suggestion}>?",
		zh: "未知组件 <{name}>。是否想使用 <{suggestion}>？"
	},
	"component.unknownPlain": {
		en: "Unknown component <{name}>. This mode only accepts local interaction components.",
		zh: "未知组件 <{name}>。此模式只接受本地交互组件。"
	},
	"legacy.fence": {
		en: "Legacy reactive-md configuration fences (state/data/computed/actions, etc.) are not part of the local interaction syntax; select legacy mode explicitly in the host.",
		zh: "旧版 reactive-md 配置围栏（state/data/computed/actions 等）不属于本地交互语法；请在宿主中显式选择旧版模式。"
	},
	"attribute.unknownSuggestion": {
		en: "Component <{component}> does not support attribute {name}. Did you mean {suggestion}?",
		zh: "组件 <{component}> 不支持属性 {name}。是否想使用 {suggestion}？"
	},
	"attribute.unknownPlain": {
		en: "Component <{component}> does not support attribute {name}.",
		zh: "组件 <{component}> 不支持属性 {name}。"
	},
	"budget.attribute": {
		en: "Attribute {name} on component <{component}> exceeds the {limit}-character limit.",
		zh: "组件 <{component}> 的属性 {name} 超过 {limit} 个字符的上限。"
	},
	"attribute.color": {
		en: "Attribute {name} on component <{component}> must be a standard CSS named color or #RGB/#RRGGBB, got \"{value}\".",
		zh: "组件 <{component}> 的属性 {name} 必须是标准 CSS 命名颜色或 #RGB/#RRGGBB，当前为“{value}”。"
	},
	"attribute.required": {
		en: "Component <{component}> is missing required attribute {name}.",
		zh: "组件 <{component}> 缺少必需属性 {name}。"
	},
	"label.requiredMissing": {
		en: "Component <{name}> requires a label.",
		zh: "组件 <{name}> 需要 label。"
	},
	"label.requiredEmpty": {
		en: "Component <{name}> label cannot be empty.",
		zh: "组件 <{name}> 的 label 不能为空。"
	},
	"attribute.static": {
		en: "Attribute {name} is static and cannot contain interpolations.",
		zh: "属性 {name} 是静态的，不能包含插值。"
	},
	"host.attributeUnknown": {
		en: "Component <{component}> does not support attribute {name}.",
		zh: "组件 <{component}> 不支持属性 {name}。"
	},
	"host.attributeRequired": {
		en: "Component <{component}> is missing required attribute {name}.",
		zh: "组件 <{component}> 缺少必需属性 {name}。"
	},
	"host.attributeStatic": {
		en: "Attribute {name} is static and cannot contain interpolations.",
		zh: "属性 {name} 是静态的，不能包含插值。"
	},
	"host.attributeType": {
		en: "Attribute {name} requires a {kind}, got \"{value}\".",
		zh: "属性 {name} 需要 {kind}，当前为“{value}”。"
	},
	"host.attributeEnum": {
		en: "Attribute {name} must be one of {values}, got \"{value}\".",
		zh: "属性 {name} 必须是 {values} 之一，当前为“{value}”。"
	},
	"host.attributePattern": {
		en: "Attribute {name} must match pattern {pattern}.",
		zh: "属性 {name} 必须匹配模式 {pattern}。"
	},
	"host.attributeInterpolation": {
		en: "Attribute {name} must be a literal matching {pattern} or one full interpolation.",
		zh: "属性 {name} 必须是匹配 {pattern} 的字面值，或一个完整插值。"
	},
	"expression.emptyAttribute": {
		en: "Attribute {name} interpolation cannot be empty.",
		zh: "属性 {name} 的插值不能为空。"
	},
	"expression.emptyInterpolation": {
		en: "Interpolation expression cannot be empty.",
		zh: "插值表达式不能为空。"
	},
	"attribute.numberInvalid": {
		en: "Attribute {name} requires a number, got \"{value}\".",
		zh: "属性 {name} 需要数字，当前为“{value}”。"
	},
	"attribute.numberInterpolationInvalid": {
		en: "Attribute {name} requires a number or a full number interpolation, got \"{value}\".",
		zh: "属性 {name} 需要数字或完整的数字插值，当前为“{value}”。"
	},
	"attribute.integer": {
		en: "Attribute {name} requires an integer.",
		zh: "属性 {name} 需要整数。"
	},
	"attribute.positive": {
		en: "Attribute {name} requires a positive number.",
		zh: "属性 {name} 需要正数。"
	},
	"attribute.rangeMin": {
		en: "Attribute {name} must be at least {min}.",
		zh: "属性 {name} 必须至少为 {min}。"
	},
	"attribute.rangeMax": {
		en: "Attribute {name} must be at most {max}.",
		zh: "属性 {name} 必须至多为 {max}。"
	},
	"attribute.booleanInvalid": {
		en: "Attribute {name} requires true or false.",
		zh: "属性 {name} 需要 true 或 false。"
	},
	"attribute.booleanInterpolationInvalid": {
		en: "Attribute {name} requires true or false, or a full boolean interpolation.",
		zh: "属性 {name} 需要 true 或 false，或完整的布尔插值。"
	},
	"attribute.enumInvalid": {
		en: "Attribute {name} must be one of {values}, got \"{value}\".",
		zh: "属性 {name} 必须是 {values} 之一，当前为“{value}”。"
	},
	"attribute.dateLower": {
		en: "Date lower bound {value} is not a valid YYYY-MM-DD.",
		zh: "日期下界 {value} 不是有效的 YYYY-MM-DD。"
	},
	"attribute.dateUpper": {
		en: "Date upper bound {value} is not a valid YYYY-MM-DD.",
		zh: "日期上界 {value} 不是有效的 YYYY-MM-DD。"
	},
	"constraint.componentMinMax": {
		en: "Component <{name}> min cannot exceed max.",
		zh: "组件 <{name}> 的 min 不能大于 max。"
	},
	"constraint.componentStep": {
		en: "Component <{name}> step must be greater than 0.",
		zh: "组件 <{name}> 的 step 必须大于 0。"
	},
	"constraint.lengthRange": {
		en: "max-length cannot be less than min-length.",
		zh: "max-length 不能小于 min-length。"
	},
	"constraint.dateOrder": {
		en: "Date min cannot be later than max.",
		zh: "日期 min 不能晚于 max。"
	},
	"constraint.progressRange": {
		en: "progress value must be between 0 and {max}, got {value}.",
		zh: "progress 的 value 必须在 0 到 {max} 之间，当前为 {value}。"
	},
	"constraint.plotRange": {
		en: "plot min must be less than max.",
		zh: "plot 的 min 必须小于 max。"
	},
	"constraint.timerDuration": {
		en: "timer duration must be a positive whole number of seconds.",
		zh: "timer 的 duration 必须是正整数秒。"
	},
	"constraint.rangeSliderOrder": {
		en: "range-slider min cannot exceed max.",
		zh: "range-slider 的 min 不能大于 max。"
	},
	"constraint.rangeSliderStep": {
		en: "range-slider step must be a finite positive number.",
		zh: "range-slider 的 step 必须是有限正数。"
	},
	"constraint.coordinateOrder": {
		en: "coordinate {axis}-min cannot exceed {axis}-max.",
		zh: "coordinate 的 {axis}-min 不能大于 {axis}-max。"
	},
	"constraint.coordinateStep": {
		en: "coordinate step must be a finite positive number.",
		zh: "coordinate 的 step 必须是有限正数。"
	},
	"constraint.multiSelectMax": {
		en: "multi-select max-selected must be a nonnegative whole number.",
		zh: "multi-select 的 max-selected 必须是非负整数。"
	},
	"constraint.quizTolerance": {
		en: "<quiz> tolerance must be a nonnegative finite number.",
		zh: "<quiz> 的 tolerance 必须是非负有限数。"
	},
	"selection.keyNeedsKey": {
		en: "<{component}> {name} requires a key attribute naming the selection column.",
		zh: "<{component}> 的 {name} 需要 key 属性来指定选择列。"
	},
	"structure.parent": {
		en: "<{name}> can only appear directly inside {parents}.",
		zh: "<{name}> 只能直接位于 {parents} 内。"
	},
	"structure.noBody": {
		en: "<{name}> does not accept body content.",
		zh: "<{name}> 不接受正文内容。"
	},
	"structure.inlineOnly": {
		en: "<{name}> only accepts inline Markdown.",
		zh: "<{name}> 只接受行内 Markdown。"
	},
	"structure.noNestedComponents": {
		en: "The body of <{name}> cannot contain other interactive components.",
		zh: "<{name}> 的正文不能包含其他交互组件。"
	},
	"structure.noComponents": {
		en: "The body of <{name}> cannot contain interactive components.",
		zh: "<{name}> 的正文不能包含交互组件。"
	},
	"structure.childrenMinimum": {
		en: "<{name}> requires at least {min} {children}.",
		zh: "<{name}> 至少需要 {min} 个 {children}。"
	},
	"structure.childrenOnly": {
		en: "Direct children of <{name}> must be {children}.",
		zh: "<{name}> 的直接子元素必须是 {children}。"
	},
	"structure.sequenceMinimum": {
		en: "<{name}> requires at least one <{child}>.",
		zh: "<{name}> 至少需要一个 <{child}>。"
	},
	"structure.sequenceOnly": {
		en: "<{name}> can only contain <{child}>.",
		zh: "<{name}> 只能包含 <{child}>。"
	},
	"structure.accordionNeedsDisclosure": {
		en: "<accordion> requires at least one <disclosure>.",
		zh: "<accordion> 至少需要一个 <disclosure>。"
	},
	"structure.accordionOnly": {
		en: "<accordion> can only contain <disclosure>.",
		zh: "<accordion> 只能包含 <disclosure>。"
	},
	"structure.gridNeedsCard": {
		en: "<grid> requires at least one <card>.",
		zh: "<grid> 至少需要一个 <card>。"
	},
	"structure.gridOnlyCard": {
		en: "Direct children of <grid> must be <card>.",
		zh: "<grid> 的直接子元素必须是 <card>。"
	},
	"structure.exactlyOneTable": {
		en: "The body of <{name}> must be exactly one Markdown table.",
		zh: "<{name}> 的正文必须恰好是一个 Markdown 表格。"
	},
	"structure.plotNeedsFormula": {
		en: "<plot> requires at least one $$...$$ formula block.",
		zh: "<plot> 至少需要一个 $$...$$ 公式块。"
	},
	"structure.plotOnlyFormulas": {
		en: "The body of <plot> can only contain blank lines and $$...$$ formula blocks.",
		zh: "<plot> 的正文只能包含空行和 $$...$$ 公式块。"
	},
	"structure.nodeNoComponents": {
		en: "The description of <node> cannot contain interactive components.",
		zh: "<node> 的描述不能包含交互组件。"
	},
	"structure.optionsNeeded": {
		en: "<{name}> requires at least one <option value=\"...\">.",
		zh: "<{name}> 至少需要一个 <option value=\"...\">。"
	},
	"structure.optionsOnly": {
		en: "<{name}> can only contain <option>.",
		zh: "<{name}> 只能包含 <option>。"
	},
	"budget.options": {
		en: "<{name}> options exceed the limit of {limit}.",
		zh: "<{name}> 的选项数量超过上限 {limit}。"
	},
	"option.valueRequired": {
		en: "<option> requires a non-empty value.",
		zh: "<option> 需要非空 value。"
	},
	"option.valueComma": {
		en: "<multi-select> option values cannot contain commas: \"{value}\".",
		zh: "<multi-select> 的选项值不能包含逗号：“{value}”。"
	},
	"option.valueDuplicate": {
		en: "Option values in <{name}> must be unique; duplicate value \"{value}\".",
		zh: "<{name}> 的选项值必须唯一；重复值“{value}”。"
	},
	"structure.optionNoComponents": {
		en: "The body of <option> cannot contain interactive components.",
		zh: "<option> 的正文不能包含交互组件。"
	},
	"structure.tabsNeedsTab": {
		en: "<tabs> requires at least one <tab>.",
		zh: "<tabs> 至少需要一个 <tab>。"
	},
	"structure.tabsOnly": {
		en: "<tabs> can only contain <tab>.",
		zh: "<tabs> 只能包含 <tab>。"
	},
	"tab.valueDuplicate": {
		en: "Tab values in <tabs> must be unique; duplicate value \"{value}\".",
		zh: "<tabs> 的标签值必须唯一；重复值“{value}”。"
	},
	"structure.stepsNeedsStep": {
		en: "<steps> requires at least one <step>.",
		zh: "<steps> 至少需要一个 <step>。"
	},
	"structure.stepsOnly": {
		en: "<steps> can only contain <step>.",
		zh: "<steps> 只能包含 <step>。"
	},
	"step.valueDuplicate": {
		en: "Step values in <steps> must be unique; duplicate value \"{value}\".",
		zh: "<steps> 的步骤值必须唯一；重复值“{value}”。"
	},
	"quiz.answerRequired": {
		en: "<quiz> requires a non-empty answer.",
		zh: "<quiz> 需要非空 answer。"
	},
	"structure.quizNumericNoBody": {
		en: "A numeric <quiz> cannot have body content; use type=\"choice\" for option-based quizzes.",
		zh: "数值型 <quiz> 不能有正文内容；基于选项的测验请使用 type=\"choice\"。"
	},
	"quiz.answerNumeric": {
		en: "A numeric <quiz> answer must be a finite number.",
		zh: "数值型 <quiz> 的 answer 必须是有限数字。"
	},
	"quiz.answerNotOption": {
		en: "<quiz> answer \"{answer}\" is not one of the option values: {options}.",
		zh: "<quiz> 的 answer“{answer}”不在选项值中：{options}。"
	},
	"diagram.needsNode": {
		en: "<diagram> requires at least one <node>.",
		zh: "<diagram> 至少需要一个 <node>。"
	},
	"structure.diagramOnly": {
		en: "<diagram> can only contain <node> and <edge>.",
		zh: "<diagram> 只能包含 <node> 和 <edge>。"
	},
	"diagram.nodeInvalid": {
		en: "Node ID \"{id}\" may only contain letters, digits, underscores and hyphens, and cannot start with a digit.",
		zh: "节点 ID“{id}”只能包含字母、数字、下划线和连字符，且不能以数字开头。"
	},
	"diagram.nodeDuplicate": {
		en: "Duplicate node ID \"{id}\".",
		zh: "重复的节点 ID“{id}”。"
	},
	"diagram.edgeFromUnknown": {
		en: "Edge from references unknown node \"{id}\".",
		zh: "连线起点引用了未知节点“{id}”。"
	},
	"diagram.edgeToUnknown": {
		en: "Edge to references unknown node \"{id}\".",
		zh: "连线终点引用了未知节点“{id}”。"
	},
	"diagram.edgeDuplicate": {
		en: "Duplicate edge: {from} → {to}{label}.",
		zh: "重复的连线：{from} → {to}{label}。"
	},
	"checklist.bodySingle": {
		en: "The body of <checklist> must be exactly one single-level Markdown task list.",
		zh: "<checklist> 的正文必须恰好是一个单层 Markdown 任务列表。"
	},
	"checklist.needsItem": {
		en: "<checklist> requires at least one task list item.",
		zh: "<checklist> 至少需要一个任务列表项。"
	},
	"budget.checklistItems": {
		en: "<checklist> items exceed the limit of {limit}.",
		zh: "<checklist> 的任务项数量超过上限 {limit}。"
	},
	"checklist.taskOnly": {
		en: "<checklist> can only contain task list items (- [ ] / - [x]).",
		zh: "<checklist> 只能包含任务列表项（- [ ] / - [x]）。"
	},
	"checklist.noNested": {
		en: "<checklist> does not support nested lists.",
		zh: "<checklist> 不支持嵌套列表。"
	},
	"checklist.noComponents": {
		en: "<checklist> items cannot contain interactive components.",
		zh: "<checklist> 的任务项不能包含交互组件。"
	},
	"budget.identifier": {
		en: "Parameter name exceeds the {limit}-character limit.",
		zh: "参数名超过 {limit} 个字符的上限。"
	},
	"binding.nameInvalid": {
		en: "Parameter name \"{name}\" must match [A-Za-z_][A-Za-z0-9_]*.",
		zh: "参数名“{name}”必须匹配 [A-Za-z_][A-Za-z0-9_]*。"
	},
	"binding.reserved": {
		en: "Parameter name \"{name}\" is reserved; choose another name.",
		zh: "参数名“{name}”是保留名称；请换一个名称。"
	},
	"binding.typeConflict": {
		en: "Parameter \"{key}\" is already declared as {kind} by <{first}> and cannot also bind <{second}>.",
		zh: "参数“{key}”已由 <{first}> 声明为 {kind}，不能再绑定 <{second}>。"
	},
	"binding.exclusive": {
		en: "Parameter \"{key}\" of <{first}> can only be owned by one component and cannot be shared with <{second}>.",
		zh: "<{first}> 的参数“{key}”只能由一个组件拥有，不能与 <{second}> 共享。"
	},
	"binding.slotExclusive": {
		en: "Parameter \"{key}\" of the {slot} slot of <{name}> is exclusive and cannot be shared with another control.",
		zh: "<{name}> 的 {slot} 槽参数“{key}”是独占的，不能与另一个控件共享。"
	},
	"binding.constraintConflict": {
		en: "Parameter \"{key}\" must use the same numeric range and step: <{first}> has {firstConstraints}, <{second}> has {secondConstraints}.",
		zh: "参数“{key}”必须使用相同的数值范围和步长：<{first}> 为 {firstConstraints}，<{second}> 为 {secondConstraints}。"
	},
	"binding.optionConflict": {
		en: "Parameter \"{key}\" must use the same option set in the same order.",
		zh: "参数“{key}”必须使用相同顺序的同一组选项。"
	},
	"initial.duplicate": {
		en: "Parameter \"{key}\" has multiple explicit initial values ({count} in total).",
		zh: "参数“{key}”有多个显式初值（共 {count} 个）。"
	},
	"initial.duplicatePeers": {
		en: "Parameter \"{key}\" has multiple explicit initial values ({count} in total; see also line {lines}).",
		zh: "参数“{key}”有多个显式初值（共 {count} 个；另见第 {lines} 行）。"
	},
	"initial.rangeNoStep": {
		en: "Parameter \"{key}\" has no valid step value within range [{min}, {max}].",
		zh: "参数“{key}”在范围 [{min}, {max}] 内没有有效的步长值。"
	},
	"initial.cannotDerive": {
		en: "Cannot derive a default initial value for <{name}> parameter \"{key}\".",
		zh: "无法为 <{name}> 的参数“{key}”推导默认初值。"
	},
	"initial.typeFiniteNumber": {
		en: "Initial value of parameter \"{key}\" must be a finite number.",
		zh: "参数“{key}”的初值必须是有限数字。"
	},
	"initial.belowMin": {
		en: "Initial value {value} of parameter \"{key}\" is below the minimum {min}.",
		zh: "参数“{key}”的初值 {value} 小于最小值 {min}。"
	},
	"initial.aboveMax": {
		en: "Initial value {value} of parameter \"{key}\" exceeds the maximum {max}.",
		zh: "参数“{key}”的初值 {value} 超过最大值 {max}。"
	},
	"initial.offStep": {
		en: "Initial value {value} of parameter \"{key}\" is not on step {step} (based at {base}).",
		zh: "参数“{key}”的初值 {value} 不在步长 {step} 上（基准 {base}）。"
	},
	"initial.typeBoolean": {
		en: "Initial value of parameter \"{key}\" must be a boolean.",
		zh: "参数“{key}”的初值必须是布尔值。"
	},
	"initial.notAmongOptions": {
		en: "Initial value \"{value}\" of parameter \"{key}\" is not among the available values {options}.",
		zh: "参数“{key}”的初值“{value}”不在可用值 {options} 中。"
	},
	"initial.typeWrong": {
		en: "Initial value of parameter \"{name}\" has the wrong type.",
		zh: "参数“{name}”的初值类型不正确。"
	},
	"initial.typeCollection": {
		en: "Initial value of parameter \"{key}\" must be a JSON array.",
		zh: "参数“{key}”的初值必须是 JSON 数组。"
	},
	"initial.typeStringArray": {
		en: "Initial value of parameter \"{key}\" must be an array of strings.",
		zh: "参数“{key}”的初值必须是字符串数组。"
	},
	"initial.typeNumberArray": {
		en: "Initial value of parameter \"{key}\" must be an array of finite numbers.",
		zh: "参数“{key}”的初值必须是有限数字组成的数组。"
	},
	"initial.maxItems": {
		en: "Initial value of parameter \"{key}\" exceeds the limit of {max} items.",
		zh: "参数“{key}”的初值超过 {max} 项的上限。"
	},
	"initial.dateInvalid": {
		en: "Initial date \"{value}\" is not a valid YYYY-MM-DD.",
		zh: "初值日期“{value}”不是有效的 YYYY-MM-DD。"
	},
	"initial.notAvailableOption": {
		en: "Initial value \"{value}\" is not an available option: {options}.",
		zh: "初值“{value}”不是可用选项：{options}。"
	},
	"initial.multiSelectOption": {
		en: "Initial value \"{value}\" of parameter \"{key}\" is not an option of <multi-select>.",
		zh: "参数“{key}”的初值“{value}”不是 <multi-select> 的选项。"
	},
	"initial.rangeSliderOrder": {
		en: "<range-slider> start {start} cannot be greater than end {end}.",
		zh: "<range-slider> 的 start {start} 不能大于 end {end}。"
	},
	"initial.slotBelowMin": {
		en: "Initial value {value} of <{name}> {slot} is below the minimum {min}.",
		zh: "<{name}> 的 {slot} 初值 {value} 小于最小值 {min}。"
	},
	"initial.slotAboveMax": {
		en: "Initial value {value} of <{name}> {slot} exceeds the maximum {max}.",
		zh: "<{name}> 的 {slot} 初值 {value} 超过最大值 {max}。"
	},
	"initial.slotOffStep": {
		en: "Initial value {value} of <{name}> {slot} is not on step {step} (based at {base}).",
		zh: "<{name}> 的 {slot} 初值 {value} 不在步长 {step} 上（基准 {base}）。"
	},
	"initial.lengthBelow": {
		en: "Initial value of parameter \"{key}\" has length {length}, below the minimum length {min} required by <{name}>.",
		zh: "参数“{key}”的初值长度为 {length}，小于 <{name}> 要求的最小长度 {min}。"
	},
	"initial.lengthAbove": {
		en: "Initial value of parameter \"{key}\" has length {length}, exceeding the maximum length {max} allowed by <{name}>.",
		zh: "参数“{key}”的初值长度为 {length}，超过 <{name}> 允许的最大长度 {max}。"
	},
	"initial.email": {
		en: "Initial value of parameter \"{key}\" is not a valid email address.",
		zh: "参数“{key}”的初值不是有效的电子邮件地址。"
	},
	"initial.dateBelow": {
		en: "Initial value {value} of parameter \"{key}\" is earlier than the minimum date {min} of <date>.",
		zh: "参数“{key}”的初值 {value} 早于 <date> 的最小日期 {min}。"
	},
	"initial.dateAbove": {
		en: "Initial value {value} of parameter \"{key}\" is later than the maximum date {max} of <date>.",
		zh: "参数“{key}”的初值 {value} 晚于 <date> 的最大日期 {max}。"
	},
	"initial.multiSelectExceeds": {
		en: "Initial values of <multi-select> exceed max-selected {max}.",
		zh: "<multi-select> 的初值数量超过 max-selected {max}。"
	},
	"expression.error": {
		en: "Expression error: {detail}",
		zh: "表达式错误：{detail}"
	},
	"binding.unknownSuggestion": {
		en: "Reference to undeclared parameter {name}. Did you mean {suggestion}?",
		zh: "引用了未声明的参数 {name}。是否想使用 {suggestion}？"
	},
	"binding.unknownPlain": {
		en: "Reference to undeclared parameter {name}.",
		zh: "引用了未声明的参数 {name}。"
	},
	"type.number": {
		en: "Expected a number here, but the expression evaluates to {kind}.",
		zh: "此处需要数字，但表达式结果为 {kind}。"
	},
	"type.boolean": {
		en: "Expected a boolean here, but the expression evaluates to {kind}.",
		zh: "此处需要布尔值，但表达式结果为 {kind}。"
	},
	"type.string": {
		en: "Expected a string here, but the expression evaluates to {kind}.",
		zh: "此处需要字符串，但表达式结果为 {kind}。"
	},
	"type.arrayNoDisplay": {
		en: "Arrays cannot be displayed directly; convert them first with a function such as len.",
		zh: "数组不能直接显示；请先用 len 等函数转换。"
	},
	"attribute.fullInterpolation": {
		en: "The {name} attribute of <{component}> must be a full interpolation.",
		zh: "<{component}> 的 {name} 属性必须是完整插值。"
	},
	"anchor.idInvalid": {
		en: "Anchor id \"{id}\" must match [A-Za-z_][A-Za-z0-9_-]*.",
		zh: "锚点 id“{id}”必须匹配 [A-Za-z_][A-Za-z0-9_-]*。"
	},
	"anchor.duplicate": {
		en: "Duplicate anchor id \"{id}\".",
		zh: "重复的锚点 id“{id}”。"
	},
	"anchor.headingCollision": {
		en: "Anchor id \"{id}\" collides with an automatic heading target.",
		zh: "锚点 id“{id}”与自动标题目标冲突。"
	},
	"jump.empty": {
		en: "<jump> target cannot be empty.",
		zh: "<jump> 的目标不能为空。"
	},
	"jump.badTarget": {
		en: "<jump> target \"{target}\" must be a bare heading slug or anchor id without \"#\" or whitespace.",
		zh: "<jump> 的目标“{target}”必须是不含“#”或空白的标题 slug 或锚点 id。"
	},
	"jump.unresolved": {
		en: "<jump> target \"{target}\" does not resolve to a heading or explicit anchor in this document.",
		zh: "<jump> 的目标“{target}”无法解析到本文档中的标题或显式锚点。"
	},
	"budget.plotCurves": {
		en: "<plot> supports at most {limit} curves, but has {count}.",
		zh: "<plot> 最多支持 {limit} 条曲线，当前有 {count} 条。"
	},
	"budget.plotPoints": {
		en: "The document's total plot sample count exceeds the limit of {limit}.",
		zh: "文档的绘图采样点总数超过上限 {limit}。"
	},
	"math.formulaShape": {
		en: "<plot> formulas must be an equation: y = f(x), a parametric cases block, or an implicit equation in x and y.",
		zh: "<plot> 的公式必须是方程：y = f(x)、参数方程 cases 块，或关于 x 和 y 的隐式方程。"
	},
	"math.computeFailed": {
		en: "Cannot compute plot formula: {detail}",
		zh: "无法计算绘图公式（错误代码 {code}）：{detail}"
	},
	"math.bindingUnknown": {
		en: "Plot formula references undeclared parameter \"{name}\".",
		zh: "绘图公式引用了未声明的参数“{name}”。"
	},
	"math.bindingType": {
		en: "Plot parameter \"{name}\" must be a number, but is {kind}.",
		zh: "绘图参数“{name}”必须是数字，但当前为 {kind}。"
	},
	"math.displayUnsupportedCommand": {
		en: "Formula command \\{name} is not supported; it is displayed as literal text.",
		zh: "公式命令 \\{name} 不受支持；已按原文显示。"
	},
	"math.displayUnsupportedEnvironment": {
		en: "Formula environment {name} is not supported; it is displayed as literal text.",
		zh: "公式环境 {name} 不受支持；已按原文显示。"
	},
	"math.displayBudget": {
		en: "Formula exceeds a display resource limit ({limit}); it is displayed as literal text.",
		zh: "公式超过显示资源上限（{limit}）；已按原文显示。"
	},
	"math.displayStrayEnd": {
		en: "Formula has an unmatched \\end; it is displayed as literal text.",
		zh: "公式中存在未匹配的 \\end；已按原文显示。"
	},
	"math.displayEnvironmentUnclosed": {
		en: "Formula environment {name} is missing its closing brace; it is displayed as literal text.",
		zh: "公式环境 {name} 缺少结束花括号；已按原文显示。"
	},
	"math.displayEnvironmentMissingName": {
		en: "Formula environment is missing its name; \\begin is displayed as literal text.",
		zh: "公式环境缺少名称；\\begin 已按原文显示。"
	},
	"math.displaySyntax": {
		en: "Formula structure cannot be displayed and is shown as literal text.",
		zh: "公式结构无法显示，已按原文显示。"
	},
	"table.missingHeader": {
		en: "The table for <{name}> is missing a header.",
		zh: "<{name}> 的表格缺少表头。"
	},
	"table.headerInterpolation": {
		en: "Table headers cannot contain interpolations.",
		zh: "表格表头不能包含插值。"
	},
	"table.headerEmpty": {
		en: "Table headers cannot be empty.",
		zh: "表格表头不能为空。"
	},
	"table.headerDuplicate": {
		en: "Duplicate table header \"{name}\".",
		zh: "重复的表格表头“{name}”。"
	},
	"table.rowColumnMismatch": {
		en: "Table row has a different column count: header has {header} columns, this row has {row}.",
		zh: "表格行的列数不一致：表头有 {header} 列，此行有 {row} 列。"
	},
	"chart.numericExpression": {
		en: "Chart column \"{name}\" requires a number in row {row}, but the expression evaluates to {kind}.",
		zh: "图表列“{name}”第 {row} 行需要数字，但表达式结果为 {kind}。"
	},
	"timeline.numericExpression": {
		en: "Timeline column \"{name}\" requires a number in row {row}, but the expression evaluates to {kind}.",
		zh: "时间线列“{name}”第 {row} 行需要数字，但表达式结果为 {kind}。"
	},
	"chart.numericPlain": {
		en: "Chart column \"{name}\" requires a plain number in row {row}, got \"{value}\".",
		zh: "图表列“{name}”第 {row} 行需要普通数字，当前为“{value}”。"
	},
	"timeline.numericPlain": {
		en: "Timeline column \"{name}\" requires a plain number in row {row}, got \"{value}\".",
		zh: "时间线列“{name}”第 {row} 行需要普通数字，当前为“{value}”。"
	},
	"selection.keyEmpty": {
		en: "<{component}> key cannot be empty.",
		zh: "<{component}> 的 key 不能为空。"
	},
	"selection.keyMissingColumn": {
		en: "<{component}> key column \"{name}\" does not exist in its table.",
		zh: "<{component}> 的 key 列“{name}”在表格中不存在。"
	},
	"selection.keyInterpolation": {
		en: "<{component}> key column \"{name}\" must contain static text; row {row} contains an interpolation.",
		zh: "<{component}> 的 key 列“{name}”必须包含静态文本；第 {row} 行包含插值。"
	},
	"selection.keyEmptyCell": {
		en: "<{component}> key column \"{name}\" cannot be empty in row {row}.",
		zh: "<{component}> 的 key 列“{name}”在第 {row} 行不能为空。"
	},
	"selection.keyDuplicate": {
		en: "<{component}> key column \"{name}\" must be unique; duplicate value \"{value}\".",
		zh: "<{component}> 的 key 列“{name}”必须唯一；重复值“{value}”。"
	},
	"initial.selectionNotValue": {
		en: "Initial selection \"{value}\" of <{component}> is not a value of key column \"{name}\".",
		zh: "<{component}> 的初始选择“{value}”不是 key 列“{name}”中的值。"
	},
	"chart.columnComma": {
		en: "Chart column names cannot contain commas: \"{name}\".",
		zh: "图表列名不能包含逗号：“{name}”。"
	},
	"chart.xMissing": {
		en: "Chart x column \"{name}\" does not exist.",
		zh: "图表 x 列“{name}”不存在。"
	},
	"chart.yRequired": {
		en: "Chart y requires a column name.",
		zh: "图表 y 需要列名。"
	},
	"chart.yMissing": {
		en: "Chart y column \"{name}\" does not exist.",
		zh: "图表 y 列“{name}”不存在。"
	},
	"chart.needsNumeric": {
		en: "Chart requires at least one numeric column.",
		zh: "图表至少需要一个数值列。"
	},
	"chart.scatterXMissing": {
		en: "Scatter chart x column \"{name}\" does not exist.",
		zh: "散点图的 x 列“{name}”不存在。"
	},
	"chart.scatterNeedsNumeric": {
		en: "Scatter chart requires at least one numeric column.",
		zh: "散点图至少需要一个数值列。"
	},
	"chart.donutNeedsColumns": {
		en: "Donut chart requires a label column and a value column.",
		zh: "环形图需要一个标签列和一个数值列。"
	},
	"chart.donutYOne": {
		en: "Donut chart y can only specify one numeric column.",
		zh: "环形图的 y 只能指定一个数值列。"
	},
	"chart.donutNeedY": {
		en: "A donut chart with more than two columns must use y to specify the single numeric column.",
		zh: "超过两列的环形图必须用 y 指定唯一的数值列。"
	},
	"chart.negative": {
		en: "Donut chart values cannot be negative; row {row} is {value}.",
		zh: "环形图的数值不能为负；第 {row} 行为 {value}。"
	},
	"timeline.headerMissing": {
		en: "Timeline requires either Task, Start and Duration columns or 事项, 开始 and 时长 columns, with optional Notes or 说明.",
		zh: "时间线需要 Task、Start、Duration 列，或 事项、开始、时长 列，并可选 Notes 或 说明。"
	},
	"timeline.columnUnsupported": {
		en: "Timeline does not support column \"{name}\".",
		zh: "时间线不支持列“{name}”。"
	},
	"timeline.negative": {
		en: "Timeline column \"{name}\" cannot be negative in row {row}.",
		zh: "时间线列“{name}”在第 {row} 行不能为负。"
	},
	"runtime.bindingNoWritable": {
		en: "This component has no writable binding state.",
		zh: "此组件没有可写的绑定状态。"
	},
	"runtime.bindingNeedsSlot": {
		en: "This multi-slot component requires a slot such as start/end or x/y.",
		zh: "此多槽组件需要 start/end 或 x/y 之类的槽位。"
	},
	"runtime.bindingUnknownSlot": {
		en: "This component has no writable slot \"{slot}\".",
		zh: "此组件没有可写的槽位“{slot}”。"
	},
	"runtime.bindingNoMultiSlot": {
		en: "This component does not support multiple slots.",
		zh: "此组件不支持多个槽位。"
	},
	"runtime.dateInvalid": {
		en: "Date must be a valid YYYY-MM-DD or an empty string.",
		zh: "日期必须是有效的 YYYY-MM-DD 或空字符串。"
	},
	"runtime.dateRequired": {
		en: "This date is required.",
		zh: "此日期为必填项。"
	},
	"runtime.dateEarlier": {
		en: "Date cannot be earlier than {min}.",
		zh: "日期不能早于 {min}。"
	},
	"runtime.dateLater": {
		en: "Date cannot be later than {max}.",
		zh: "日期不能晚于 {max}。"
	},
	"runtime.fieldRequired": {
		en: "This field is required.",
		zh: "此字段为必填项。"
	},
	"runtime.minLength": {
		en: "At least {min} characters.",
		zh: "至少 {min} 个字符。"
	},
	"runtime.maxLength": {
		en: "At most {max} characters.",
		zh: "至多 {max} 个字符。"
	},
	"runtime.emailLength": {
		en: "Email address cannot exceed {limit} characters.",
		zh: "电子邮件地址不能超过 {limit} 个字符。"
	},
	"runtime.emailInvalid": {
		en: "Enter a valid email address.",
		zh: "请输入有效的电子邮件地址。"
	},
	"runtime.finiteNumber": {
		en: "Parameter \"{name}\" requires a finite number.",
		zh: "参数“{name}”需要有限数字。"
	},
	"runtime.min": {
		en: "Parameter \"{name}\" must be at least {min}.",
		zh: "参数“{name}”必须至少为 {min}。"
	},
	"runtime.max": {
		en: "Parameter \"{name}\" must be at most {max}.",
		zh: "参数“{name}”必须至多为 {max}。"
	},
	"runtime.step": {
		en: "Parameter \"{name}\" must be a multiple of step {step} (base {base}).",
		zh: "参数“{name}”必须是步长 {step} 的倍数（基准 {base}）。"
	},
	"runtime.boolean": {
		en: "Parameter \"{name}\" requires a boolean.",
		zh: "参数“{name}”需要布尔值。"
	},
	"runtime.string": {
		en: "Parameter \"{name}\" requires a string.",
		zh: "参数“{name}”需要字符串。"
	},
	"runtime.array": {
		en: "Parameter \"{name}\" requires an array of strings.",
		zh: "参数“{name}”需要字符串数组。"
	},
	"runtime.arrayMembers": {
		en: "Parameter \"{name}\" members must be strings.",
		zh: "参数“{name}”的成员必须是字符串。"
	},
	"runtime.numberArray": {
		en: "Parameter \"{name}\" requires an array of finite numbers.",
		zh: "参数“{name}”需要有限数字数组。"
	},
	"runtime.numberArrayMembers": {
		en: "Parameter \"{name}\" members must be finite numbers.",
		zh: "参数“{name}”的成员必须是有限数字。"
	},
	"runtime.null": {
		en: "Parameter \"{name}\" requires null.",
		zh: "参数“{name}”需要 null。"
	},
	"runtime.checklistOption": {
		en: "Checklist item \"{value}\" does not exist.",
		zh: "清单项“{value}”不存在。"
	},
	"runtime.maxItems": {
		en: "Parameter \"{name}\" allows at most {max} selected values.",
		zh: "参数“{name}”最多允许选择 {max} 个值。"
	},
	"runtime.unsupportedType": {
		en: "Parameter \"{name}\" has an unsupported value type.",
		zh: "参数“{name}”的值类型不受支持。"
	},
	"runtime.option": {
		en: "Value \"{value}\" is not among the options: {options}.",
		zh: "值“{value}”不在选项中：{options}。"
	},
	"runtime.budget": {
		en: "Parameter \"{name}\": {detail}",
		zh: "参数“{name}”：{detail}"
	},
	"runtime.rangeOrder": {
		en: "The range start cannot be greater than its end.",
		zh: "范围起点不能大于终点。"
	},
	"budget.string": {
		en: "String exceeds the {limit}-character limit.",
		zh: "字符串超过 {limit} 个字符的上限。"
	},
	"budget.array": {
		en: "Array exceeds the {limit}-item limit.",
		zh: "数组超过 {limit} 个项的上限。"
	},
	"budget.arrayMember": {
		en: "Array member exceeds the {limit}-character limit.",
		zh: "数组成员超过 {limit} 个字符的上限。"
	},
	"budget.arrayContents": {
		en: "Array contents exceed the {limit}-character limit.",
		zh: "数组内容超过 {limit} 个字符的上限。"
	},
	"theme.missing": {
		en: "Theme \"{name}\" is not registered by the host; using the default theme.",
		zh: "宿主未注册主题“{name}”；将使用默认主题。"
	},
	"theme.registryUnreadable": {
		en: "The host theme registry could not be read; using the default theme.",
		zh: "无法读取宿主主题注册表；将使用默认主题。"
	},
	"theme.invalidDefinition": {
		en: "The selected theme \"{name}\" is not a valid definition; using the default theme.",
		zh: "所选主题“{name}”不是有效定义；将使用默认主题。"
	},
	"theme.duplicateRegistration": {
		en: "Theme \"{name}\" is registered more than once; using the default theme.",
		zh: "主题“{name}”被多次注册；将使用默认主题。"
	},
	"theme.protocol": {
		en: "Theme \"{name}\" does not support the {protocol} protocol; using the default theme.",
		zh: "主题“{name}”不支持 {protocol} 协议；将使用默认主题。"
	},
	"theme.modes": {
		en: "Theme \"{name}\" must supply both light and dark color schemes; using the default theme.",
		zh: "主题“{name}”必须同时提供浅色和深色配色；将使用默认主题。"
	},
	"theme.selectedUnreadable": {
		en: "The selected theme \"{name}\" could not be read; using the default theme.",
		zh: "所选主题“{name}”无法读取；将使用默认主题。"
	},
	"error.expression-syntax": {
		en: "Check expression operators, parentheses and arguments.",
		zh: "表达式语法不正确，请检查运算符、括号或参数是否完整。"
	},
	"error.expression-index": {
		en: "An array index must be a finite safe integer.",
		zh: "数组索引必须为有限的安全整数。"
	},
	"error.expression-cycle": {
		en: "Named calculations contain a dependency cycle.",
		zh: "命名计算中存在循环依赖。"
	},
	"error.array.homogeneous": {
		en: "Array elements must all be strings or all be numbers.",
		zh: "数组元素必须全部为字符串或全部为数字。"
	},
	"error.array.finite": {
		en: "Array members must be finite numbers.",
		zh: "数字数组元素必须为有限数值。"
	},
	"error.array.members": {
		en: "Array members must be strings or finite numbers.",
		zh: "数组元素必须为字符串或有限数值。"
	},
	"error.expression-number": {
		en: "A numeric literal must be finite and valid.",
		zh: "数字字面量无效，必须是有限数值。"
	},
	"error.expression-string": {
		en: "Check the string quotes and escape sequences.",
		zh: "字符串格式不正确，请检查引号和转义。"
	},
	"error.expression-budget": {
		en: "The expression exceeded a resource budget.",
		zh: "表达式超过长度、节点、深度或求值步数预算，请简化表达式。"
	},
	"error.expression-assignment": {
		en: "Assignment is not allowed in expressions.",
		zh: "表达式不能执行赋值，请使用比较运算符。"
	},
	"error.expression-property": {
		en: "Property access is not allowed.",
		zh: "表达式不支持属性访问，请直接引用绑定名称。"
	},
	"error.expression-empty": {
		en: "An expression is required.",
		zh: "此处需要非空表达式。"
	},
	"error.expression-unknown-function": {
		en: "Use a supported built-in function.",
		zh: "函数不受支持，请使用语言内置函数。"
	},
	"error.expression-arity": {
		en: "Check the function argument count.",
		zh: "函数参数数量不正确。"
	},
	"error.expression-forbidden-name": {
		en: "The name is forbidden.",
		zh: "此名称属于禁止访问的名称，请使用已声明的绑定。"
	},
	"error.expression-type": {
		en: "Operand or argument types do not match.",
		zh: "操作数或函数参数的类型不匹配，请检查绑定类型。"
	},
	"error.expression-unknown-name": {
		en: "The binding is not declared.",
		zh: "引用了未声明的绑定。"
	},
	"error.expression-value": {
		en: "The binding value is not supported.",
		zh: "绑定值不符合表达式支持的类型或数值范围。"
	},
	"error.expression-eval": {
		en: "The expression cannot be evaluated.",
		zh: "表达式无法求值，请检查输入和运算条件。"
	},
	"error.expression-domain": {
		en: "A value lies outside the function domain.",
		zh: "参数超出函数定义域。"
	},
	"error.expression-divide-by-zero": {
		en: "Division by zero is undefined.",
		zh: "除数不能为零。"
	},
	"error.expression-interpolation": {
		en: "Check interpolation delimiters and content.",
		zh: "插值格式不正确，请检查分隔符和表达式内容。"
	},
	"error.latex-budget": {
		en: "The formula exceeded a resource budget.",
		zh: "公式超过长度、记号、节点、深度或计算步数预算，请简化公式。"
	},
	"error.latex-syntax": {
		en: "Check formula syntax and delimiters.",
		zh: "公式语法不正确，请检查命令、括号和分隔符。"
	},
	"error.latex-empty": {
		en: "A formula is required.",
		zh: "公式不能为空。"
	},
	"error.latex-relation": {
		en: "Check the formula relation.",
		zh: "公式中的关系式不符合计算语法。"
	},
	"error.latex-number": {
		en: "A formula number must be finite.",
		zh: "公式中的数字必须是有限数值。"
	},
	"error.latex-name": {
		en: "Use a valid formula parameter name.",
		zh: "公式参数名称无效，请使用合法绑定名。"
	},
	"error.latex-unsupported": {
		en: "The LaTeX structure is not computable.",
		zh: "此 LaTeX 结构不支持计算，请改用支持的函数和运算。"
	},
	"error.latex-variable": {
		en: "A numeric formula parameter is missing or invalid.",
		zh: "公式引用的参数缺失或不是有限数字。"
	},
	"error.latex-type": {
		en: "A formula parameter has the wrong type.",
		zh: "公式参数类型不正确，计算参数必须为数字。"
	},
	"error.latex-divide-by-zero": {
		en: "Division by zero is undefined.",
		zh: "公式中的除数不能为零。"
	},
	"error.latex-domain": {
		en: "A formula value lies outside the function domain.",
		zh: "公式参数超出函数定义域。"
	},
	"error.latex-undefined": {
		en: "The formula is undefined at this point.",
		zh: "公式在此点没有有限定义值。"
	},
	"error.latex-plot-range": {
		en: "Plot bounds must be finite and increasing.",
		zh: "绘图区间必须由有限数值构成，且最小值小于最大值。"
	},
	"error.latex-plot-samples": {
		en: "The sample count must be an integer from 2 to 2000.",
		zh: "采样点数必须为 2 至 2000 的整数。"
	},
	"local.external.placement": {
		en: "<external> declarations must be standalone tags at the document top level.",
		zh: "<external> 声明必须独占一行，位于文档顶层。"
	},
	"local.external.name": {
		en: "External name \"{name}\" must match [A-Za-z_][A-Za-z0-9_]*.",
		zh: "外部名称“{name}”必须匹配 [A-Za-z_][A-Za-z0-9_]*。"
	},
	"local.external.reserved": {
		en: "External name \"{name}\" is reserved; choose another name.",
		zh: "外部名称“{name}”为保留名称，请更换。"
	},
	"local.external.duplicate": {
		en: "External name \"{name}\" is declared more than once.",
		zh: "外部名称“{name}”被重复声明。"
	},
	"local.external.conflict": {
		en: "External name \"{name}\" conflicts with a control parameter of the same name.",
		zh: "外部名称“{name}”与同名控件参数冲突。"
	},
	"local.external.type": {
		en: "External \"{name}\" must declare type string, number, boolean, string-array or number-array.",
		zh: "外部声明“{name}”必须声明 string、number、boolean、string-array 或 number-array 类型。"
	},
	"local.host.structure.leaf": {
		en: "Host component <{component}> is a leaf and cannot have body content.",
		zh: "宿主组件 <{component}> 是叶子组件，不能包含正文内容。"
	},
	"local.runtime.external": {
		en: "External value {name} cannot be written.",
		zh: "无法写入外部数据 {name}。"
	},
	"local.runtime.external-value": {
		en: "External value {name} must be {kind}.",
		zh: "外部数据 {name} 必须是 {kind} 类型。"
	},
	"local.runtime.external-budget": {
		en: "External value {name} exceeds a resource limit.",
		zh: "外部数据 {name} 超过资源限制。"
	},
	"local.runtime.value.constraint": {
		en: "Dynamic {attribute} constraint failed for parameter {name}.",
		zh: "参数 {name} 的动态 {attribute} 约束无法计算。"
	},
	"local.runtime.value.constraint-range": {
		en: "Dynamic constraints for parameter {name} produce an invalid range.",
		zh: "参数 {name} 的动态约束产生无效范围。"
	},
	"local.runtime.value.constraint-date": {
		en: "Dynamic {attribute} date bound for parameter {name} is not a valid YYYY-MM-DD value.",
		zh: "参数 {name} 的动态 {attribute} 日期边界不是合法的 YYYY-MM-DD。"
	}
}, g = {
	"local.options.invalid.object": "options.notObject",
	"local.options.invalid.limits": "options.limitsNotObject",
	"local.options.invalid.max-syntax-nodes": "options.maxSyntaxNodes",
	"local.options.invalid.max-parse-work": "options.maxParseWork",
	"local.options.invalid.max-markdown-depth": "options.maxMarkdownDepth",
	"local.options.invalid.limits-unknown": "options.unknownLimit",
	"local.options.invalid.host-components": "options.hostComponents",
	"local.budget.document": "budget.document",
	"local.budget.nodes": "budget.syntaxNodes",
	"local.budget.parse-work": "budget.parseWork",
	"local.budget.markdown-depth": "budget.markdownDepth",
	"local.budget.nesting": "budget.nesting",
	"local.budget.name.attribute": "budget.attributeName",
	"local.budget.name.tag": "budget.tagName",
	"local.budget.math": "budget.math",
	"local.budget.attribute": "budget.attribute",
	"local.budget.array.options": "budget.options",
	"local.budget.array.checklist": "budget.checklistItems",
	"local.budget.identifier": "budget.identifier",
	"local.budget.plot.curves": "budget.plotCurves",
	"local.budget.plot.points": "budget.plotPoints",
	"local.budget.value.string": "budget.string",
	"local.budget.value.array": "budget.array",
	"local.budget.value.array-member": "budget.arrayMember",
	"local.budget.value.array-contents": "budget.arrayContents",
	"local.capability.html": "capability.html",
	"local.capability.plot": "capability.plot",
	"local.parse.source": "parse.sourceType",
	"local.parse.markdown": "parse.markdownFailed",
	"local.parse.document": "parse.failed",
	"local.legacy": "legacy.fence",
	"local.theme.expression": "theme.expression",
	"local.theme.name.missing": "theme.nameRequired",
	"local.theme.attribute": "theme.attributeOnly",
	"local.theme.name.invalid": "theme.nameInvalid",
	"local.theme.name": "theme.nameInvalid",
	"local.theme.malformed.unclosed": "theme.malformedMissingClose",
	"local.theme.malformed.closing": "theme.malformedClosing",
	"local.theme.malformed.placement": "theme.malformedStandalone",
	"local.theme.duplicate.declaration": "theme.duplicateDeclaration",
	"local.theme.duplicate": "theme.duplicateRegistration",
	"local.theme.late": "theme.late",
	"local.theme.nested": "theme.nested",
	"local.theme.invalid": "theme.invalidDeclaration",
	"local.theme.missing": "theme.missing",
	"local.theme.manifest.unreadable": "theme.registryUnreadable",
	"local.theme.manifest.definition": "theme.invalidDefinition",
	"local.theme.manifest.selected": "theme.selectedUnreadable",
	"local.theme.protocol": "theme.protocol",
	"local.theme.modes": "theme.modes",
	"local.tag.missing-close": "tag.missingClose",
	"local.tag.unclosed.open": "tag.missingClose",
	"local.tag.unclosed.pair": "tag.unclosedPaired",
	"local.tag.closing": "tag.closingAttributes",
	"local.tag.name": "tag.nameInvalid",
	"local.tag.mismatch.root": "tag.mismatchRoot",
	"local.tag.mismatch.parent": "tag.mismatchParent",
	"local.tag.shape": "tag.requiresClose",
	"local.interpolation.unclosed": "interpolation.unclosed",
	"local.math.unclosed": "math.unclosed",
	"local.math.whitespace": "math.whitespace",
	"local.footnote.unsupported": "footnote.unsupported",
	"local.html": "html.raw",
	"local.html.fallback": "html.fallback",
	"local.html.fallback.attribute": "html.fallbackAttribute",
	"local.html.table": "html.table.structure",
	"local.html.extended": "html.extended",
	"local.html.attribute": "html.attribute",
	"local.html.unsafe-url": "html.unsafeUrl",
	"local.html.capability": "html.capability",
	"local.recovery.unclosed": "recovery.unclosed",
	"local.recovery.mismatch": "recovery.mismatch",
	"local.recovery.stray-close": "recovery.strayClose",
	"local.html.repair": "recovery.htmlRepair",
	"local.html.literal": "recovery.htmlLiteral",
	"local.options.invalid.html-flag": "options.htmlFlag",
	"local.options.invalid.markdown-breaks": "options.markdownBreaks",
	"local.options.invalid.strict": "options.strict",
	"local.component.unknown.suggestion": "component.unknownSuggestion",
	"local.component.unknown": "component.unknownPlain",
	"local.attribute.format": "attribute.lowercase",
	"local.attribute.name": "attribute.nameInvalid",
	"local.attribute.value-quoted": "attribute.valueQuoted",
	"local.attribute.closing-quote": "attribute.valueUnclosed",
	"local.attribute.duplicate": "attribute.duplicate",
	"local.attribute.separator": "attribute.separator",
	"local.attribute.unknown.suggestion": "attribute.unknownSuggestion",
	"local.attribute.unknown": "attribute.unknownPlain",
	"local.attribute.color": "attribute.color",
	"local.attribute.required": "attribute.required",
	"local.attribute.static": "attribute.static",
	"local.host.attribute.unknown": "host.attributeUnknown",
	"local.host.attribute.required": "host.attributeRequired",
	"local.host.attribute.static": "host.attributeStatic",
	"local.host.attribute.type": "host.attributeType",
	"local.host.attribute.enum": "host.attributeEnum",
	"local.host.attribute.pattern": "host.attributePattern",
	"local.host.attribute.interpolation": "host.attributeInterpolation",
	"local.attribute.type.number": "attribute.numberInvalid",
	"local.attribute.type.number-interpolation": "attribute.numberInterpolationInvalid",
	"local.attribute.type.integer": "attribute.integer",
	"local.attribute.type.positive": "attribute.positive",
	"local.attribute.type.boolean": "attribute.booleanInvalid",
	"local.attribute.type.boolean-interpolation": "attribute.booleanInterpolationInvalid",
	"local.attribute.type.enum": "attribute.enumInvalid",
	"local.attribute.type.date-lower": "attribute.dateLower",
	"local.attribute.type.date-upper": "attribute.dateUpper",
	"local.attribute.range.min": "attribute.rangeMin",
	"local.attribute.range.max": "attribute.rangeMax",
	"local.attribute.interpolation": "attribute.fullInterpolation",
	"local.label.required.missing": "label.requiredMissing",
	"local.label.required.empty": "label.requiredEmpty",
	"local.expression.empty.attribute": "expression.emptyAttribute",
	"local.expression.empty": "expression.emptyInterpolation",
	"local.expression.error": "expression.error",
	"local.constraint.number-min-max": "constraint.componentMinMax",
	"local.constraint.number-step": "constraint.componentStep",
	"local.constraint.length-order": "constraint.lengthRange",
	"local.constraint.date-order": "constraint.dateOrder",
	"local.constraint.progress-range": "constraint.progressRange",
	"local.constraint.plot-range": "constraint.plotRange",
	"local.constraint.timer-duration": "constraint.timerDuration",
	"local.constraint.range-slider-min-max": "constraint.rangeSliderOrder",
	"local.constraint.range-slider-step": "constraint.rangeSliderStep",
	"local.constraint.coordinate-axis": "constraint.coordinateOrder",
	"local.constraint.coordinate-step": "constraint.coordinateStep",
	"local.constraint.multi-select": "constraint.multiSelectMax",
	"local.constraint.quiz-tolerance": "constraint.quizTolerance",
	"local.selection.key.required": "selection.keyNeedsKey",
	"local.selection.key.empty": "selection.keyEmpty",
	"local.selection.key.missing-column": "selection.keyMissingColumn",
	"local.selection.key.interpolation": "selection.keyInterpolation",
	"local.selection.key.empty-cell": "selection.keyEmptyCell",
	"local.selection.key.duplicate": "selection.keyDuplicate",
	"local.selection.key.initial": "initial.selectionNotValue",
	"local.structure.parent": "structure.parent",
	"local.structure.no-body": "structure.noBody",
	"local.structure.inline-only": "structure.inlineOnly",
	"local.structure.no-nested-components": "structure.noNestedComponents",
	"local.structure.no-components": "structure.noComponents",
	"local.structure.children.minimum": "structure.childrenMinimum",
	"local.structure.children.only": "structure.childrenOnly",
	"local.structure.sequence.minimum": "structure.sequenceMinimum",
	"local.structure.sequence.only": "structure.sequenceOnly",
	"local.structure.accordion.needs-disclosure": "structure.accordionNeedsDisclosure",
	"local.structure.accordion.only-disclosure": "structure.accordionOnly",
	"local.structure.grid.needs-card": "structure.gridNeedsCard",
	"local.structure.grid.only-card": "structure.gridOnlyCard",
	"local.structure.table.single": "structure.exactlyOneTable",
	"local.structure.plot.needs-formula": "structure.plotNeedsFormula",
	"local.structure.plot.only-formulas": "structure.plotOnlyFormulas",
	"local.structure.node.no-components": "structure.nodeNoComponents",
	"local.structure.options.needed": "structure.optionsNeeded",
	"local.structure.options.only": "structure.optionsOnly",
	"local.structure.option.no-components": "structure.optionNoComponents",
	"local.structure.tabs.needs-tab": "structure.tabsNeedsTab",
	"local.structure.tabs.only-tab": "structure.tabsOnly",
	"local.structure.steps.needs-step": "structure.stepsNeedsStep",
	"local.structure.steps.only-step": "structure.stepsOnly",
	"local.structure.quiz.numeric-no-body": "structure.quizNumericNoBody",
	"local.structure.diagram.only": "structure.diagramOnly",
	"local.option.value.required": "option.valueRequired",
	"local.option.value.comma": "option.valueComma",
	"local.option.value.duplicate": "option.valueDuplicate",
	"local.tab.value.duplicate": "tab.valueDuplicate",
	"local.step.value.duplicate": "step.valueDuplicate",
	"local.quiz.answer.required": "quiz.answerRequired",
	"local.quiz.answer.numeric": "quiz.answerNumeric",
	"local.quiz.answer.not-option": "quiz.answerNotOption",
	"local.diagram.node.required": "diagram.needsNode",
	"local.diagram.node.invalid": "diagram.nodeInvalid",
	"local.diagram.node.duplicate": "diagram.nodeDuplicate",
	"local.diagram.edge.from": "diagram.edgeFromUnknown",
	"local.diagram.edge.to": "diagram.edgeToUnknown",
	"local.diagram.edge.duplicate": "diagram.edgeDuplicate",
	"local.checklist.body.single": "checklist.bodySingle",
	"local.checklist.body.item-required": "checklist.needsItem",
	"local.checklist.body.items-limit": "budget.checklistItems",
	"local.checklist.body.task-only": "checklist.taskOnly",
	"local.checklist.body.no-nested": "checklist.noNested",
	"local.checklist.body.no-components": "checklist.noComponents",
	"local.binding.name": "binding.nameInvalid",
	"local.binding.reserved": "binding.reserved",
	"local.binding.type": "binding.typeConflict",
	"local.binding.exclusive": "binding.exclusive",
	"local.binding.exclusive.slot": "binding.slotExclusive",
	"local.binding.constraint": "binding.constraintConflict",
	"local.binding.option": "binding.optionConflict",
	"local.binding.unknown.suggestion": "binding.unknownSuggestion",
	"local.binding.unknown": "binding.unknownPlain",
	"local.initial.duplicate": "initial.duplicate",
	"local.initial.duplicate-peers": "initial.duplicatePeers",
	"local.initial.no-step": "initial.rangeNoStep",
	"local.initial.cannot-derive": "initial.cannotDerive",
	"local.initial.type.number": "initial.typeFiniteNumber",
	"local.initial.type.boolean": "initial.typeBoolean",
	"local.initial.type": "initial.typeWrong",
	"local.initial.type.collection": "initial.typeCollection",
	"local.initial.type.array": "initial.typeStringArray",
	"local.initial.type.number-array": "initial.typeNumberArray",
	"local.initial.value.max-items": "initial.maxItems",
	"local.initial.range.min": "initial.belowMin",
	"local.initial.range.max": "initial.aboveMax",
	"local.initial.range.step": "initial.offStep",
	"local.initial.value.options": "initial.notAmongOptions",
	"local.initial.date": "initial.dateInvalid",
	"local.initial.value.option": "initial.notAvailableOption",
	"local.initial.option.multi-select": "initial.multiSelectOption",
	"local.initial.range-slider": "initial.rangeSliderOrder",
	"local.initial.slot.min": "initial.slotBelowMin",
	"local.initial.slot.max": "initial.slotAboveMax",
	"local.initial.slot.step": "initial.slotOffStep",
	"local.initial.length.min": "initial.lengthBelow",
	"local.initial.length.max": "initial.lengthAbove",
	"local.initial.email": "initial.email",
	"local.initial.date.min": "initial.dateBelow",
	"local.initial.date.max": "initial.dateAbove",
	"local.initial.multi-select": "initial.multiSelectExceeds",
	"local.type.number": "type.number",
	"local.type.boolean": "type.boolean",
	"local.type.string": "type.string",
	"local.type.array": "type.arrayNoDisplay",
	"local.anchor.id": "anchor.idInvalid",
	"local.anchor.duplicate": "anchor.duplicate",
	"local.anchor.heading-collision": "anchor.headingCollision",
	"local.jump.empty": "jump.empty",
	"local.jump.bad-target": "jump.badTarget",
	"local.jump.unresolved": "jump.unresolved",
	"local.math.formula.shape": "math.formulaShape",
	"local.math.compute": "math.computeFailed",
	"local.math.binding.unknown": "math.bindingUnknown",
	"local.math.binding.type": "math.bindingType",
	"local.math.display.unsupported-command": "math.displayUnsupportedCommand",
	"local.math.display.unsupported-environment": "math.displayUnsupportedEnvironment",
	"local.math.display.budget": "math.displayBudget",
	"local.math.display.stray-end": "math.displayStrayEnd",
	"local.math.display.environment-unclosed": "math.displayEnvironmentUnclosed",
	"local.math.display.environment-missing-name": "math.displayEnvironmentMissingName",
	"local.math.display.syntax": "math.displaySyntax",
	"local.table.header.missing": "table.missingHeader",
	"local.table.header.interpolation": "table.headerInterpolation",
	"local.table.header.empty": "table.headerEmpty",
	"local.table.header.duplicate": "table.headerDuplicate",
	"local.table.row.mismatch": "table.rowColumnMismatch",
	"local.chart.numeric.expression": "chart.numericExpression",
	"local.timeline.numeric.expression": "timeline.numericExpression",
	"local.chart.numeric.plain": "chart.numericPlain",
	"local.timeline.numeric.plain": "timeline.numericPlain",
	"local.chart.column.comma": "chart.columnComma",
	"local.chart.column.x-missing": "chart.xMissing",
	"local.chart.column.y-required": "chart.yRequired",
	"local.chart.column.y-missing": "chart.yMissing",
	"local.chart.column.needs-numeric": "chart.needsNumeric",
	"local.chart.column.scatter-x-missing": "chart.scatterXMissing",
	"local.chart.column.scatter-needs-numeric": "chart.scatterNeedsNumeric",
	"local.chart.column.donut-columns": "chart.donutNeedsColumns",
	"local.chart.column.donut-y": "chart.donutYOne",
	"local.chart.column.donut-need-y": "chart.donutNeedY",
	"local.chart.negative": "chart.negative",
	"local.timeline.header.missing": "timeline.headerMissing",
	"local.timeline.header.column": "timeline.columnUnsupported",
	"local.timeline.value.negative": "timeline.negative",
	"local.runtime.binding.no-writable": "runtime.bindingNoWritable",
	"local.runtime.binding.needs-slot": "runtime.bindingNeedsSlot",
	"local.runtime.binding.unknown-slot": "runtime.bindingUnknownSlot",
	"local.runtime.binding.no-multi-slot": "runtime.bindingNoMultiSlot",
	"local.runtime.value.date-invalid": "runtime.dateInvalid",
	"local.runtime.value.date-required": "runtime.dateRequired",
	"local.runtime.value.date-earlier": "runtime.dateEarlier",
	"local.runtime.value.date-later": "runtime.dateLater",
	"local.runtime.value.field-required": "runtime.fieldRequired",
	"local.runtime.value.min-length": "runtime.minLength",
	"local.runtime.value.max-length": "runtime.maxLength",
	"local.runtime.value.email-length": "runtime.emailLength",
	"local.runtime.value.email-invalid": "runtime.emailInvalid",
	"local.runtime.value.finite-number": "runtime.finiteNumber",
	"local.runtime.value.min": "runtime.min",
	"local.runtime.value.max": "runtime.max",
	"local.runtime.value.step": "runtime.step",
	"local.runtime.value.boolean": "runtime.boolean",
	"local.runtime.value.string": "runtime.string",
	"local.runtime.value.array": "runtime.array",
	"local.runtime.value.array-members": "runtime.arrayMembers",
	"local.runtime.value.number-array": "runtime.numberArray",
	"local.runtime.value.number-array-members": "runtime.numberArrayMembers",
	"local.runtime.value.null": "runtime.null",
	"local.runtime.value.checklist-option": "runtime.checklistOption",
	"local.runtime.value.max-items": "runtime.maxItems",
	"local.runtime.value.unsupported-type": "runtime.unsupportedType",
	"local.runtime.value.option": "runtime.option",
	"local.runtime.value.budget": "runtime.budget",
	"local.runtime.value.range-order": "runtime.rangeOrder"
}, ne = 16, _ = 256, re = 2e3;
function ie(e) {
	if (typeof e == "string") return e.length > _ ? `${e.slice(0, 255)}…` : e;
	if (typeof e == "number") return Number.isFinite(e) ? e : String(e);
	if (typeof e == "boolean" || e === null) return e;
	if (e === void 0) return "";
	try {
		let t = JSON.stringify(e) ?? String(e);
		return t.length > _ ? `${t.slice(0, 255)}…` : t;
	} catch {
		return String(e).slice(0, _);
	}
}
function ae(e) {
	let t = Object.entries(e);
	if (t.length === 0) return;
	let n = {}, r = 0, i = 0;
	for (let [e, a] of t) {
		if (i >= ne) break;
		if (!/^[A-Za-z_][A-Za-z0-9_]*$/.test(e)) continue;
		let t;
		try {
			t = ie(a);
		} catch {
			t = "";
		}
		let o = typeof t == "string" ? t.length : String(t).length;
		if (r + o > re) break;
		n[e] = t, r += o, i += 1;
	}
	return i > 0 ? n : void 0;
}
function oe(e, t) {
	let n = t ? ae(t) : void 0;
	return n ? {
		key: e,
		params: n
	} : { key: e };
}
var se = /* @__PURE__ */ "local.parse,local.budget,local.options.invalid,local.theme.expression,local.theme.name,local.theme.attribute,local.theme.malformed,local.theme.duplicate,local.theme.late,local.theme.nested,local.attribute,local.attribute.name,local.attribute.duplicate,local.budget.name,local.budget.math,local.tag.unclosed,local.tag.closing,local.tag.name,local.tag.mismatch,local.tag.shape,local.footnote.unsupported,local.interpolation,local.math.unclosed,local.math.whitespace,local.component.unknown,local.html,local.html.fallback,local.html.table,local.html.repair,local.html.literal,local.recovery.unclosed,local.recovery.mismatch,local.recovery.stray-close".split(","), ce = /* @__PURE__ */ "local.budget.data-table.cells,local.budget.data-table.columns,local.budget.data-table.rows,local.computation.budget,local.computation.const,local.computation.cycle,local.computation.duplicate,local.computation.expression,local.computation.name,local.computation.placement,local.computation.reserved,local.computation.unknown,local.external.placement,local.external.name,local.external.reserved,local.external.duplicate,local.external.conflict,local.external.type,local.host.structure,local.computation.value,local.data-table.column,local.data-table.key,local.data-table.rows,local.data-table.value,local.validation.budget,local.validation.expression,local.validation.failed,local.validation.fields,local.validation.placement,local.validation.when,local.parse,local.legacy,local.component.unknown,local.host.attribute,local.attribute.unknown,local.budget.attribute,local.attribute.color,local.attribute.required,local.label.required,local.attribute.static,local.expression.empty,local.expression.invalid,local.attribute.type,local.attribute.range,local.constraint,local.selection.key,local.structure.parent,local.structure.children,local.budget.array,local.option.value,local.tab.value,local.step.value,local.quiz.answer,local.diagram.node,local.diagram.edge,local.checklist.body,local.budget.identifier,local.binding.name,local.binding.reserved,local.binding.type,local.binding.exclusive,local.binding.constraint,local.binding.option,local.initial.duplicate,local.initial.length,local.initial.email,local.initial.range,local.initial.option,local.initial.type,local.initial.date,local.initial,local.initial.step,local.binding.unknown,local.type,local.interpolation,local.attribute.interpolation,local.anchor.id,local.anchor.duplicate,local.jump.target,local.budget.plot.curves,local.budget.plot.points,local.math.formula,local.math,local.math.display,local.math.binding,local.table.header,local.table.row,local.chart.numeric,local.chart.column,local.chart.negative,local.timeline.header,local.timeline.value,local.html.extended,local.html.attribute,local.html.unsafe-url,local.html.capability,local.capability.html,local.capability.plot".split(","), le = [
	"local.runtime.binding",
	"local.runtime.value",
	"local.runtime.external"
], ue = [
	"local.theme.name",
	"local.theme.missing",
	"local.theme.manifest",
	"local.theme.duplicate",
	"local.theme.protocol",
	"local.theme.modes"
], de = [
	"expression-index",
	"expression-cycle",
	"expression-syntax",
	"expression-number",
	"expression-string",
	"expression-budget",
	"expression-assignment",
	"expression-property",
	"expression-empty",
	"expression-unknown-function",
	"expression-arity",
	"expression-forbidden-name",
	"expression-type",
	"expression-unknown-name",
	"expression-value",
	"expression-eval",
	"expression-domain",
	"expression-divide-by-zero",
	"expression-interpolation"
], fe = [
	"latex-budget",
	"latex-syntax",
	"latex-empty",
	"latex-relation",
	"latex-number",
	"latex-name",
	"latex-unsupported",
	"latex-variable",
	"latex-type",
	"latex-divide-by-zero",
	"latex-domain",
	"latex-undefined",
	"latex-plot-range",
	"latex-plot-samples"
], pe = [
	"local.version.unsupported",
	"local.version.malformed",
	"local.version.duplicate",
	"local.version.placement",
	"local.upgrade.from-version",
	"local.upgrade.reserved-binding",
	"local.upgrade.tag",
	"local.upgrade.text-length",
	"local.upgrade.expression",
	"local.upgrade.version-missing",
	...se,
	...ce,
	...le,
	...ue
], me = Object.freeze(Array.from(/* @__PURE__ */ new Set([
	...pe,
	...de,
	...de.map((e) => `local.expression.${e}`),
	...fe
]))), he = Object.freeze([...Object.keys(g), ...Object.keys(h).filter((e) => e.startsWith("error."))].sort());
function ge(e) {
	if (Object.hasOwn(g, e)) return g[e];
	if (Object.hasOwn(h, e)) return e;
}
function v(e, t = "en") {
	let n = ge(e);
	if (n) return h[n][t === "zh" ? "zh" : "en"];
}
function _e(e) {
	return typeof e == "string" && me.includes(e);
}
function y(e, t) {
	return t ? e.replace(/\{([A-Za-z_][A-Za-z0-9_]*)\}/g, (e, n) => {
		let r = t[n];
		return r === void 0 ? "" : String(r);
	}) : e;
}
function b(e, t = "en", n) {
	let r = v(e, t);
	return r === void 0 ? "" : y(r, n);
}
function ve(e) {
	return b(e.key, "en", e.params);
}
function ye(e, t = "en") {
	let n = typeof e.messageKey == "string" ? e.messageKey : void 0, r = n === void 0 ? void 0 : v(n, t), i = e.params;
	if (t === "zh" && i) {
		let e = n === void 0 ? void 0 : ge(n);
		if (e === "expression.error" || e === "math.computeFailed") {
			let e = typeof i.code == "string" ? v(`error.${i.code}`, "zh") : void 0;
			if (e) {
				let t = typeof i.near == "string" && i.near ? ` 相关源码：${i.near}` : "";
				i = {
					...i,
					detail: e + t
				};
			}
		} else if (e === "runtime.budget" && typeof i.detailKey == "string") {
			let e = v(i.detailKey, "zh");
			e && (i = {
				...i,
				detail: y(e, i)
			});
		}
	}
	let a = r === void 0 ? typeof e.message == "string" ? e.message : String(e.message ?? "") : y(r, i), o = typeof a == "string" ? a : String(a ?? "");
	return o.length > 2e3 ? `${o.slice(0, te - 1)}…` : o;
}
// src/local/compilation/component-kernel.ts
function x(e, t, n) {
	if (!e) return;
	let r = e, i = e.options ?? [], a = e.constraints ?? (r.min !== void 0 || r.max !== void 0 || r.step !== void 0 ? {
		...r.min === void 0 ? {} : { min: { literal: r.min } },
		...r.max === void 0 ? {} : { max: { literal: r.max } },
		...r.step === void 0 ? {} : { step: { literal: r.step } }
	} : void 0), o = e.family ?? (e.kind === "number" ? "number" : e.kind === "boolean" ? "boolean" : e.kind === "array" ? "multi-select" : i.length ? "choice" : "text");
	return {
		...e,
		family: o,
		bind: e.bind ?? "bind",
		initial: e.initial ?? "initial",
		initialRule: e.initialRule ?? n ?? (t === "value" ? e.kind === "boolean" ? "false" : e.kind === "number" ? "nearest-zero" : "empty" : "nearest-zero"),
		...a ? { constraints: a } : {}
	};
}
function be(e) {
	return e.bindings.value;
}
function xe(e) {
	let t = [];
	for (let [n, r] of Object.entries(e.bindings)) n !== "value" && t.push({
		...r,
		slot: n
	});
	return t;
}
function Se(e) {
	return e.slotRelations;
}
function Ce(e) {
	return e.structure ? e.structure : {
		rule: e.childRule ?? (e.form === "leaf" ? "none" : e.form === "inline" ? "inline" : "any"),
		label: e.label ?? "none",
		...e.parent ? { parents: e.parent } : {}
	};
}
function we(e) {
	return e.structure;
}
function S(e) {
	return e.rules ?? [];
}
function Te(e, t) {
	for (let n of S(e)) if (n.kind === t) return n;
}
function Ee(e, t) {
	return S(e).filter((e) => e.kind === t);
}
function De(e) {
	return e.legacyHost === !0;
}
function C(e, t) {
	if (t === e.bind) return e.options, {
		kind: "string",
		static: !0
	};
	switch (e.kind) {
		case "number": return {
			kind: "number",
			static: !0
		};
		case "boolean": return {
			kind: "boolean",
			static: !0
		};
		default: return {
			kind: "string",
			static: !0
		};
	}
}
function Oe(e, t) {
	let n = { ...e.props }, r = t?.bindings ?? e.bindings, i = r?.value ?? e.binding, a = r ? Object.entries(r).filter(([e]) => e !== "value").map(([, e]) => e) : (e.slots ?? []).map((e) => ({
		kind: e.kind,
		family: e.family,
		bind: e.bind,
		initial: e.initial,
		initialRule: e.initialRule ?? "nearest-zero"
	}));
	for (let e of i ? [i] : []) Object.hasOwn(n, e.bind) || (n[e.bind] = C(e, e.bind)), Object.hasOwn(n, e.initial) || (n[e.initial] = C(e, e.initial)), Object.hasOwn(n, "disabled") || (n.disabled = {
		kind: "boolean",
		dynamic: !0,
		default: !1
	});
	for (let e of a) Object.hasOwn(n, e.bind) || (n[e.bind] = C(e, e.bind)), Object.hasOwn(n, e.initial) || (n[e.initial] = C(e, e.initial));
	return {
		...e,
		props: n,
		...t?.structure ?? e.structure ? { structure: t?.structure ?? e.structure } : {},
		...t?.rules ?? e.rules ? { rules: t?.rules ?? e.rules } : {},
		...r ? { bindings: r } : {},
		...t?.slotRelations ?? e.slotRelations ? { slotRelations: t?.slotRelations ?? e.slotRelations } : {},
		...t?.legacyHost === !0 || e.legacyHost === !0 ? { legacyHost: !0 } : {}
	};
}
function w(e, t) {
	let n = Oe(e, t), r = {}, i = t?.bindings ?? e.bindings;
	if (i) for (let [t, n] of Object.entries(i)) {
		let i = x(n, t, t === "value" ? e.initialRule : void 0);
		i && (r[t] = i);
	}
	else if (e.binding) {
		let t = x(e.binding, "value", e.initialRule);
		t && (r.value = t);
	}
	for (let t of e.slots ?? []) {
		if (r[t.name] !== void 0) continue;
		let e = x({
			kind: t.kind,
			family: t.family,
			bind: t.bind,
			initial: t.initial,
			...t.exclusive === void 0 ? {} : { exclusive: t.exclusive },
			...t.initialRule === void 0 ? {} : { initialRule: t.initialRule }
		}, t.name);
		e && (r[t.name] = e);
	}
	let a = {};
	for (let [e, t] of Object.entries(n.props)) {
		let n = t.values ?? t.enum;
		if (n === void 0) {
			a[e] = t;
			continue;
		}
		let { enum: r, ...i } = t;
		a[e] = {
			...i,
			values: n
		};
	}
	return Object.freeze({
		name: n.name,
		form: n.form,
		props: Object.freeze(a),
		bindings: Object.freeze(r),
		structure: Ce(n),
		rules: n.rules ?? [],
		slotRelations: n.slotRelations ?? [],
		legacyHost: n.legacyHost === !0
	});
}
function T(e, t, n) {
	if (n === void 0) return;
	let r = t[n];
	if (r) return !r.dynamic && typeof r.value == "number" ? r.value : void 0;
	let i = e.props[n]?.default;
	return typeof i == "number" ? i : void 0;
}
function E(e, t, n) {
	if (n === void 0) return;
	let r = t[n];
	if (r) return !r.dynamic && typeof r.value == "string" ? r.value : void 0;
	let i = e.props[n]?.default;
	return typeof i == "string" ? i : void 0;
}
function D(e, t, n) {
	return n === void 0 ? t : e[n]?.offset ?? t;
}
function ke(e, t, n) {
	let r = [], i = e.name, a = i, o = (e, t, n, i, a) => {
		r.push({
			code: e,
			message: t,
			start: n,
			key: i,
			...a ? { params: a } : {}
		});
	};
	for (let r of S(e)) switch (r.kind) {
		case "numeric-range": {
			let s = T(e, t, r.min), c = T(e, t, r.max);
			s !== void 0 && c !== void 0 && (r.order === "increasing" ? !(s < c) : s > c) && o("local.constraint", r.order === "increasing" ? `${i} ${r.min ?? "min"} must be less than ${r.max ?? "max"}.` : `Component <${i}> min cannot exceed max.`, D(t, n.start, r.min), r.order === "increasing" ? "local.constraint.plot-range" : "local.constraint.number-min-max", r.order === "increasing" ? void 0 : { component: a });
			let l = T(e, t, r.step);
			l === void 0 || l > 0 && Number.isFinite(l) || o("local.constraint", `Component <${i}> step must be greater than 0.`, D(t, n.start, r.step), "local.constraint.number-step", { component: a });
			let u = r.integer;
			if (u !== void 0) {
				let r = T(e, t, u);
				r !== void 0 && !Number.isInteger(r) && o("local.constraint", `Attribute ${u} must be a whole number.`, D(t, n.start, u), "local.constraint.integer", {
					name: u,
					component: a
				});
			}
			if (r.positiveInteger !== void 0) {
				let i = T(e, t, r.positiveInteger);
				i !== void 0 && (!Number.isInteger(i) || i <= 0) && o("local.constraint", `Attribute ${r.positiveInteger} must be a positive whole number.`, D(t, n.start, r.positiveInteger), "local.constraint.positive-integer", {
					name: r.positiveInteger,
					component: a
				});
			}
			break;
		}
		case "text-length": {
			let i = T(e, t, r.min) ?? 0, a = T(e, t, r.max);
			a !== void 0 && a < i && o("local.constraint", "max-length cannot be less than min-length.", D(t, n.start, r.max), "local.constraint.length-order");
			break;
		}
		case "date-bounds": {
			let i = E(e, t, r.min), a = E(e, t, r.max);
			i !== void 0 && !O(i) && o("local.attribute.type", `Date lower bound ${i} is not a valid YYYY-MM-DD.`, D(t, n.start, r.min), "local.attribute.type.date-lower", { value: i }), a !== void 0 && !O(a) && o("local.attribute.type", `Date upper bound ${a} is not a valid YYYY-MM-DD.`, D(t, n.start, r.max), "local.attribute.type.date-upper", { value: a }), i && a && i > a && o("local.constraint", "Date min cannot be later than max.", D(t, n.start, r.min), "local.constraint.date-order");
			break;
		}
		case "nonempty": {
			let e = t[r.attribute];
			if (!e || e.dynamic) break;
			(typeof e.value == "string" ? e.value : String(e.raw ?? "")).trim() || o("local.constraint", `Attribute ${r.attribute} of <${i}> cannot be empty.`, e.offset, `local.constraint.${i}-${r.attribute}`, {
				name: r.attribute,
				component: a
			});
			break;
		}
		case "progress-bounds": {
			let n = T(e, t, r.max) ?? r.defaultMax, i = t[r.value];
			i && !i.dynamic && typeof i.value == "number" && (i.value < 0 || i.value > n) && o("local.constraint", `progress value must be between 0 and ${n}, got ${i.value}.`, i.offset, "local.constraint.progress-range", {
				max: n,
				value: i.value
			});
			break;
		}
		case "timer-duration": {
			let i = T(e, t, r.attribute) ?? r.default;
			(!Number.isInteger(i) || i <= 0) && o("local.constraint", "timer duration must be a positive whole number of seconds.", D(t, n.start, r.attribute), "local.constraint.timer-duration");
			break;
		}
		case "option-count": {
			let a = T(e, t, r.max);
			a !== void 0 && (!Number.isInteger(a) || a < 0) && o("local.constraint", `${i} ${r.max} must be a nonnegative whole number.`, D(t, n.start, r.max), `local.constraint.${i}`);
			break;
		}
		case "selection-requires":
			if (Object.hasOwn(t, r.key)) break;
			for (let e of r.attributes) {
				let n = t[e];
				n && o("local.selection.key", `<${i}> ${e} requires a key attribute naming the selection column.`, n.offset, "local.selection.key.required", {
					component: a,
					name: e
				});
			}
	}
	return r;
}
var Ae = /^(\d{4})-(\d{2})-(\d{2})$/;
function O(e) {
	if (e === "") return !0;
	let t = Ae.exec(e);
	if (!t) return !1;
	let n = Number(t[1]), r = Number(t[2]), i = Number(t[3]);
	return n < 1 || r < 1 || r > 12 || i < 1 ? !1 : i <= [
		31,
		n % 4 == 0 && n % 100 != 0 || n % 400 == 0 ? 29 : 28,
		31,
		30,
		31,
		30,
		31,
		31,
		30,
		31,
		30,
		31
	][r - 1];
}
function k(e, t, n) {
	if (n === void 0) return;
	if ("literal" in n) return n.literal;
	let r = t[n.prop];
	if (r) return r.dynamic ? void 0 : typeof r.value == "number" ? r.value : void 0;
	let i = e.props[n.prop]?.default;
	return typeof i == "number" ? i : void 0;
}
function je(e, t, n) {
	let r = t.constraints;
	if (!r) return { step: 1 };
	let i = k(e, n, r.min), a = k(e, n, r.max), o = k(e, n, r.step) ?? 1, s = (e) => {
		if (e === void 0 || !("prop" in e)) return;
		let t = n[e.prop];
		return t?.dynamic ? (t.expression ?? "").trim() : void 0;
	}, c = s(r.min), l = s(r.max);
	return {
		...i === void 0 ? {} : { min: i },
		...a === void 0 ? {} : { max: a },
		step: o > 0 ? o : 1,
		...c === void 0 ? {} : { dynamicMin: c },
		...l === void 0 ? {} : { dynamicMax: l }
	};
}
function Me(e, t, n) {
	return k(e, n, t.maxItems);
}
function Ne(e, t, n) {
	let r = n === "min" ? e.dynamicMin : e.dynamicMax, i = n === "min" ? t.dynamicMin : t.dynamicMax;
	return r !== void 0 || i !== void 0 ? r === i : e[n] === t[n];
}
function Pe(e) {
	return `[${e.dynamicMin === void 0 ? e.min === void 0 ? "-∞" : String(e.min) : `{{ ${e.dynamicMin} }}`}, ${e.dynamicMax === void 0 ? e.max === void 0 ? "∞" : String(e.max) : `{{ ${e.dynamicMax} }}`}] / ${e.step}`;
}
function Fe(e, t, n) {
	let r = (e - t) / n;
	return Math.abs(r - Math.round(r)) <= 1e-9 * Math.max(1, Math.abs(r));
}
function Ie(e, t, n) {
	let r = e ?? 0, i = e === void 0 ? -Infinity : Math.ceil((e - r) / n), a = t === void 0 ? Infinity : Math.floor((t - r) / n);
	if (i > a) return null;
	let o = -r / n, s = null;
	for (let e of [Math.floor(o), Math.ceil(o)]) {
		let t = Math.min(a, Math.max(i, e));
		if (!Number.isFinite(t)) continue;
		if (s === null) {
			s = t;
			continue;
		}
		let o = r + t * n, c = r + s * n;
		(Math.abs(o) < Math.abs(c) || Math.abs(o) === Math.abs(c) && o < c) && (s = t);
	}
	if (s === null) return null;
	let c = r + s * n;
	return e !== void 0 && c < e || t !== void 0 && c > t ? null : c;
}
function Le(e, t, n) {
	switch (e) {
		case "empty": return { value: "" };
		case "false": return { value: !1 };
		case "min": return { value: t?.min ?? 0 };
		case "nearest-zero": {
			let e = t ?? { step: 1 }, n = Ie(e.min, e.max, e.step);
			return n === null ? { error: "no-step" } : { value: n };
		}
		case "duration": return { value: t?.max ?? 60 };
		case "first-option":
		case "first-tab":
		case "first-step":
		case "first-node": return { value: n[0] ?? "" };
		case "checked": return { value: [] };
		case "empty-array": return { value: [] };
		case "max-step": {
			let e = t ?? { step: 1 }, n = e.min ?? 0, r = (e.max ?? n) - n, i = n + Math.max(0, Math.floor(r / e.step + 1e-9)) * e.step;
			return { value: Math.min(e.max ?? i, Math.max(e.min ?? i, i)) };
		}
		case "none": return { value: "" };
		default: return { error: "cannot-derive" };
	}
}
function Re(e) {
	switch (e) {
		case "choice":
		case "multi-select": return "options";
		case "tabs": return "tabs";
		case "steps": return "steps";
		case "selection": return "selection";
		case "diagram": return "diagram-nodes";
		case "checklist": return "checklist";
		default: return;
	}
}
function A(e) {
	let t = {};
	for (let [n, r] of Object.entries(e)) r !== void 0 && (t[n] = r);
	return t;
}
function ze(e) {
	let t = [];
	for (let n of S(e)) switch (n.kind) {
		case "value-date":
			t.push(A({
				kind: "date",
				min: n.min,
				max: n.max,
				required: n.required
			}));
			break;
		case "value-length":
			t.push(A({
				kind: "length",
				min: n.min,
				max: n.max
			})), (n.email !== void 0 || n.emailType !== void 0) && t.push(A({
				kind: "email",
				type: n.email ?? "type",
				value: n.emailType ?? "email"
			}));
			break;
		case "value-email":
			t.push(A({
				kind: "email",
				type: n.type ?? "type",
				value: n.value ?? "email"
			}));
			break;
		case "value-required": t.push({
			kind: "required",
			required: n.required
		});
	}
	return t;
}
function Be(e) {
	if (!e || typeof e != "object") return;
	let t = e.kernel;
	if (t && typeof t == "object") return t;
}
var Ve = /^[A-Za-z_][A-Za-z0-9_-]*$/;
function He(e) {
	return Ve.test(e);
}
function Ue(e, t, n) {
	let r = [];
	for (let i of e) {
		let e = i.target;
		e ? e.startsWith("#") || /\s/.test(e) ? r.push({
			code: "local.jump.target",
			message: `<${i.name}> target "${e}" must be a bare heading slug or anchor id without "#" or whitespace.`,
			start: i.offset,
			key: "local.jump.bad-target",
			params: { target: e }
		}) : !t.has(e) && !n.has(e) && r.push({
			code: "local.jump.target",
			message: `<${i.name}> target "${e}" does not resolve to a heading or explicit anchor in this document.`,
			start: i.offset,
			key: "local.jump.unresolved",
			params: { target: e }
		}) : r.push({
			code: "local.jump.target",
			message: "<jump> target cannot be empty.",
			start: i.offset,
			key: "local.jump.empty"
		});
	}
	return r;
}
Object.freeze({
	arrayLength: c,
	dataTableColumns: 20,
	plotCurves: 16,
	plotPoints: ee
});
// src/local/html/html-names.ts
var j = /* @__PURE__ */ new Set(/* @__PURE__ */ "b.strong.i.em.s.del.u.mark.sup.sub.br.hr.img.p.h1.h2.h3.h4.h5.h6.div.span.details.summary.blockquote.code.pre.ul.ol.li.a".split(".")), We = /* @__PURE__ */ new Set([
	"div",
	"p",
	"h1",
	"h2",
	"h3",
	"h4",
	"h5",
	"h6"
]);
function Ge(e) {
	let t = e.trim().toLowerCase();
	return t === "left" || t === "center" || t === "right" || t === "justify" ? t : null;
}
var Ke = /* @__PURE__ */ new Set([
	"href",
	"target",
	"rel"
]);
function qe(e, t) {
	if (t?.toLowerCase() !== "_blank") return e;
	let n = [], r = /* @__PURE__ */ new Set();
	for (let t of (e ?? "").split(/[\t\n\f\r ]+/)) {
		let e = t.toLowerCase();
		t && e !== "opener" && !r.has(e) && (r.add(e), n.push(t));
	}
	for (let e of ["noopener", "noreferrer"]) r.has(e) || n.push(e);
	return n.join(" ");
}
var M = Object.freeze([
	Object.freeze({
		name: "computed",
		form: "leaf",
		childRule: "none",
		label: "none",
		props: {
			name: {
				kind: "string",
				static: !0,
				required: !0
			},
			value: {
				kind: "string",
				required: !0
			}
		},
		structure: {
			rule: "none",
			label: "none"
		},
		rules: [{
			kind: "require-full-interpolation",
			attributes: ["value"]
		}]
	}),
	Object.freeze({
		name: "const",
		form: "leaf",
		childRule: "none",
		label: "none",
		props: {
			name: {
				kind: "string",
				static: !0,
				required: !0
			},
			value: {
				kind: "string",
				required: !0
			}
		},
		structure: {
			rule: "none",
			label: "none"
		},
		rules: [{
			kind: "require-full-interpolation",
			attributes: ["value"]
		}]
	}),
	Object.freeze({
		name: "external",
		form: "leaf",
		childRule: "none",
		label: "none",
		props: {
			name: {
				kind: "string",
				static: !0,
				required: !0
			},
			type: {
				kind: "enum",
				static: !0,
				required: !0,
				values: [
					"string",
					"number",
					"boolean",
					"string-array",
					"number-array"
				]
			}
		},
		structure: {
			rule: "none",
			label: "none"
		}
	})
]);
function Je(e, t) {
	let n = Array.from({ length: t.length + 1 }, (e, t) => t);
	for (let r = 1; r <= e.length; r++) {
		let i = n[0];
		n[0] = r;
		for (let a = 1; a <= t.length; a++) {
			let o = n[a];
			n[a] = Math.min(n[a] + 1, n[a - 1] + 1, i + (e[r - 1] === t[a - 1] ? 0 : 1)), i = o;
		}
	}
	return n[t.length];
}
function Ye(e, t) {
	let n, r = Infinity;
	for (let i of t) {
		let t = Je(e, i);
		t < r && (n = i, r = t);
	}
	return r <= 2 ? n : void 0;
}
// src/local/theme/theme-name.ts
var Xe = /^[a-z][a-z0-9]*(?:-[a-z0-9]+)*$/;
function Ze(e) {
	return typeof e == "string" && e.length > 0 && e.length <= 64 && Xe.test(e);
}
// src/sdk/registry-core.ts
var N = /* @__PURE__ */ new WeakMap();
function Qe(e) {
	return {
		kind: e.kind,
		...e.required === !0 ? { required: !0 } : {},
		...e.static === !0 ? { static: !0 } : {},
		...e.dynamic === void 0 ? {} : { dynamic: e.dynamic },
		...e.default === void 0 ? {} : { default: e.default },
		...e.nullable === !0 ? { nullable: !0 } : {},
		...e.enum ? { values: [...e.enum] } : {},
		...e.pattern === void 0 ? {} : { pattern: e.pattern },
		...e.min === void 0 ? {} : { min: e.min },
		...e.max === void 0 ? {} : { max: e.max },
		...e.integer === !0 ? { integer: !0 } : {},
		...e.positive === !0 ? { positive: !0 } : {},
		...e.color === !0 ? { color: !0 } : {},
		...e.coerce === void 0 ? {} : { coerce: e.coerce }
	};
}
function $e(e) {
	return {
		kind: e.kind,
		family: e.family,
		bind: e.bind,
		initial: e.initial,
		initialRule: e.initialRule,
		required: e.required === !0,
		...e.exclusive === !0 ? { exclusive: !0 } : {},
		...e.options ? { options: e.options } : {},
		...e.constraints ? { constraints: e.constraints } : {},
		...e.maxItems ? { maxItems: e.maxItems } : {},
		...e.requiresAttributes ? { requiresAttributes: e.requiresAttributes } : {},
		...e.compare ? { compare: e.compare } : {},
		...e.retain === !1 ? { retain: !1 } : {}
	};
}
function et(e, t) {
	if (t === e.bind) return {
		kind: "string",
		static: !0
	};
	switch (e.kind) {
		case "number": return {
			kind: "number",
			static: !0
		};
		case "boolean": return {
			kind: "boolean",
			static: !0
		};
		default: return {
			kind: "string",
			static: !0
		};
	}
}
function P(e, t) {
	if (e === void 0) return t === "leaf" ? "none" : "any";
	switch (e.rule) {
		case "components": return e.child === "card" ? "cards" : e.child === "disclosure" ? "disclosures" : e.child === "column" ? "columns" : "any";
		default: return e.rule;
	}
}
function F(t) {
	let n = N.get(t);
	if (n !== void 0) return n;
	let r = t.bindings ?? {}, i = t.structure ?? e(t.children), a = r.value, o = [];
	for (let [e, t] of Object.entries(r)) e !== "value" && o.push(Object.freeze({
		name: e,
		bind: t.bind,
		initial: t.initial,
		kind: t.kind,
		family: t.family,
		exclusive: t.exclusive === !0,
		initialRule: t.initialRule
	}));
	let s = {};
	for (let [e, n] of Object.entries(t.props)) s[e] = Qe(n);
	for (let e of Object.values(r)) {
		let t = [e.bind, e.initial];
		for (let n of t) Object.hasOwn(s, n) || (n !== e.initial || e.initialRule !== "checked" && e.initialRule !== "duration") && (s[n] = et(e, n));
	}
	let c = Object.freeze({
		name: t.name,
		form: t.form,
		props: Object.freeze(s),
		...a ? { binding: Object.freeze($e(a)) } : {},
		...Object.keys(r).length ? { bindings: Object.freeze({ ...r }) } : {},
		...o.length ? { slots: Object.freeze(o) } : {},
		...i ? { structure: i } : {},
		...t.rules ? { rules: t.rules } : {},
		...t.slotRelations ? { slotRelations: t.slotRelations } : {},
		...t.legacyHost === !0 ? { legacyHost: !0 } : {},
		childRule: P(i, t.form),
		label: i?.label ?? "none",
		...i?.parents ? { parent: i.parents } : {},
		...a ? { initialRule: a.initialRule } : {}
	});
	return N.set(t, c), c;
}
function tt(e) {
	return F(e);
}
var I = /* @__PURE__ */ new WeakMap();
function nt(t) {
	let n = I.get(t);
	if (n !== void 0) return n;
	let r = t.structure ?? e(t.children), i = w({
		name: t.name,
		form: t.form,
		props: t.props,
		childRule: P(r, t.form)
	}, {
		...r ? { structure: r } : {},
		...t.rules ? { rules: t.rules } : {},
		...t.bindings ? { bindings: t.bindings } : {},
		...t.slotRelations ? { slotRelations: t.slotRelations } : {},
		...t.legacyHost ? { legacyHost: !0 } : {}
	});
	return I.set(t, i), i;
}
// src/sdk/compat-profile.ts
var L = Object.freeze([Object.freeze({
	name: "reactive-md-config/v1@0.7.0",
	protocol: s,
	sdkRange: "0.7.0",
	targetProtocol: n,
	targetSdkRange: "0.7.0",
	preset: Object.freeze({
		id: "reactive-md/default",
		version: "0.7.0"
	}),
	legacyKeys: Object.freeze([Object.freeze({
		profile: s,
		algorithm: "external-components/v1"
	})]),
	source: "git tag v0.7.0:src/presets/default.ts and src/sdk/config.ts; docs/compatibility/compatibility-ch.md"
})]);
function R(e, t = L) {
	for (let n of t) if (n.preset.id === e.id && n.preset.version === e.version) return n;
}
function rt(e = []) {
	return e.length === 0 ? L : Object.freeze([...L, ...e]);
}
// src/sdk/assembly.ts
var it = /* @__PURE__ */ new Set([
	"protocol",
	"presets",
	"components",
	"replacementPolicy",
	"themes"
]), z = 32, B = 256, V = 32;
function H(e, t) {
	throw Error(`Invalid local SDK config (${e}): ${t}`);
}
function U(e, t) {
	return e < t ? -1 : +(e > t);
}
function W(e, t) {
	return [...e].sort((e, n) => U(t(e), t(n)));
}
function G(e) {
	if (typeof e != "object" || !e || Array.isArray(e)) return !1;
	let t = Object.getPrototypeOf(e);
	return t === Object.prototype || t === null;
}
function K(e) {
	if (Array.isArray(e)) return e.map(K);
	if (G(e)) {
		let t = {};
		for (let n of Object.keys(e).sort(U)) t[n] = K(e[n]);
		return t;
	}
	return e;
}
function q(e, t) {
	return JSON.stringify(K(e)) === JSON.stringify(K(t));
}
function at(e) {
	Array.isArray(e) || H("assembly.presets", "must be an array."), e.length > z && H("assembly.presets", `accepts at most ${z} packages.`);
	let t = W(e.map((e, t) => {
		try {
			return u(e);
		} catch (e) {
			H(`assembly.presets[${t}]`, e instanceof Error ? e.message : String(e));
		}
	}), (e) => e.id), n = /* @__PURE__ */ new Set();
	for (let e of t) n.has(e.id) && H("assembly.presets", `preset "${e.id}" is selected more than once.`), n.add(e.id);
	return Object.freeze(t);
}
function ot(e) {
	Array.isArray(e) || H("assembly.components", "must be an array."), e.length > B && H("assembly.components", `accepts at most ${B} components.`);
	let t = W(e.map((e, t) => {
		try {
			return f(e);
		} catch (e) {
			H(`assembly.components[${t}]`, e instanceof Error ? e.message : String(e));
		}
	}), (e) => e.id);
	return Object.freeze(t);
}
function st(e) {
	Array.isArray(e) || H("assembly.themes", "must be an array."), e.length > V && H("assembly.themes", `accepts at most ${V} themes.`);
	let t = /* @__PURE__ */ new Set();
	return Object.freeze(W(e.map((e, n) => {
		G(e) || H(`assembly.themes[${n}]`, "must be an object.");
		let r = e.id, a = e.name, o = e.version;
		return (typeof r != "string" || r.length === 0) && H(`assembly.themes[${n}].id`, "must be a non-empty string."), (typeof a != "string" || a.length === 0) && H(`assembly.themes[${n}].name`, "must be a non-empty string."), typeof o == "string" && i(o) || H(`assembly.themes[${n}].version`, "must be a semantic version."), t.has(r) && H("assembly.themes", `theme id "${r}" is declared more than once.`), t.add(r), Object.freeze({ ...e });
	}), (e) => e.id));
}
function ct(e) {
	G(e) || H("assembly", "must be an object.");
	for (let t of Object.keys(e)) it.has(t) || H("assembly", `unknown field "${t}".`);
	e.protocol !== "reactive-md-assembly/v1" && H("assembly.protocol", `must be "${a}".`);
	let t = e.replacementPolicy;
	return t !== "allow" && t !== "forbid" && H("assembly.replacementPolicy", "must be \"allow\" or \"forbid\"."), Object.freeze({
		protocol: a,
		presets: at(e.presets),
		components: ot(e.components),
		replacementPolicy: t,
		themes: st(e.themes)
	});
}
function lt(e) {
	let t = new Map(e.map((e) => [e.id, e])), n = /* @__PURE__ */ new Map(), r = [], a = (e) => {
		let o = n.get(e);
		if (o === "done") return;
		o === "visiting" && H("assembly.presets", `preset dependency cycle at "${e}".`);
		let s = t.get(e);
		s || H("assembly.presets", `missing preset dependency "${e}".`), n.set(e, "visiting");
		for (let e of W(s.dependencies ?? [], (e) => e.id)) {
			let n = t.get(e.id);
			n || H("assembly.presets", `preset "${s.id}" requires missing preset "${e.id}".`), i(e.version) || H("assembly.presets", `preset dependency "${e.id}" must use an exact version.`), n.version !== e.version && H("assembly.presets", `preset "${s.id}" requires "${e.id}" ${e.version}, but ${n.version} is installed.`), a(e.id);
		}
		n.set(e, "done"), r.push(s);
	};
	for (let e of [...t.keys()].sort(U)) a(e);
	return Object.freeze(r);
}
function J(e) {
	let { description: t, ...n } = e;
	return n;
}
function Y(t) {
	return t.structure ?? e(t.children) ?? null;
}
function ut(e, t) {
	for (let n of [
		"interactive",
		"static",
		"ssr",
		"offline"
	]) if (t.capabilities[n] && !e.capabilities[n]) return !1;
	return !0;
}
function dt(e, t) {
	let n = e.definition, r = t.definition, i = `assembly.replacements["${n.id}"]`;
	(n.id !== r.id || n.name !== r.name) && H(i, "the replacement must keep the target id and tag name."), n.form !== r.form && H(i, "the replacement must keep the target form.");
	for (let e of Object.keys(n.props)) {
		let t = n.props[e], a = r.props[e];
		a || H(i, `the replacement removed prop "${e}".`), q(J(t), J(a)) || H(i, `the replacement changed the semantics of prop "${e}".`);
	}
	for (let e of Object.keys(r.props)) Object.hasOwn(n.props, e) || r.props[e].required === !0 && H(i, `the replacement added required prop "${e}".`);
	let a = n.bindings ?? {}, o = r.bindings ?? {}, s = Object.keys(a).sort(U);
	q(s, Object.keys(o).sort(U)) || H(i, "the replacement must keep the target binding slots unchanged.");
	for (let e of s) q(a[e], o[e]) || H(i, `the replacement changed binding slot "${e}".`);
	q(Y(n), Y(r)) || H(i, "the replacement changed the target child structure."), q(n.rules ?? [], r.rules ?? []) || H(i, "the replacement changed semantic rules."), q(n.slotRelations ?? [], r.slotRelations ?? []) || H(i, "the replacement changed slot relations."), n.legacyHost === !0 != (r.legacyHost === !0) && H(i, "the replacement changed legacyHost."), ut(r, n) || H(i, "the replacement downgraded a declared capability.");
}
function ft(e, t) {
	return e.id === t.id ? t.version === void 0 || r(t.version) !== null && l(e.version, t.version) : !1;
}
function pt(e, n) {
	return Object.freeze({
		id: e.definition.id,
		name: e.definition.name,
		fromVersion: e.definition.version,
		toVersion: n.definition.version,
		fromDigest: t(e.definition),
		toDigest: t(n.definition),
		...e.origin.kind === "preset" ? { fromPreset: e.origin.id } : {},
		...n.origin.kind === "preset" ? { toPreset: n.origin.id } : {}
	});
}
function mt(e, t) {
	let n = [], r = 0;
	for (let t of e) for (let e of t.components) n.push({
		definition: e,
		origin: {
			kind: "preset",
			id: t.id
		},
		index: r
	}), r += 1;
	for (let e of W(t, (e) => e.id)) n.push({
		definition: e,
		origin: { kind: "external" },
		index: r
	}), r += 1;
	return n;
}
function ht(e) {
	let t = /* @__PURE__ */ new Map();
	for (let n of e) n.authoring !== void 0 && n.authoring.length !== 0 && t.set(n.id, new Map(n.authoring.map((e) => [e.componentId, e.authoring])));
	return t;
}
function X(e, t) {
	return t === void 0 ? e : e === void 0 ? t : Object.freeze({
		...e.title === void 0 ? {} : { title: e.title },
		...e.description === void 0 ? {} : { description: e.description },
		...e.category === void 0 ? {} : { category: e.category },
		...e.insertText === void 0 ? {} : { insertText: e.insertText },
		...t.title === void 0 ? {} : { title: t.title },
		...t.description === void 0 ? {} : { description: t.description },
		...t.category === void 0 ? {} : { category: t.category },
		...t.insertText === void 0 ? {} : { insertText: t.insertText }
	});
}
function Z(e, t) {
	let n = e.origin.kind === "preset" ? t.get(e.origin.id)?.get(e.definition.id) : void 0;
	return X(e.definition.authoring, n);
}
function gt(e, t) {
	return t === void 0 || t === e.authoring ? e : f({
		...e,
		authoring: t
	});
}
function _t(e, t, n) {
	let r = /* @__PURE__ */ new Map();
	for (let t of e) {
		let e = r.get(t.definition.id);
		e ? e.push(t) : r.set(t.definition.id, [t]);
	}
	let i = [], a = [];
	for (let e of r.values()) {
		if (e.length === 1) {
			let r = e[0];
			r.definition.replaces !== void 0 && (t === "forbid" && H("assembly.replacements", `replacement for "${r.definition.id}" is forbidden.`), H("assembly.replacements", `replacement for "${r.definition.id}" has no base contribution.`));
			let a = Z(r, n);
			i.push({
				...r,
				position: r.index,
				...a === void 0 ? {} : { authoring: a }
			});
			continue;
		}
		let r = e.filter((e) => e.definition.replaces !== void 0);
		t === "forbid" && r.length > 0 && H("assembly.replacements", `replacement for "${e[0].definition.id}" is forbidden.`), r.length === 0 && H("assembly.components", `component id "${e[0].definition.id}" is declared more than once.`), r.length > 1 && H("assembly.replacements", `component id "${e[0].definition.id}" has more than one replacement.`), e.length > 2 && H("assembly.replacements", `component id "${e[0].definition.id}" has ambiguous base contributions.`);
		let o = r[0], s = e.filter((e) => e !== o);
		s.length !== 1 && H("assembly.replacements", `component id "${e[0].definition.id}" must have exactly one base.`);
		let c = s[0];
		c.definition.replaces !== void 0 && H("assembly.replacements", `component id "${e[0].definition.id}" uses a replacement chain.`);
		let l = o.definition.replaces;
		ft(c.definition, l) || H("assembly.replacements", `replacement for "${c.definition.id}" does not match base version ${c.definition.version}.`), dt(c, o);
		let u = X(Z(c, n), Z(o, n));
		i.push({
			...o,
			position: c.index,
			...u === void 0 ? {} : { authoring: u }
		}), a.push(pt(c, o));
	}
	return i.sort((e, t) => e.position - t.position), {
		active: Object.freeze(i),
		replacements: Object.freeze(W(a, (e) => e.id))
	};
}
function vt(e) {
	let t = /* @__PURE__ */ new Map(), n = new Map(e.map((e) => [e.definition.id, e.definition]));
	for (let r of e) {
		let e = r.definition, i = t.get(e.name);
		i !== void 0 && ((i.origin.kind === "preset" || r.origin.kind === "preset") && H("assembly.components", `name "${e.name}" conflicts with a built-in component "${i.definition.id}".`), H("assembly.components", `component name "${e.name}" is declared more than once by "${i.definition.id}" and "${e.id}".`)), t.set(e.name, r);
		let a = e.requires?.kernel;
		a !== void 0 && !l("0.7.0", a) && H("assembly.components", `component "${e.id}" requires kernel ${a}, but ${m} is installed.`);
		for (let t of e.dependencies ?? []) {
			let r = n.get(t.id);
			r || H("assembly.dependencies", `component "${e.id}" requires missing component "${t.id}".`), t.version !== void 0 && !l(r.version, t.version) && H("assembly.dependencies", `component "${e.id}" requires "${t.id}" ${t.version}, but version ${r.version} is installed.`);
		}
	}
	let r = /* @__PURE__ */ new Map(), i = (e, t) => {
		let a = r.get(e);
		if (a !== "done") {
			a === "visiting" && H("assembly.dependencies", `dependency cycle: ${[...t, e].join(" -> ")}.`), r.set(e, "visiting");
			for (let r of n.get(e)?.dependencies ?? []) n.has(r.id) && i(r.id, [...t, e]);
			r.set(e, "done");
		}
	};
	for (let e of [...n.keys()].sort(U)) i(e, []);
}
function yt(e, t) {
	let n = /* @__PURE__ */ new Map(), r = /* @__PURE__ */ new Map(), i = (e, t) => {
		n.get(e.id) && H("assembly.themes", `theme id "${e.id}" is declared by both ${t} and another source.`), r.get(e.name) && H("assembly.themes", `theme name "${e.name}" is declared by both ${t} and another source.`), n.set(e.id, e), r.set(e.name, e);
	};
	for (let t of e) for (let e of t.themes ?? []) i(e, `preset:${t.id}`);
	for (let e of t) i(e, "external");
	return Object.freeze(W([...n.values()], (e) => e.id));
}
function bt(e) {
	return Object.freeze(W(e.map((e) => ({
		id: e.id,
		version: e.version,
		digest: d(e)
	})), (e) => e.id));
}
function xt(e, r, i) {
	let a = JSON.stringify({
		protocol: n,
		presets: W(e, (e) => e.id),
		registry: [...r].map((e) => ({
			id: e.id,
			name: e.name,
			version: e.version,
			digest: t(e)
		})).sort((e, t) => U(e.id, t.id)),
		replacements: W(i, (e) => e.id)
	});
	return p(a);
}
function Q(e, n) {
	let r = JSON.stringify({
		protocol: s,
		presets: [{
			id: e.id,
			version: e.version
		}],
		components: [...n].map((e) => ({
			id: e.id,
			version: e.version,
			digest: t(e)
		})).sort((e, t) => U(e.id, t.id))
	});
	return p(r);
}
function St(e, t = {}) {
	let n = lt(e.presets), r = _t(mt(n, e.components), e.replacementPolicy, ht(n));
	vt(r.active);
	let i = Object.freeze(r.active.map((e) => gt(e.definition, e.authoring))), a = Object.freeze(W(r.active.filter((e) => e.origin.kind === "external").map((e) => e.definition), (e) => e.id)), o = bt(n), s = yt(n, e.themes), c = xt(o, i, r.replacements), l = [], u = t.legacyProfiles === void 0 || n.length !== 1 || r.replacements.length !== 0 ? void 0 : R({
		id: n[0].id,
		version: n[0].version
	}, t.legacyProfiles), d = u?.legacyKeys[0];
	return u !== void 0 && d !== void 0 && l.push(Object.freeze({
		profile: d.profile,
		key: Q(u.preset, a)
	})), Object.freeze({
		presets: o,
		components: a,
		replacements: r.replacements,
		registry: i,
		themes: s,
		key: c,
		legacyKeys: Object.freeze(l)
	});
}
function Ct(e, t, r = t.legacyKeys) {
	return Object.freeze({
		protocol: n,
		assembly: e,
		key: t.key,
		presets: t.presets,
		components: t.components,
		replacements: t.replacements,
		registry: t.registry,
		themes: t.themes,
		legacyKeys: Object.freeze(r)
	});
}
function wt(e) {
	return Object.freeze({
		protocol: "reactive-md-assembly-seal/v1",
		configKey: e.key,
		presets: Object.freeze(W(e.presets, (e) => e.id)),
		components: Object.freeze(W(e.registry.map(o), (e) => e.id)),
		replacements: Object.freeze(W(e.replacements, (e) => e.id)),
		legacyKeys: Object.freeze(W(e.legacyKeys, (e) => e.key))
	});
}
function Tt(e) {
	return p(JSON.stringify(wt(e)));
}
function Et(e, t) {
	return e.key === t || e.legacyKeys.some((e) => e.key === t);
}
// src/sdk/config-validation.ts
var Dt = 16777216, Ot = /* @__PURE__ */ new Set([
	"__proto__",
	"constructor",
	"prototype"
]), kt = /* @__PURE__ */ new Set([
	"protocol",
	"key",
	"assembly",
	"presets",
	"components",
	"replacements",
	"registry",
	"themes",
	"legacyKeys"
]);
function $(e, t) {
	throw Error(`Invalid local SDK config (${e}): ${t}`);
}
function At(e) {
	if (typeof e != "object" || !e || Array.isArray(e)) return !1;
	let t = Object.getPrototypeOf(e);
	return t === Object.prototype || t === null;
}
function jt(e, t, n) {
	for (let r of Object.keys(e)) Ot.has(r) && $(n, `field "${r}" is not allowed.`), t.has(r) || $(n, `unknown field "${r}".`);
}
function Mt(e, t, n = []) {
	if (e === void 0) return Object.freeze([t]);
	Array.isArray(e) || $("presets", "must be an array."), e.length === 0 && $("presets", "must select at least the default preset.");
	let r = [];
	for (let e of [t, ...n.map((e) => e.preset)]) r.some((t) => t.id === e.id && t.version === e.version) || r.push(e);
	let i = /* @__PURE__ */ new Set(), a = [];
	for (let n = 0; n < e.length; n += 1) {
		let o = e[n], s, c;
		typeof o == "string" ? s = o : At(o) ? ((o.id === void 0 || typeof o.id != "string") && $(`presets[${n}].id`, "must be a string."), s = o.id, o.version !== void 0 && (typeof o.version != "string" && $(`presets[${n}].version`, "must be a string."), c = o.version)) : $(`presets[${n}]`, "must be a preset id or preset reference.");
		let l = s === "default" ? t.id : s, u = r.filter((e) => e.id === l);
		u.length === 0 && $(`presets[${n}]`, `unsupported preset "${s}"; local.config.migration-unsupported: no compatibility profile matches this identity.`);
		let d = c === void 0 ? u.length === 1 ? u[0] : void 0 : u.find((e) => e.version === c);
		d === void 0 && $(`presets[${n}]`, `unsupported preset "${s}"${c === void 0 ? "" : ` version "${c}"`}; local.config.migration-unsupported: no compatibility profile matches this identity.`), i.has(d.id) && $("presets", `"${d.id}" is selected more than once.`), a.length > 0 && a[0].id !== d.id && $("presets", "reactive-md-config/v1 selects exactly one default preset identity."), i.add(d.id), a.push(d);
	}
	return Object.freeze(a);
}
function Nt(e, n) {
	if (e.components === void 0) return;
	let r = new Map(n.map((e) => [e.id, e]));
	for (let n of e.components) {
		let i = r.get(n.id);
		i && i.name === n.name && i.version === n.version && t(i) === n.digest || $("presets", `local.config.migration-unsupported: profile "${e.name}" cannot map legacy component "${n.id}".`);
	}
}
function Pt(e) {
	let t = /* @__PURE__ */ new Set();
	for (let n of e) t.add(n.name), t.add(n.id);
	return t;
}
function Ft(e, t) {
	let n = new Map(e.map((e) => [e.id, e])), r = Pt(t);
	for (let t of e) {
		let e = t.requires?.kernel;
		e !== void 0 && !l("0.7.0", e) && $("requires", `component "${t.id}" requires kernel ${e}, but ${m} is installed.`);
		for (let e of t.dependencies ?? []) {
			let i = n.get(e.id)?.version ?? (r.has(e.id) ? "0.7.0" : null);
			i === null && $("dependencies", `component "${t.id}" requires missing component "${e.id}".`), e.version !== void 0 && !l(i, e.version) && $("dependencies", `component "${t.id}" requires "${e.id}" ${e.version}, but version ${i} is installed.`);
		}
	}
	let i = /* @__PURE__ */ new Map(), a = (e, t) => {
		let r = i.get(e);
		if (r === "done") return;
		r === "visiting" && $("dependencies", `dependency cycle: ${[...t, e].join(" -> ")}.`), i.set(e, "visiting");
		let o = n.get(e);
		for (let r of o?.dependencies ?? []) n.has(r.id) && a(r.id, [...t, e]);
		i.set(e, "done");
	};
	for (let e of n.keys()) a(e, []);
}
function It(e, t) {
	if (e === void 0) return Object.freeze([]);
	Array.isArray(e) || $("components", "must be an array."), e.length > 64 && $("components", "accepts at most 64 external components.");
	let n = new Set([
		...t.map((e) => e.name),
		...M.map((e) => e.name),
		...j
	].map((e) => e.toLowerCase()));
	n.add("theme");
	let r = new Set(t.map((e) => e.id)), i = /* @__PURE__ */ new Set(), a = [];
	for (let t = 0; t < e.length; t += 1) {
		let o = f(e[t]);
		n.has(o.name.toLowerCase()) && $(`components[${t}]`, `name "${o.name}" conflicts with a built-in component, HTML tag or theme declaration.`), r.has(o.id) && $("components", `component id "${o.id}" is declared more than once.`), i.has(o.name) && $("components", `component name "${o.name}" is declared more than once.`), r.add(o.id), i.add(o.name), a.push(o);
	}
	return Ft(a, t), Object.freeze(a);
}
export { ve as $, He as A, Re as B, M as C, j as D, Ke as E, Be as F, xe as G, S as H, Me as I, De as J, Se as K, Ue as L, ke as M, Le as N, Ge as O, Pe as P, me as Q, je as R, Ze as S, We as T, Ee as U, Te as V, Ne as W, ze as X, be as Y, w as Z, R as _, At as a, b as at, tt as b, Nt as c, Ct as d, ye as et, Et as f, L as g, St as h, $ as i, he as it, O as j, qe as k, wt as l, ct as m, Dt as n, oe as nt, It as o, Q as p, we as q, jt as r, v as rt, Mt as s, kt as t, _e as tt, Tt as u, rt as v, Ye as w, nt as x, F as y, Fe as z };
