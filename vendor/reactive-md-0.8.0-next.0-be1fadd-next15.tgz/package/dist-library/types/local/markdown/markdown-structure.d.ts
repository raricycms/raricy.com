import type { MarkdownStructure } from './markdown-blocks.js';
/** Lezer is advisory only: its top-level nodes seed candidate ranges. */
export declare function scanMarkdownStructure(source: string): MarkdownStructure;
