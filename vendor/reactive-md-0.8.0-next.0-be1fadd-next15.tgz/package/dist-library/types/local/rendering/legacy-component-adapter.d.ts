import { type ReactNode } from 'react';
import type { Diagnostic, LocalNode, LocalRuntime } from '../contracts/types.js';
import type { LocalRenderMode } from './render-types.js';
import type { LocalLocale, Localize } from '../theme/i18n.js';
import { type LocalComponentContext } from '../../react/component-api.js';
/**
 * Legacy fixture adapter.
 *
 * Older visual/data-table tests build a `LocalNode` and pass a minimal runtime
 * instead of going through `LocalDocumentView`. This module adapts exactly that
 * shape into the public component context and resolves the actual implementation
 * from the default React preset by manifest name. It is a compatibility entry,
 * not a second renderer: all markup comes from `src/components/**`.
 */
export interface LegacyComponentAdapterOptions {
    readonly node: LocalNode;
    readonly runtime: LocalRuntime;
    readonly mode?: LocalRenderMode;
    readonly visible?: boolean;
    /** Legacy block renderer used for the component's parsed children. */
    readonly render?: (nodes?: LocalNode[], visible?: boolean) => ReactNode;
    /** Legacy localizer; defaults to English. */
    readonly t?: Localize;
    readonly locale?: LocalLocale;
    readonly report?: (diagnostics: Diagnostic[]) => void;
}
/**
 * Build the public context for one legacy fixture node. The returned context
 * only exposes public services; the node stays inside this adapter.
 */
export declare function createLegacyComponentContext(options: LegacyComponentAdapterOptions): LocalComponentContext;
/**
 * Render one legacy fixture node through the default manifest implementation.
 * Unknown names keep the previous `null` result.
 */
export declare function renderLegacyComponent(name: string, options: LegacyComponentAdapterOptions): ReactNode;
