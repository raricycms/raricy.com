import type { LocalNode } from '../contracts/types.js';
import type { AttrMap, Entry } from './compiler-structure.js';
export declare function parseNumberText(raw: string): number | null;
export declare function meaningful(nodes: LocalNode[] | undefined): LocalNode[];
export declare function hasComponent(node: LocalNode): boolean;
/** Static numeric attribute value, or the manifest prop default. */
export declare function numberValue(entry: Entry, attrs: AttrMap, name: string | undefined): number | undefined;
/** Static string attribute value, or the manifest prop default. */
export declare function staticAttributeString(entry: Entry, attrs: AttrMap, name: string | undefined): string | undefined;
