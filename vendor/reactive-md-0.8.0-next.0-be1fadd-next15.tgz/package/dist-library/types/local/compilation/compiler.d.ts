/**
 * Compatibility facade for the historical compile entry points.
 *
 * The semantic pass lives in `compiler-core.ts`; this module keeps the
 * documented `compileLocal` / `compileLocalTracked` / `compileLocalDocument`
 * signatures and their exact default behavior, including option validation,
 * the concrete semantic cache and the KaTeX display precheck.
 */
import type { LocalCompileOptions, LocalCompileResult } from '../contracts/types.js';
import { LocalSemanticCache, type SemanticCacheStats } from '../session/compiler-cache.js';
import { parseLocal } from '../parsing/parser.js';
import type { InlinePlanLookup } from '../markdown/fast-markdown.js';
import type { SourceContext } from '../source/source-context.js';
/** Compile to plain data that can cross a React Server Component boundary. */
export declare function compileLocal(source: string, options?: LocalCompileOptions): LocalCompileResult;
/** Compiler-owned capture for editor sessions. Callers must copy before publishing. */
export interface LocalCompilerServices {
    parser?: {
        parse(source: string, options?: LocalCompileOptions, context?: SourceContext, rowPlans?: InlinePlanLookup): ReturnType<typeof parseLocal>;
    };
    semantic?: LocalSemanticCache;
    /**
     * Per-row inline plans from the previous revision. Checked before the
     * session LRU so large sequential row blocks cannot thrash it.
     */
    rowPlans?: InlinePlanLookup;
}
export declare function compileLocalTracked(source: string, options?: LocalCompileOptions, services?: LocalCompilerServices): {
    result: LocalCompileResult;
    parsed?: ReturnType<typeof parseLocal>;
    semantic?: SemanticCacheStats;
    timings: Record<string, number>;
};
export declare function compileLocalDocument(source: string, options?: LocalCompileOptions): LocalCompileResult;
