import { type ParsedLocal } from '../parsing/parser-core.js';
import { type LocalOptionCheck } from '../configuration/options-core.js';
import type { LocalCompilerCoreServices } from './compiler-services.js';
import type { LocalCompileOptions, LocalCompileResult } from '../contracts/types.js';
/**
 * The single reference compiler pass. Options must already be validated; the
 * validated `optionCheck` is the option snapshot this pass reads, so later
 * mutation of the caller's options object cannot change compilation semantics.
 *
 * `services` carries optional execution goods (session parser, semantic
 * products, row plans, KaTeX display inspector). Omitting them keeps the same
 * semantic flow, only without cross-revision reuse and optional checks.
 */
export declare function compileLocalCore(source: string, options: LocalCompileOptions | undefined, optionCheck: Extract<LocalOptionCheck, {
    ok: true;
}>, services?: LocalCompilerCoreServices, capture?: (tree: ParsedLocal) => void, mark?: (name: string) => void): LocalCompileResult;
