import { type NormalizedComponent } from './component-kernel.js';
import type { LocalDiagnosticDetails } from '../configuration/diagnostics.js';
import type { LocalNode, LocalValue } from '../contracts/types.js';
import type { LocalComponentDefinition } from '../../sdk/types.js';
export interface AttrState {
    raw: string;
    value?: LocalValue;
    dynamic: boolean;
    expression?: string;
    offset: number;
    expressionOffset?: number;
}
export type AttrMap = Record<string, AttrState>;
export interface Entry {
    node: LocalNode;
    name: string;
    kernel: NormalizedComponent;
    definition?: LocalComponentDefinition;
    legacy: boolean;
    parent: Entry | null;
}
export interface ChecklistInfo {
    ids: string[];
    checked: string[];
}
export type ReportDiagnostic = (code: string, message: string | LocalDiagnosticDetails, start: number, end?: number, details?: LocalDiagnosticDetails) => void;
/**
 * Minimal state the structure pass reads and writes. `CompileState` extends
 * this view so the compiler and the pass share one state shape.
 */
export interface StructureState {
    /** Unified registry used for every component node in this compile. */
    readonly schemaByName: ReadonlyMap<string, NormalizedComponent>;
    readonly report: ReportDiagnostic;
    readonly attrs: Map<string, AttrMap>;
    readonly options: Map<string, string[]>;
    readonly tabs: Map<string, string[]>;
    readonly steps: Map<string, string[]>;
    readonly selections: Map<string, string[]>;
    readonly diagramNodes: Map<string, string[]>;
    readonly checklists: Map<string, ChecklistInfo>;
    readonly tables: Map<string, LocalNode>;
}
export declare function projectionMap(state: StructureState, kind: 'options' | 'tabs' | 'steps' | 'diagram-nodes'): Map<string, string[]>;
export declare function validateChildren(entry: Entry, state: StructureState): void;
export declare function validateChecklist(entry: Entry, state: StructureState, itemLimit?: number): ChecklistInfo;
