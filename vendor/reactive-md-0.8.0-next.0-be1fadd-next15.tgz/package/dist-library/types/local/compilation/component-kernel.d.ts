/**
 * Shared component kernel for the local compiler and runtime.
 *
 * Phase two moves every component-specific compile/state rule out of tag-name
 * branches and into bounded, serializable manifest data. This module owns that
 * vocabulary and the generic evaluators; `compiler.ts` and `runtime.ts`
 * dispatch on rule kinds and attribute names only. Language declarations
 * (`theme`, `computed`, `const`, `external`) stay kernel grammar and are the
 * only remaining name checks in the compiler.
 *
 * The types here are the agreement with the registry module. `LocalComponentSchema`
 * may expose the same fields directly, or through the derived compatibility
 * views handled by the accessors below.
 */
import type { LocalNode, LocalValue, LocalValueKind, SourceRange } from '../contracts/types.js';
export type KernelComponentForm = 'leaf' | 'inline' | 'container';
export type KernelLabel = 'none' | 'required' | 'optional';
export type KernelInitialRule = 'empty' | 'false' | 'nearest-zero' | 'min' | 'max-step' | 'first-option' | 'first-tab' | 'first-step' | 'first-node' | 'checked' | 'duration' | 'empty-array' | 'none';
export type KernelChildRule = 'none' | 'any' | 'inline' | 'content' | 'table' | 'plot' | 'diagram' | 'quiz' | 'options' | 'tabs' | 'steps' | 'components';
export interface KernelPropSchema {
    kind: 'string' | 'number' | 'boolean' | 'enum';
    required?: boolean;
    static?: boolean;
    dynamic?: boolean;
    values?: readonly string[];
    enum?: readonly string[];
    default?: LocalValue;
    integer?: boolean;
    positive?: boolean;
    min?: number;
    max?: number;
    color?: boolean;
    pattern?: string;
    /** Coerce a scalar interpolation to display text instead of requiring a string. */
    coerce?: 'text';
    /** Allow an explicit null default/prop value. */
    nullable?: boolean;
}
export type KernelBindingConstraint = {
    readonly literal: number;
} | {
    readonly prop: string;
};
export interface KernelBindingSchema {
    kind: LocalValueKind;
    /** Family semantics stay kernel-owned; components do not add new families. */
    family: string;
    /** Attribute that names the public binding (default "bind"). */
    bind: string;
    /** Attribute that supplies an explicit initial value (default "initial"). */
    initial: string;
    initialRule: KernelInitialRule;
    options?: readonly string[];
    constraints?: {
        min?: KernelBindingConstraint;
        max?: KernelBindingConstraint;
        step?: KernelBindingConstraint;
    };
    required?: boolean;
    exclusive?: boolean;
    maxItems?: KernelBindingConstraint;
    /** Register the binding only when every listed attribute is present. */
    requiresAttributes?: readonly string[];
    /** Attributes whose literal/expression must match between shared owners. */
    compare?: readonly string[];
    /** False excludes the binding from state retention (timers, checklists). */
    retain?: boolean;
}
export interface KernelStructure {
    rule: KernelChildRule;
    label?: KernelLabel;
    parents?: readonly string[];
    child?: string;
    children?: readonly string[];
    min?: number;
    max?: number;
    inlineOnly?: boolean;
    noComponents?: boolean;
    valueAttribute?: string;
    generatedPrefix?: string;
    forbidSeparator?: string;
    maxItems?: number;
    items?: readonly string[];
    minItems?: number;
    maxItemsCount?: number;
    valuePrefix?: string;
    markdown?: 'inline' | 'block' | 'any';
    allowComponents?: boolean;
    single?: 'markdown-table' | 'formula-block';
    content?: 'markdown' | 'task-list';
}
export type KernelRule = {
    kind: 'numeric-range';
    min?: string;
    max?: string;
    step?: string;
    order?: 'nondecreasing' | 'increasing';
    integer?: string;
    positiveInteger?: string;
} | {
    kind: 'text-length';
    min?: string;
    max?: string;
} | {
    kind: 'date-bounds';
    min?: string;
    max?: string;
    required?: string;
} | {
    kind: 'nonempty';
    attribute: string;
} | {
    kind: 'progress-bounds';
    value: string;
    max: string;
    defaultMax: number;
} | {
    kind: 'timer-duration';
    attribute: string;
    default: number;
} | {
    kind: 'option-count';
    max?: string;
} | {
    kind: 'selection-requires';
    key: string;
    attributes: readonly string[];
} | {
    kind: 'inline-body';
    strict?: boolean;
} | {
    kind: 'no-components';
} | {
    kind: 'single-table';
    fallbackSingle?: boolean;
} | {
    kind: 'math-body';
} | {
    kind: 'options-body';
    child: string;
    valueAttribute: string;
    unique: boolean;
    max?: number;
    forbidSeparator?: string;
} | {
    kind: 'value-sequence';
    child: string;
    valueAttribute: string;
    min: number;
    generatedPrefix: string;
    unique: boolean;
    duplicateCode?: string;
} | {
    kind: 'only-children';
    children: readonly string[];
    min: number;
    max?: number;
    maxCode?: string;
    onlyCode?: string;
} | {
    kind: 'diagram-body';
    node: string;
    edge: string;
    id: string;
    from: string;
    to: string;
    label?: string;
} | {
    kind: 'quiz-body';
    type: string;
    answer: string;
    tolerance: string;
    child: string;
    valueAttribute: string;
    max?: number;
} | {
    kind: 'checklist-body';
    itemLimit: number;
} | {
    kind: 'dynamic-constraints';
    attributes: readonly string[];
} | {
    kind: 'require-full-interpolation';
    attributes: readonly string[];
} | {
    kind: 'scoped-expressions';
    attributes: readonly string[];
    scope: 'row' | 'validation';
} | {
    kind: 'row-values';
    rows: string;
    key: string;
    child: string;
    childValue: string;
} | {
    kind: 'validation-rule';
    when: string;
    fields: string;
    message: string;
    placement: 'container' | 'prose';
    max: number;
} | {
    kind: 'anchor';
    id: string;
} | {
    kind: 'navigation';
    target: string;
} | {
    kind: 'data-table';
    rows: string;
    key: string;
    child: string;
    childValue: string;
    label: string;
    maxRows: string;
    defaultMaxRows: number;
    documentRows: number;
    documentCells: number;
    maxColumns: number;
} | {
    kind: 'plot-math';
    min: string;
    max: string;
    samples: string;
    curves: number;
    points: number;
} | {
    kind: 'chart-table';
    chartKind: string;
    x: string;
    y: string;
} | {
    kind: 'timeline-table';
    headerSets: readonly (readonly string[])[];
} | {
    kind: 'table-selection';
    key: string;
    bindings: readonly string[];
} | {
    kind: 'retain';
    value: boolean;
} | {
    kind: 'self-binding-read';
    mode: 'always' | 'attribute';
    attribute?: string;
} | {
    kind: 'inline-math-reads';
} | {
    kind: 'value-date';
    min?: string;
    max?: string;
    required?: string;
} | {
    kind: 'value-length';
    min?: string;
    max?: string;
    email?: string;
    emailType?: string;
} | {
    kind: 'value-email';
    type?: string;
    value?: string;
} | {
    kind: 'value-required';
    required: string;
};
export interface KernelSlotRelation {
    readonly lower: string;
    readonly upper: string;
}
/** Legacy `LocalComponentSchema.slots` entry shape, kept for compatibility. */
export interface KernelLegacySlot {
    readonly name: string;
    readonly bind: string;
    readonly initial: string;
    readonly kind: LocalValueKind;
    readonly family: string;
    readonly exclusive?: boolean;
    readonly initialRule?: string;
}
/**
 * Structural view of a component schema the kernel needs. `LocalComponentSchema`
 * satisfies it directly once the registry populates `structure`, `rules`,
 * `bindings` and `slotRelations`; legacy phase-one schemas satisfy it through
 * the derived accessors below.
 */
export interface KernelComponentSchema {
    name: string;
    form: KernelComponentForm;
    props: Readonly<Record<string, KernelPropSchema>>;
    /** Compatibility view: the scalar `value` binding. */
    binding?: KernelBindingSchema;
    /** Record of scalar and named-slot bindings. */
    bindings?: Readonly<Record<string, KernelBindingSchema>>;
    /** Compatibility view of named slots. */
    slots?: readonly KernelLegacySlot[];
    structure?: KernelStructure;
    rules?: readonly KernelRule[];
    slotRelations?: readonly KernelSlotRelation[];
    /** Legacy compatibility projections. */
    childRule?: string;
    label?: KernelLabel;
    parent?: readonly string[];
    initialRule?: string;
    /** Diagnostic profile for phase-one host/config input adapters. */
    legacyHost?: boolean;
}
/**
 * The single component model the compiler and runtime consume.
 *
 * Every field is explicit: bindings are normalized (`family`, `bind`,
 * `initial`, `initialRule`), structure and rules are always present, and
 * attributes owned by bindings are synthesized. Inputs are converted once at
 * the configuration entry, so later stages never have to check whether a new
 * field exists before falling back to a legacy one.
 */
export interface NormalizedComponent {
    readonly name: string;
    readonly form: KernelComponentForm;
    readonly props: Readonly<Record<string, KernelPropSchema>>;
    readonly bindings: Readonly<Record<string, KernelBindingSchema>>;
    readonly structure: KernelStructure;
    readonly rules: readonly KernelRule[];
    readonly slotRelations: readonly KernelSlotRelation[];
    readonly legacyHost: boolean;
}
/** The scalar `value` binding of a normalized component. */
export declare function kernelValueBinding(schema: NormalizedComponent): KernelBindingSchema | undefined;
/** Named slot bindings in declaration order, excluding `value`. */
export declare function kernelSlotBindings(schema: NormalizedComponent): readonly (KernelBindingSchema & {
    slot: string;
})[];
/** Declared order relations between slots (e.g. range start <= end). */
export declare function kernelSlotRelations(schema: NormalizedComponent): readonly KernelSlotRelation[];
/** Structure of a normalized component. */
export declare function kernelStructure(schema: NormalizedComponent): KernelStructure;
export declare function kernelRules(schema: KernelComponentSchema): readonly KernelRule[];
export declare function kernelRule<K extends KernelRule['kind']>(schema: KernelComponentSchema, kind: K): Extract<KernelRule, {
    kind: K;
}> | undefined;
export declare function kernelRulesOf<K extends KernelRule['kind']>(schema: KernelComponentSchema, kind: K): Extract<KernelRule, {
    kind: K;
}>[];
/** Phase-one manifest input adapters keep their diagnostic wording. */
export declare function kernelUsesLegacyDiagnostics(schema: KernelComponentSchema): boolean;
/** Definition-level fields the registry adds; all optional for compatibility. */
export interface KernelDefinitionFields {
    readonly structure?: KernelStructure;
    readonly rules?: readonly KernelRule[];
    readonly bindings?: Readonly<Record<string, KernelBindingSchema>>;
    readonly slotRelations?: readonly KernelSlotRelation[];
    readonly legacyHost?: boolean;
}
/**
 * Merge the compatibility schema with definition-level phase-two fields and
 * synthesize the attributes every declared binding owns implicitly. This keeps
 * the compiler's attribute table independent of how the registry represents
 * built-in versus external manifests.
 */
export declare function kernelSchemaFor(schema: KernelComponentSchema, definition?: KernelDefinitionFields): KernelComponentSchema;
/**
 * Normalize one component at the configuration entry.
 *
 * This is the only place that reads legacy compatibility fields (`binding`,
 * `slots`, `childRule`, `label`, `parent`, `initialRule`) and the only place
 * that fills defaults for `structure`, `rules` and `bindings`. Compilers and
 * runtimes receive the normalized model and read fields directly.
 */
export declare function normalizeComponent(schema: KernelComponentSchema, definition?: KernelDefinitionFields): NormalizedComponent;
export interface KernelAttrState {
    raw: string;
    value?: LocalValue;
    dynamic: boolean;
    expression?: string;
    offset: number;
    expressionOffset?: number;
}
export type KernelAttrMap = Record<string, KernelAttrState>;
export interface KernelDiagnosticIssue {
    code: string;
    message: string;
    start: number;
    end?: number;
    key: string;
    params?: Readonly<Record<string, string | number | boolean | null>>;
}
/**
 * Evaluate the declarative attribute-relation rules of one component.
 * Diagnostic codes and offsets mirror the phase-one checks exactly; the rule
 * kind, not the tag name, decides which relation applies.
 */
export declare function kernelAttributeIssues(schema: KernelComponentSchema, attrs: KernelAttrMap, nodeRange: SourceRange): KernelDiagnosticIssue[];
/** A bounded YYYY-MM-DD check independent of the compiler's date helpers. */
export declare function isKernelDate(value: string): boolean;
export interface KernelNumericConstraints {
    min?: number;
    max?: number;
    step: number;
    dynamicMin?: string;
    dynamicMax?: string;
}
/**
 * Effective numeric constraints of a binding. Literal constraints and prop
 * references resolve from the node's own attributes/defaults; full
 * interpolations stay dynamic and are recorded separately.
 */
export declare function kernelNumericConstraints(schema: KernelComponentSchema, binding: KernelBindingSchema, attrs: KernelAttrMap): KernelNumericConstraints;
/** Resolve a `maxItems` constraint to a literal cap. */
export declare function kernelMaxItems(schema: KernelComponentSchema, binding: KernelBindingSchema, attrs: KernelAttrMap): number | undefined;
/** Bounds are compatible only when both sides are the same literal or expression. */
export declare function kernelSameNumericBound(a: KernelNumericConstraints, b: KernelNumericConstraints, bound: 'min' | 'max'): boolean;
export declare function kernelDescribeConstraints(constraints: KernelNumericConstraints): string;
export declare function kernelOnStep(value: number, base: number, step: number): boolean;
export declare function kernelNearestZero(min: number | undefined, max: number | undefined, step: number): number | null;
/** Derive the default initial value for any binding without tag names. */
export declare function kernelDefaultInitial(rule: KernelInitialRule, constraints: KernelNumericConstraints | undefined, options: readonly string[]): {
    value: LocalValue;
} | {
    error: 'no-step' | 'cannot-derive';
};
export type KernelProjectionKind = 'options' | 'tabs' | 'steps' | 'selection' | 'diagram-nodes' | 'checklist';
/** Binding family -> projection kind. Family semantics are kernel-owned. */
export declare function kernelProjectionForFamily(family: string): KernelProjectionKind | undefined;
export type KernelValueRule = {
    kind: 'date';
    min?: string;
    max?: string;
    required?: string;
} | {
    kind: 'length';
    min?: string;
    max?: string;
    email?: string;
    emailType?: string;
} | {
    kind: 'required';
    required: string;
} | {
    kind: 'email';
    type: string;
    value: string;
};
export interface KernelDocumentMetadata {
    readonly valueRules: Readonly<Record<string, readonly KernelValueRule[]>>;
    readonly slotRelations: readonly {
        nodeId: string;
        lower: string;
        upper: string;
    }[];
    readonly retentionExclusions: readonly string[];
    /** Authored bind/initial attribute names per public binding. */
    readonly bindingAttributes?: Readonly<Record<string, {
        readonly bind: string;
        readonly initial: string;
    }>>;
    /** Dependency-display capabilities per component node. */
    readonly dependencyRules?: Readonly<Record<string, {
        readonly selfBinding?: {
            readonly mode: 'always' | 'attribute';
            readonly attribute?: string;
        };
        readonly inlineMathReads?: boolean;
    }>>;
}
/** Lower a component's runtime value rules; compile-time rules are ignored. */
export declare function kernelValueRules(schema: KernelComponentSchema): readonly KernelValueRule[];
/** The serialized kernel metadata a compiled document carries. */
export declare function kernelDocumentMetadata(document: unknown): KernelDocumentMetadata | undefined;
export declare function isKernelAnchorId(value: string): boolean;
export interface KernelNavigationTarget {
    name: string;
    target: string;
    offset: number;
}
/**
 * Check navigation targets against known anchors and heading slugs. Rules pick
 * the target attribute; the algorithm is shared by every declaring component.
 */
export declare function kernelNavigationIssues(targets: readonly KernelNavigationTarget[], explicit: ReadonlySet<string>, headings: ReadonlySet<string>): KernelDiagnosticIssue[];
export declare const KERNEL_LIMITS: Readonly<{
    arrayLength: 10000;
    dataTableColumns: 20;
    plotCurves: 16;
    plotPoints: 20000;
}>;
export declare function kernelMeaningfulChildren(nodes: readonly LocalNode[] | undefined): LocalNode[];
export declare function kernelHasComponent(node: LocalNode): boolean;
