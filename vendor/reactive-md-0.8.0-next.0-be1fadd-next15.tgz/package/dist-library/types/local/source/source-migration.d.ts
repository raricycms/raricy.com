import { LOCAL_SYNTAX_VERSION } from '../contracts/version.js';
import type { Diagnostic, SourceRange } from '../contracts/types.js';
export interface LocalSourceVersion {
    declaredVersion: string | null;
    effectiveVersion: string;
    supported: boolean;
    range: SourceRange | null;
    diagnostics: Diagnostic[];
}
export interface LocalUpgradeOptions {
    fromVersion?: string;
    /** Accept the documented UTF-16 -> code-point text-constraint change. */
    allowSemanticChanges?: boolean;
}
export interface LocalUpgradeReport {
    ok: boolean;
    fromVersion: string;
    toVersion: typeof LOCAL_SYNTAX_VERSION;
    needsMigration: boolean;
    diagnostics: Diagnostic[];
}
export interface LocalMigrationResult extends LocalUpgradeReport {
    source: string;
    changed: boolean;
    edits: {
        range: SourceRange;
        text: string;
    }[];
}
/** Inspect source metadata without constructing a runtime or evaluating declarations. */
export declare function inspectLocalSourceVersion(source: string): LocalSourceVersion;
/** Report blockers and declared compatibility exceptions before editing source. */
export declare function checkLocalUpgrade(source: string, options?: LocalUpgradeOptions): LocalUpgradeReport;
/** Pure, idempotent metadata migration. Failure returns the original source. */
export declare function migrateLocalSource(source: string, options?: LocalUpgradeOptions): LocalMigrationResult;
