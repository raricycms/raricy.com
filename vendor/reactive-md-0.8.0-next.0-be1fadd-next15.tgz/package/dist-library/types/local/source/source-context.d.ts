/** One physical source line (LF, CRLF or CR terminated). */
export interface SourceLineFacts {
    readonly from: number;
    readonly to: number;
    readonly text: string;
    readonly blank: boolean;
    readonly indent: number;
    /** Leading blockquote markers (`>`); code content contributes zero. */
    readonly quoteDepth: number;
    /** True for a fence delimiter or any line inside a fenced code block. */
    readonly fenced: boolean;
    /** Blockquote depth plus open list levels at this line. */
    readonly depth: number;
}
/**
 * Shared, read-only line and container facts for one source string. The block
 * planner, the parse budgets and the cache all consume this single scan instead
 * of re-splitting the same text. It is intentionally conservative: fenced and
 * (non-marker) indented code lines never contribute container depth, so `>`
 * and `-` inside code cannot be mistaken for structure.
 */
export interface SourceFacts {
    readonly lines: readonly SourceLineFacts[];
    readonly maxMarkdownDepth: number;
    /** Upper bound from raw line prefixes, including code/HTML. Used to decide
     * when the authoritative container scan is necessary, never to reject. */
    readonly potentialDepth: number;
    /** Half-open ranges of fenced code blocks, including their delimiter lines. */
    readonly fenceSpans: readonly {
        readonly from: number;
        readonly to: number;
    }[];
}
/** Compiler-private source index. Diagnostic line semantics remain LF-based. */
export declare class SourceContext {
    readonly source: string;
    readonly lineStarts: number[];
    private logicalLines;
    private factsValue;
    constructor(source: string);
    get logicalLineCount(): number;
    /** One shared physical-line/container scan, computed on first use. */
    get facts(): SourceFacts;
    lineIndexAt(offset: number): number;
    lineStartAt(offset: number): number;
}
/** Piecewise affine mapping, including an explicit original-region EOF. */
export declare class MappedSource {
    private readonly context;
    private readonly chunks;
    private readonly segments;
    private end;
    private recent;
    length: number;
    constructor(context: SourceContext);
    get segmentCount(): number;
    private append;
    generated(text: string, source: number): void;
    original(from: number, to: number, indent?: number, stripBlockquote?: boolean, stripBom?: boolean): void;
    finish(end: number): void;
    text(): string;
    at(offset: number, fallback: number): number;
}
