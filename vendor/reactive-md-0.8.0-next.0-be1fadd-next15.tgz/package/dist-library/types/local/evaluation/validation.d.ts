import type { Diagnostic, LocalValidation, SourceRange } from '../contracts/types.js';
/**
 * Shared pieces for advisory cross-field rules (`<validation>`).
 *
 * The compiler publishes `LocalDocument.validations` in source order; the
 * runtime evaluates each rule independently against the current revision and
 * reports two stable diagnostic codes. Renderers must not infer extra fields:
 * a failed rule is identified by its tag range (`LocalValidation.range`).
 */
/** A rule whose `when` expression evaluated to `false`. */
export declare const LOCAL_VALIDATION_FAILED_CODE = "local.validation.failed";
/** A rule whose `when` expression could not be evaluated or was not boolean. */
export declare const LOCAL_VALIDATION_EXPRESSION_CODE = "local.validation.expression";
/** Visible substitute when the rule message itself cannot be interpolated. */
export declare const LOCAL_VALIDATION_FALLBACK_MESSAGE = "Validation failed.";
/** Apply the shared diagnostic message budget with the existing ellipsis style. */
export declare function boundLocalDiagnosticMessage(message: string): string;
/** `fields` is a whitespace-separated list of public writable parameter names. */
export declare function parseValidationFields(raw: string): string[];
export declare function localLineStarts(source: string): number[];
/**
 * Runtime rules are metadata, so a hand-built document may carry anything.
 * Only well-formed rules are evaluated; malformed entries are ignored instead
 * of crashing the runtime.
 */
export declare function isLocalValidation(rule: unknown): rule is LocalValidation;
/**
 * Build a runtime diagnostic anchored at the validation tag. `range` comes
 * from the compiled metadata, so renderers can match the diagnostic back to
 * the tag node without any extra field.
 */
export declare function validationDiagnostic(source: string, lineStarts: readonly number[], range: SourceRange, code: string, message: string): Diagnostic;
