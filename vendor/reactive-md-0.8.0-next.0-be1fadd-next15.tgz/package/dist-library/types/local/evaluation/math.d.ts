import type { LocalValue, SourceRange } from '../contracts/types.js';
/**
 * Computable LaTeX for local plots.
 *
 * The parser builds an explicit AST; evaluation never uses eval/Function and
 * only reads the independent variable x plus numeric bindings from the
 * document. Unsupported structures (integrals, matrices, macros, ...) are
 * rejected at compile time with an offset into the LaTeX source.
 */
export declare class LatexError extends Error {
    readonly code: string;
    readonly offset: number;
    constructor(code: string, message: string, offset?: number);
}
export interface LatexExpression {
    readonly source: string;
    dependencies: string[];
    evaluate(x: number, env: Record<string, LocalValue>, budget?: LatexEvaluationBudget): number;
}
/** Shared step budget used by samplePlot so the whole curve has one bound. */
export interface LatexEvaluationBudget {
    steps: number;
    limit: number;
}
export interface PlotPoint {
    x: number;
    y: number | null;
    /** Parameter value for parametric curves; absent for explicit and implicit curves. */
    t?: number;
}
export interface PlotSample {
    points: PlotPoint[];
    endpoint: number | null;
}
/** A point on an implicit contour; both coordinates are defined. */
export interface PlotSegmentPoint {
    x: number;
    y: number;
}
/** One formula block inside a plot, ready for sampling. */
export type PlotFormulaKind = 'explicit' | 'parametric' | 'implicit';
export interface CompiledPlotFormula {
    kind: PlotFormulaKind;
    source: string;
    /** Explicit y(x), parametric x(t), or implicit F(x, y). */
    expression: LatexExpression;
    /** Parametric y(t); null for the other kinds. */
    yExpression: LatexExpression | null;
    /** Parameters only; independent variables x and y are removed. */
    dependencies: string[];
}
/** Internal authoring support: only AST variable nodes represent plot reads. */
export declare function localLatexReferences(source: string): {
    name: string;
    range: SourceRange;
}[];
export declare function compileLatex(source: string): LatexExpression;
/** Cheap classification used before compiling and sampling a plot block. */
export declare function plotFormulaKind(source: string): PlotFormulaKind | null;
/**
 * Classifies one plot formula block.
 *
 * - `y = f(x)` is an explicit curve.
 * - `\begin{cases} x = f(t) \\ y = g(t) \end{cases}` is a parametric curve.
 * - Any other equation in x and y is implicit and traced as `left - right = 0`.
 */
export declare function compilePlotFormula(source: string): CompiledPlotFormula;
/** Upper bound for the per-axis grid used to trace an implicit equation. */
export declare const MAX_IMPLICIT_GRID = 100;
/** Minimum grid resolution; smaller `samples` values are raised to this. */
export declare const MIN_IMPLICIT_GRID = 32;
/** Grid cells per axis for an implicit curve at a given plot sample count. */
export declare function implicitGridSize(samples: number): number;
