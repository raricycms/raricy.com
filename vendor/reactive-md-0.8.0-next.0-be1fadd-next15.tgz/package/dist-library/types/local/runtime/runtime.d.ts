import type { Diagnostic } from '../contracts/types.js';
import type { LocalStateRetentionDrop } from './retention.js';
import { type LocalDocument, type LocalRuntime, type LocalRuntimeOptions } from '../contracts/types.js';
export interface LocalRuntimeUpdateOptions {
    /**
     * Announce the adopted revision to subscribers (default true). The document
     * view stages updates with `false` and flushes after React commits, so no
     * subscriber is notified during render.
     */
    readonly notify?: boolean;
}
export interface LocalRuntimeDocumentUpdate {
    /** False when the next document could not be adopted; the runtime is unchanged. */
    readonly ok: boolean;
    /** True when the document identity was adopted (state may or may not differ). */
    readonly changed: boolean;
    /** Revision after the call; unchanged when `ok` is false. */
    readonly revision: number;
    readonly retained: readonly string[];
    readonly dropped: readonly LocalStateRetentionDrop[];
    readonly diagnostics: readonly Diagnostic[];
}
/**
 * Adopt a freshly compiled document without discarding the runtime object.
 * Values migrate with the same rules as `planLocalStateRetention` /
 * `applyLocalStateRetention`: an unchanged public binding keeps its value, a
 * value the new constraints reject falls back to the new author initial, and
 * type, initial-definition, anonymous, timer, checklist, renamed or removed
 * bindings reset conservatively. Multi-slot ranges stay globally ordered.
 */
export declare function updateLocalRuntime(runtime: LocalRuntime, next: LocalDocument, options?: LocalRuntimeUpdateOptions): LocalRuntimeDocumentUpdate;
/** Flush a staged document update to subscribers after React commits. */
export declare function notifyLocalRuntime(runtime: LocalRuntime): void;
export declare function createLocalRuntime(document: LocalDocument, options?: LocalRuntimeOptions): LocalRuntime;
