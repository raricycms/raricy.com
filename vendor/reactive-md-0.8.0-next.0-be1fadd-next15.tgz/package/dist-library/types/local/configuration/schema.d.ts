import type { LocalComponentForm, LocalComponentSchema } from './schema-core.js';
import type { LocalValue } from '../contracts/types.js';
export type { LocalComponentForm, LocalChildRule, LocalPropKind, LocalPropSchema, LocalBindingFamily, LocalBindingSchema, LocalBindingSlotSchema, LocalInitialRule, LocalComponentSchema, } from './schema-core.js';
export { LOCAL_KERNEL_DECLARATIONS, closestName } from './schema-core.js';
export declare const LOCAL_COMPONENTS: Readonly<Record<string, LocalComponentSchema>>;
export declare const LOCAL_COMPONENT_NAMES: readonly string[];
/** Component names with the given tag shape, in declaration order. */
export declare function localComponentNames(form: LocalComponentForm): readonly string[];
export declare function getLocalComponent(name: string): LocalComponentSchema | undefined;
export declare function getPropDefault(component: LocalComponentSchema, prop: string): LocalValue | undefined;
export declare function suggestComponent(name: string): string | undefined;
export declare function suggestAttribute(component: LocalComponentSchema, name: string): string | undefined;
