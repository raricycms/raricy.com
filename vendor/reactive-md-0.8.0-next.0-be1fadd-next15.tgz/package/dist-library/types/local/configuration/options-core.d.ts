import { type NormalizedComponent } from '../compilation/component-kernel.js';
import { type LocalParserCapabilities } from '../parsing/parser-capabilities.js';
import type { LocalComponentDefinition, LocalConfig } from '../../sdk/types.js';
import type { LocalCompileOptions, LocalHostComponentSchema, LocalHtmlPolicy } from '../contracts/types.js';
/** Capability flags that select the temporary whole-document HTML branch. */
export declare const LOCAL_HTML_FLAGS: readonly ['enableCss', 'enableJavaScript', 'enableExtendedHtml'];
export type LocalHtmlFlag = (typeof LOCAL_HTML_FLAGS)[number];
/**
 * Identity of the tolerance strategy. It participates in the canonical option
 * key only when `strict` is false, so changing recovery ranges invalidates
 * caches without perturbing strict identities.
 */
export declare const LOCAL_RECOVERY_STRATEGY_VERSION = "2";
export type LocalOptionCheck = {
    ok: true;
    /** Validated syntax-node budget for this compilation. */
    maxSyntaxNodes: number;
    /** Validated deterministic parser work budget, in abstract units. */
    maxParseWork: number;
    /** Validated nested Markdown container depth budget. */
    maxMarkdownDepth: number;
    /** Effective HTML policy; every flag is false by default. */
    html: LocalHtmlPolicy;
    /** True when at least one capability flag is enabled. */
    htmlActive: boolean;
    /** Render ordinary Markdown soft line breaks as `break` nodes. */
    markdownBreaks: boolean;
    /**
     * Effective structural mode. Defaults to `true`; `false` enables the
     * parser's isolated recovery strategy.
     */
    strict: boolean;
    /** Validated host component schemas; empty when the option is absent. */
    hostComponents: readonly LocalHostComponentSchema[];
    /** Host tag name lookup; names are already lowercase kebab-case. */
    hostByName: ReadonlyMap<string, LocalHostComponentSchema>;
    /** Validated instance configuration, when one was supplied. */
    config?: LocalConfig;
    /**
     * SDK manifests by tag name, retained for typed prop defaults, ranges
     * and binding constraints that the host schema cannot express.
     */
    sdkByName: ReadonlyMap<string, LocalComponentDefinition>;
    /** Full validated snapshot: assembled defaults followed by external manifests. */
    registry: readonly LocalComponentDefinition[];
    /** Unified definition lookup (defaults + external manifests). */
    componentByName: ReadonlyMap<string, LocalComponentDefinition>;
    /** Unified schema lookup (defaults + external + kernel grammar declarations). */
    schemaByName: ReadonlyMap<string, NormalizedComponent>;
    /** Names contributed by the assembled defaults. */
    defaultComponentNames: ReadonlySet<string>;
    /** Names contributed by external manifests. */
    externalComponentNames: ReadonlySet<string>;
    /** Legacy `hostComponents` input adapter names. */
    legacyHostNames: ReadonlySet<string>;
    /**
     * Semantic component-configuration key. Matches
     * `localComponentConfigKey` for the same presets and external manifests;
     * themes never contribute.
     */
    componentConfigKey: string;
    /** Preset actually honored by this compilation, when one is assembled. */
    preset?: {
        readonly id: string;
        readonly version: string;
    };
    /** Optional parser abilities installed by this assembly. */
    capabilities: LocalParserCapabilities;
} | {
    ok: false;
    message: string;
    key: string;
    detail?: string;
};
/**
 * Assembly services injected by the caller.
 *
 * The validation rules are shared; only the assembled built-in defaults, the
 * preset identity, the configuration reader (full or semantic) and the config
 * key source differ between the compatibility entry and single compilation.
 */
export interface LocalOptionSources {
    /** Built-in definitions for this assembly; empty for the minimal compiler. */
    readonly defaults: readonly LocalComponentDefinition[];
    /** Preset honored by this assembly, if any. */
    readonly preset?: {
        readonly id: string;
        readonly version: string;
    };
    /** Key for a configuration-free assembly. */
    readonly defaultConfigKey: string;
    /** Read and validate instance configuration. */
    readonly readConfig: (value: unknown, defaults: readonly LocalComponentDefinition[]) => LocalConfig;
    /** Semantic key of a validated configuration. */
    readonly configKey: (config: LocalConfig) => string;
    /** Optional parser abilities; omitted means core Markdown only. */
    readonly capabilities?: LocalParserCapabilities;
}
/**
 * Shared option validation used by both the compatibility entry and single
 * compilation. Only the assembled defaults, preset identity and configuration
 * reader differ between callers.
 */
export declare function readOptionCheck(options: LocalCompileOptions | undefined, sources: LocalOptionSources): LocalOptionCheck;
/**
 * Read semantic compile options for one compilation.
 *
 * Without `defaults` the returned registry is empty: the minimal compiler
 * installs no components and only kernel grammar declarations. A standard
 * factory passes the assembled default manifests explicitly.
 */
export declare function readCompilerOptions(options?: LocalCompileOptions, defaults?: readonly LocalComponentDefinition[], capabilities?: LocalParserCapabilities): LocalOptionCheck;
/**
 * Semantic component-configuration key of a validated check. Equal to the
 * legacy `localComponentConfigKey` for the same presets and external manifests;
 * themes and display-only configuration never change it.
 */
export declare function compilerComponentConfigKey(check: Extract<LocalOptionCheck, {
    ok: true;
}>): string;
