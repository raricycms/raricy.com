import type { KernelBindingSchema, KernelChildRule, KernelComponentSchema, KernelInitialRule, KernelLegacySlot, KernelPropSchema } from '../compilation/component-kernel.js';
/**
 * Theme-free component schema vocabulary.
 *
 * These declarations are the part of `schema.ts` that depends only on the
 * language kernel. The default preset projection, suggestions over installed
 * names and every manifest import stay in `schema.ts`; the single-compilation
 * entry point may import this module without loading the preset or the theme
 * registry.
 */
export type LocalComponentForm = 'leaf' | 'inline' | 'container';
export type LocalChildRule = KernelChildRule;
export type LocalPropKind = 'string' | 'number' | 'boolean' | 'enum';
export type LocalPropSchema = KernelPropSchema;
export type LocalBindingFamily = 'text' | 'number' | 'boolean' | 'choice' | 'date' | 'timer' | 'checklist' | 'tabs' | 'diagram' | 'multi-select' | 'selection' | 'steps' | 'collection';
export type LocalBindingSchema = KernelBindingSchema;
/**
 * One independently bound value of a multi-slot component. Each slot has its
 * own public binding name (or an internal `@node:slot` key) and is exclusive in
 * the first revision of the slot API.
 */
export type LocalBindingSlotSchema = KernelLegacySlot;
/**
 * `default` is the schema default for an ordinary property. `initialRule`
 * describes how a component produces the value of a binding when the author
 * omits `initial`.
 */
export type LocalInitialRule = KernelInitialRule;
export type LocalComponentSchema = KernelComponentSchema;
export declare const LOCAL_KERNEL_DECLARATIONS: readonly LocalComponentSchema[];
/** Closest candidate within an edit distance of two, or `undefined`. */
export declare function closestName(name: string, candidates: readonly string[]): string | undefined;
