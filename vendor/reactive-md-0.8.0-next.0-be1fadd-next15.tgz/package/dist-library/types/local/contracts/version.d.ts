/** The local syntax revision accepted and rendered by this build. */
export declare const LOCAL_SYNTAX_VERSION: 'local-draft-3';
