import type { SourceFacts } from '../source/source-context.js';
import type { LocalRecovery, SourceRange } from '../contracts/types.js';
/**
 * One tag-shaped token found by the tolerant structural planner. `complete`
 * is false when the closing `>` was never found (or an attribute quote stayed
 * open); such a tag always uses the conservative boundary rule.
 */
export interface RmdTagScan {
    readonly name: string;
    readonly closing: boolean;
    readonly self: boolean;
    readonly end: number;
    readonly complete: boolean;
}
/** Lexical services owned by the parser; the planner never re-parses source. */
export interface RmdRecoveryHooks {
    readonly facts: SourceFacts;
    /** Root footnote definitions are literal bodies, not structural RMD. */
    readonly definitions: readonly SourceRange[];
    isKnown(name: string): boolean;
    /** False for registered leaf components, which never require a closing tag. */
    isPaired(name: string): boolean;
    isHtmlName(lower: string): boolean;
    isVoidHtml(lower: string): boolean;
    /** End offset of a raw-text HTML body, or null when it never closes. */
    rawHtmlEnd(lower: string, bodyStart: number, insideContainer: boolean): number | null;
    /** Fenced/inline code or escape ending at `offset`, if any. */
    protectedEnd(offset: number, insideContainer: boolean): number | null;
    /** Document-wide Markdown code range ending at `offset`, if any. */
    codeEndAt(offset: number): number | null;
    readTag(offset: number): RmdTagScan | null;
    beginsLine(offset: number): boolean;
    charge(units: number, start: number, end: number): void;
}
export interface RmdRecoveryPlan {
    readonly recoveries: readonly LocalRecovery[];
    /** Non-overlapping ranges, sorted by start; each is consumed literally. */
    readonly ranges: readonly SourceRange[];
    /** Exact range-start lookup used by the region scanner. */
    readonly byStart: ReadonlyMap<number, number>;
}
/**
 * Plan the structure-only recovery for one document. The scan is single-pass
 * and uses the parser's existing lexical guards, so code, comments,
 * interpolations, formulas and raw HTML never become sync points. It returns
 * literal ranges plus stable recovery records; nothing here mutates source.
 */
export declare function planRmdRecovery(source: string, hooks: RmdRecoveryHooks): RmdRecoveryPlan;
