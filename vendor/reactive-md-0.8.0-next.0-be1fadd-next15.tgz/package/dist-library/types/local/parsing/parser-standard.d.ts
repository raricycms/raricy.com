import type { LocalParserCapabilities } from './parser-capabilities.js';
/**
 * Parser abilities of the full experience: GFM syntax, native HTML support,
 * isolated HTML repair and Lezer-assisted block planning. The minimal compiler
 * never imports this module.
 */
export declare const STANDARD_PARSER_CAPABILITIES: LocalParserCapabilities;
