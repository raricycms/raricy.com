import type { LocalCompileOptions } from '../contracts/types.js';
import { type ParsedLocal } from './parser-core.js';
import type { SourceContext } from '../source/source-context.js';
import type { ParseSessionCache } from './parse-budget.js';
import type { InlinePlanLookup } from '../markdown/fast-markdown.js';
export type { ParsedLocal, ParserWork } from './parser-core.js';
/**
 * Compatibility facade for the pure kernel. Host options are read and
 * validated here; the kernel itself never imports options, SDK config, the
 * schema registry or theme implementations.
 *
 * Source validation still precedes option validation: the kernel checks the
 * source first and returns `local.parse`/`local.budget` for it. The
 * placeholder option check below is therefore never inspected.
 */
export declare function parseLocal(source: string, options?: LocalCompileOptions, context?: SourceContext, cache?: ParseSessionCache, rowPlans?: InlinePlanLookup): ParsedLocal;
