import type { Diagnostic } from '../contracts/types.js';
import type { LocalNode, LocalVersionDeclaration, SourceRange, LocalRecovery } from '../contracts/types.js';
import type { LocalOptionCheck } from '../configuration/options-core.js';
import type { FastMarkdownPlan, InlinePlanLookup } from '../markdown/fast-markdown.js';
import { SourceContext } from '../source/source-context.js';
import { type ParseSessionCache } from './parse-budget.js';
export interface ParsedLocal {
    nodes: LocalNode[];
    diagnostics: Diagnostic[];
    /** Internal cumulative creation count, including discarded intermediates. */
    syntaxNodes?: number;
    /** Internal aggregate work over shielding and nested conversion calls. */
    work?: ParserWork;
    versionDeclaration?: LocalVersionDeclaration;
    /** Declared theme name, when the leading declaration is valid. */
    theme?: string;
    /** Source range of the first leading theme declaration, valid or not. */
    themeRange?: SourceRange;
    /**
     * Internal: fast Markdown plans used by this parse. The incremental
     * compiler keeps their per-row inline plans so a later edit of the same
     * block can skip re-scanning unchanged rows.
     */
    plans?: FastMarkdownPlan[];
    /**
     * Structural repairs applied in non-strict mode, in stable source order.
     * Strict parsing omits the field entirely.
     */
    recoveries?: LocalRecovery[];
}
export interface ParserWork {
    markdownCalls: number;
    fastBlocks: number;
    generalBlocks: number;
    fastCharacters: number;
    generalCharacters: number;
    mappingSegments: number;
    sourceLines: number;
    maxComponentDepth: number;
    /** Deterministic parser work charged for this parse. */
    parseWork?: number;
    /** Maximum Markdown container depth observed in the source. */
    maxMarkdownDepth?: number;
    /** Session cache lookups that were served from the session. */
    cacheHits?: number;
    /** Session cache lookups that had to be computed. */
    cacheMisses?: number;
    /** Whole fast plans reused from the session. */
    reusedBlocks?: number;
    /** Table rows/cells whose inline plan was reused. */
    reusedRows?: number;
    /** List items whose inline plan was reused. */
    reusedItems?: number;
    /** General Markdown ASTs reused from the session. */
    reusedAst?: number;
    /** Coarse phase timings; observability only, never part of a result. */
    timings?: {
        shieldMs: number;
        regionMs: number;
        convertMs: number;
        totalMs: number;
    };
}
/** A lexical pass shields code before recognizing local tags, interpolation and math. */
export declare function parseLocalCore(source: string, optionCheck: LocalOptionCheck, context?: SourceContext, cache?: ParseSessionCache, rowPlans?: InlinePlanLookup): ParsedLocal;
