/** True only for a standard CSS named color or #RGB / #RRGGBB. */
export declare function isLocalColor(value: string): boolean;
