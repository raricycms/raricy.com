export declare const MAX_THEME_NAME_LENGTH = 64;
/** Bounded, URL-free theme identifier used by documents and host manifests. */
export declare function isLocalThemeName(value: unknown): value is string;
