import type { LocalCompileResult } from '../contracts/types.js';
/** Plain compiler data only: no executable values, class instances or cycles. */
type Primitive = string | number | boolean | null | undefined;
type Entry = [key: string, reference: number];
type RecordData = [0, Primitive] | [1, length: number, entries: Entry[]] | [2, entries: Entry[]];
export interface FlatCompiledData {
    version: 'flat-v1';
    records: RecordData[];
}
export declare const FLAT_COMPILED_DATA_PROTOCOL = "flat-v1";
/** Keep ordinary documents on the existing result/patch transport. */
export declare function needsFlatCompileResult(result: LocalCompileResult): boolean;
/** Flat record references keep structured clone depth constant, even on older V8. */
export declare function encodeFlatCompiledData(value: unknown): FlatCompiledData;
/** Reject malformed graphs before publishing any decoded result. */
export declare function decodeFlatCompiledData(value: unknown): unknown | null;
export {};
