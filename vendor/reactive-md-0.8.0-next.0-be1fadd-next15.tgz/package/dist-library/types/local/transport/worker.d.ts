import { type LocalCompileSession, type LocalIncrementalStats } from '../session/incremental.js';
import { LOCAL_RESULT_PATCH_PROTOCOL, type LocalResultPatch, type LocalSourceEdit } from './compile-patch.js';
import type { Diagnostic, LocalCompileOptions, LocalCompileResult } from '../contracts/types.js';
import { type AuthorAnalysis } from '../source/authoring.js';
import { FLAT_COMPILED_DATA_PROTOCOL, type FlatCompiledData } from './flat-compiled-data.js';
/** Editors are coalesced for this long before a compile is dispatched. */
export declare const LOCAL_COMPILE_DELAY_MS = 150;
/**
 * Idle delay after a successful result before the worker asks the session to
 * prepare the next revision. A new request cancels the pending preparation.
 */
export declare const LOCAL_COMPILE_PREPARATION_DELAY_MS = 200;
export type LocalCompileProtocol = typeof LOCAL_RESULT_PATCH_PROTOCOL;
export interface LocalCompileRequest {
    /** Opt into depth-independent full results. Absent on legacy clients. */
    flatResults?: typeof FLAT_COMPILED_DATA_PROTOCOL;
    /** Return authoring data from the same compiled document. Off by default. */
    includeAuthorAnalysis?: boolean;
    id: number;
    source: string;
    /**
     * Capability flags, Markdown break handling, strict recovery mode, limits
     * and host component schemas for this compile. `hostComponents` selects the
     * host leaf tags the parser may build; `markdownBreaks` turns soft breaks
     * into `break` nodes; `strict: false` selects the complete tolerant-recovery
     * reference path.
     */
    options?: LocalCompileOptions;
    /**
     * Advertised by a client that understands `patch-v1`. A worker echoes its
     * support on the full response, after which both sides may exchange edits
     * and result patches. Older peers simply omit the field.
     */
    protocol?: LocalCompileProtocol;
    /** Client-assigned revision of this source. Echoed by a `patch-v1` worker. */
    revision?: number;
}
/** An incremental request; only sent once a `patch-v1` worker was confirmed. */
export interface LocalCompilePatchRequest {
    includeAuthorAnalysis?: boolean;
    id: number;
    protocol: LocalCompileProtocol;
    /** Revision of the complete source this edit applies to. */
    baseRevision: number;
    /** Revision of the resulting source. */
    revision: number;
    /** UTF-16 replacement, not a byte or code-point offset. */
    edit: LocalSourceEdit;
    /** Cheap guard that the edit produced the source the scheduler intended. */
    targetLength?: number;
    /** Options signature of the baseline; a mismatch asks for a full compile. */
    optionsKey?: string;
}
export type LocalCompileWorkerRequest = LocalCompileRequest | LocalCompilePatchRequest;
export interface LocalCompileWorkerMetrics {
    analysisMs?: number;
    /** Time spent inside the compile call, mirroring `duration`. */
    compileMs?: number;
    /** Time spent encoding a result patch. */
    patchEncodeMs?: number;
    /** Node records in the result patch. */
    patchNodes?: number;
    /**
     * Set when a complete result was sent instead of a patch because the patch
     * was estimated to be no cheaper. This is a transport choice for the same
     * revision, never an error or a retry; the patch* estimates describe the
     * discarded patch.
     */
    patchFallback?: 'cost';
    /** Estimated serialized characters of the discarded patch payload. */
    patchBytes?: number;
    /** Estimated serialized characters of the complete result payload. */
    fullBytes?: number;
    /** Time of the most recent idle preparation, when one completed. */
    preparationMs?: number;
}
export interface LocalCompileMetrics {
    /** Schedule to dispatch, including the debounce window. */
    queueMs?: number;
    /** Dispatch to receive, including worker compile and transport. */
    roundTripMs?: number;
    /** Result patch decode/apply on the receiving thread. */
    applyMs?: number;
    /** Worker-reported stages; never a DOM input latency measurement. */
    worker?: LocalCompileWorkerMetrics;
}
export interface LocalCompilePatchResponse {
    analysis?: AuthorAnalysis;
    id: number;
    ok: true;
    protocol: LocalCompileProtocol;
    baseRevision: number;
    revision: number;
    patch: LocalResultPatch;
    duration: number;
    incremental?: Readonly<LocalIncrementalStats>;
    metrics?: LocalCompileWorkerMetrics;
}
export type LocalCompileResponse = {
    id: number;
    ok: true;
    result: LocalCompileResult;
    duration: number;
    incremental?: Readonly<LocalIncrementalStats>;
    protocol?: LocalCompileProtocol;
    revision?: number;
    metrics?: LocalCompileWorkerMetrics;
    analysis?: AuthorAnalysis;
} | {
    id: number;
    ok: false;
    message: string;
    /** The request cannot be served incrementally; resend the full source. */
    retryFull?: boolean;
    code?: string;
    /** Worker's current revision, for diagnostics and recovery. */
    revision?: number;
};
/**
 * Everything the worker may post. `LocalCompileResponse` stays the classic
 * complete/failure union so existing scopes and test doubles keep their exact
 * full-result typing; patch frames are layered on top rather than embedded in
 * the full result shape.
 */
export type LocalCompileFlatResponse = Omit<Extract<LocalCompileResponse, {
    ok: true;
}>, 'result'> & {
    flatResult: FlatCompiledData;
};
export type LocalCompileWorkerResponse = LocalCompileResponse | LocalCompilePatchResponse | LocalCompileFlatResponse;
/**
 * The small surface the scheduler needs from a Worker. Events stay untyped so
 * the core declarations compile without the DOM library.
 */
export interface LocalCompileWorker {
    postMessage(message: LocalCompileWorkerRequest): void;
    terminate(): void;
    onmessage: ((event: any) => void) | null;
    onerror: ((event: any) => void) | null;
    onmessageerror: ((event: any) => void) | null;
}
export type LocalCompileMode = 'worker' | 'fallback';
export interface LocalCompileOutcome {
    analysis?: AuthorAnalysis;
    source: string;
    result: LocalCompileResult;
    duration: number;
    mode: LocalCompileMode;
    /** Snapshot of the options this result was compiled with, when supplied. */
    options?: LocalCompileOptions;
    /** Stage timings; absent on peers that do not report metrics. */
    metrics?: LocalCompileMetrics;
    /** Source revision when the worker negotiated `patch-v1`. */
    revision?: number;
}
export interface LocalCompileSchedulerOptions {
    includeAuthorAnalysis?: boolean;
    createWorker(): LocalCompileWorker;
    /**
     * Defaults to compileLocal. Runs on the main thread only when the worker is
     * unavailable or failed. One-argument callbacks remain supported.
     */
    fallbackCompile?(source: string, options?: LocalCompileOptions): LocalCompileResult;
    onResult(outcome: LocalCompileOutcome): void;
    onPendingChange?(pending: boolean): void;
    onModeChange?(mode: LocalCompileMode, detail?: string): void;
    delay?: number;
    /**
     * Opt into the internal read-only result graph. Off by default, where every
     * `onResult` receives an independent deep copy and may mutate it freely.
     */
    shareResults?: boolean;
}
/** Optional native-editor transaction; discarded when its baseline differs. */
export interface LocalCompileEditHint {
    baseSource: string;
    edit: LocalSourceEdit;
}
/**
 * Canonical job/transport signature. Extends the compiler's public key with
 * the newer per-compile budgets once they exist, without modifying options.ts.
 * Strict identity, including the recovery-strategy version for `strict:false`,
 * comes from `localCompileOptionsKey`; both sides key the same snapshot.
 */
export declare function localWorkerOptionsKey(options: LocalCompileOptions | undefined): string;
export declare function compileFailureDiagnostic(error: unknown): Diagnostic;
/**
 * Debounces edits, keeps at most one compile in flight plus the latest source
 * waiting, and drops results that a newer edit has already superseded.
 *
 * Once a worker advertises `patch-v1`, subsequent dispatches send a UTF-16
 * edit against the last accepted revision and receive a result patch. Failed
 * applies are recovered once with a complete request; legacy workers keep
 * receiving complete sources forever.
 */
export declare class LocalCompileScheduler {
    private readonly options;
    private readonly delay;
    private worker;
    private timer;
    private queued;
    private inFlight;
    private nextId;
    private nextRevision;
    private pending;
    private fallbackSession;
    private disposed;
    private baseline;
    private patchState;
    constructor(options: LocalCompileSchedulerOptions);
    /**
     * Queue the newest source and its compile options; the previous timer, if
     * any, is replaced. Options are copied so a later mutation cannot change the
     * permissions of an in-flight compile. An options-only edit still supersedes
     * an older result for the same source.
     */
    schedule(source: string, options?: LocalCompileOptions, hint?: LocalCompileEditHint): void;
    /** Stop the timer and terminate the worker. No callbacks fire afterwards. */
    dispose(): void;
    private drain;
    private compile;
    private compileFallback;
    private receive;
    /**
     * Apply a patch response against the last accepted baseline. Returns null
     * for any mismatch so the caller can resend a complete source once.
     */
    private applyResponsePatch;
    /** Re-dispatch the same job with a complete source, at most once per job. */
    private recoverWithFullResult;
    private handleWorkerFailure;
    /** Permanently switch to the fallback; a crashed worker is never restarted. */
    private degrade;
    private resetProtocol;
    private finishRun;
    private deliver;
    private setPending;
    private clearTimer;
}
export interface LocalCompileWorkerScope {
    onmessage: ((event: any) => void) | null;
    /** Classic full/failure shape; patch frames are delivered to patch-v1 clients. */
    postMessage(message: LocalCompileResponse): void;
}
export interface LocalCompileWorkerControlMessage {
    readonly control: 'dispose' | 'cancel-preparation';
}
export interface LocalCompileWorkerControl {
    dispose(): void;
    cancelPreparation(): void;
    readonly disposed: boolean;
}
export interface LocalCompileWorkerOptions {
    /** Test seam; production uses `createLocalCompileSession`. */
    createSession?(): LocalCompileSession;
    /** Idle delay before session preparation; defaults to `LOCAL_COMPILE_PREPARATION_DELAY_MS`. */
    preparationDelay?: number;
}
/**
 * Install the worker-side compile handler on a DedicatedWorkerGlobalScope-like
 * object. Returns a cleanup handle (ignored by existing callers) and accepts
 * `{control: 'dispose' | 'cancel-preparation'}` messages for transports that
 * prefer lifecycle messages over the handle.
 */
export declare function startLocalCompileWorker(scope?: LocalCompileWorkerScope, options?: LocalCompileWorkerOptions): LocalCompileWorkerControl;
