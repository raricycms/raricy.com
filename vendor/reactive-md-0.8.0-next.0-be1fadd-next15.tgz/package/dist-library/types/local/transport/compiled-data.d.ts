/**
 * Publish compiler-owned data as ordinary records and arrays. Internal maps can
 * keep null prototypes; React Server Component props require ordinary records.
 * Keep undefined fields, shared references and existing frozen metadata intact.
 */
export declare function plainCompiledData<T>(value: T, preserveFrozen?: boolean): T;
