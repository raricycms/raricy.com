import type { LanguageFn } from 'highlight.js';
/** Cattca embeds command blocks in Markdown narrative. */
export declare const cattca: LanguageFn;
/** Highlight Mermaid source as code; rendering diagrams is a separate feature. */
export declare const mermaid: LanguageFn;
/** Vue SFCs combine HTML templates, JavaScript/TypeScript and CSS/SCSS. */
export declare const vue: LanguageFn;
