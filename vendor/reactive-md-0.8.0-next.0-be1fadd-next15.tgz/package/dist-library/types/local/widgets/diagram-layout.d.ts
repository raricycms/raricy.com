export type DiagramDirection = 'right' | 'down';
export interface DiagramLayoutNodeInput {
    id: string;
    width: number;
    height: number;
}
export interface DiagramLayoutEdgeInput {
    id: string;
    from: string;
    to: string;
    label?: string;
    labelWidth?: number;
    labelHeight?: number;
}
export interface DiagramLayoutInput {
    direction: DiagramDirection;
    nodes: DiagramLayoutNodeInput[];
    edges: DiagramLayoutEdgeInput[];
}
export interface DiagramPoint {
    x: number;
    y: number;
}
export interface DiagramEdgeSection {
    startPoint: DiagramPoint;
    endPoint: DiagramPoint;
    bendPoints: DiagramPoint[];
    /** ELK spline points are cubic controls, not polyline vertices. */
    cubic?: boolean;
}
/** Round routed corners without moving ports or leaving the routing corridor. */
export declare function diagramEdgePath(sections: DiagramEdgeSection[], radius?: number): string;
export interface DiagramLabelRect {
    x: number;
    y: number;
    width: number;
    height: number;
}
export interface DiagramEdgeLayout {
    sections: DiagramEdgeSection[];
    label?: DiagramLabelRect;
}
export interface DiagramNodeLayout {
    /** Node centre, matching the SVG translate used for node cards. */
    x: number;
    y: number;
    width: number;
    height: number;
}
export interface DiagramLayoutResult {
    width: number;
    height: number;
    nodes: Map<string, DiagramNodeLayout>;
    edges: Map<string, DiagramEdgeLayout>;
    source: 'elk' | 'fallback';
}
/** Every value that can change geometry; selection, tone and body do not. */
export declare function diagramLayoutKey(input: DiagramLayoutInput): string;
/**
 * Resolves the layered layout. Failures (including an unsupported runtime)
 * degrade to the synchronous fallback instead of breaking the diagram.
 */
export declare function layoutDiagram(input: DiagramLayoutInput): Promise<DiagramLayoutResult>;
/**
 * Deterministic layered layout used before ELK resolves (SSR, static export
 * and first paint). Cycle-closing edges found by a declaration-order DFS are
 * ignored for layering and routed outside the node band.
 */
export declare function createDiagramLayoutFallback(input: DiagramLayoutInput): DiagramLayoutResult;
