import type { ReactNode } from 'react';
import type { LocalNode, LocalRuntime } from '../contracts/types.js';
import type { LocalVisualProps } from '../rendering/render-types.js';
import type { Localize } from '../theme/i18n.js';
/**
 * Legacy visual entry points.
 *
 * The actual table/chart/plot/timeline/diagram implementations now live in
 * `src/components/visuals.tsx` and are resolved through the default React
 * preset. This module keeps the historical fixture surface (`LocalVisual`,
 * `VisualFrame`) and the generic native-HTML-table helper used by the main
 * renderer; it contains no builtin view implementation or tag dispatch.
 */
export { VisualFrame } from '../../components/visuals.js';
/**
 * Shared numeric-column detection for native HTML tables. Markdown-backed
 * visuals get the same classification from the public table projection.
 */
export declare function tableNumericColumns(rows: readonly LocalNode[][], runtime: Pick<LocalRuntime, 'evaluate'>, _t?: Localize): boolean[];
/**
 * Legacy fixture renderer for one visual component. It adapts the historical
 * `{ node, runtime, render, visible, mode }` props into the public component
 * context and resolves the actual implementation from the default preset.
 */
export declare function LocalVisual(props: LocalVisualProps): ReactNode;
