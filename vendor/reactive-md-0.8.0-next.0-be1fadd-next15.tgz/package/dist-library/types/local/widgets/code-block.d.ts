import { type ReactElement, type ReactNode } from 'react';
/**
 * Fenced code blocks with optional syntax highlighting and a copy button.
 *
 * Highlighting is renderer-only and never trusts source as HTML: lowlight
 * produces a hast tree whose text and span nodes are mapped back to React text
 * and span elements. Unknown languages, oversized sources, mismatched text and
 * highlighting failures all fall back to the exact source value.
 */
/** Sources longer than this render as plain text; highlighting cost grows with input. */
export declare const MAX_HIGHLIGHT_CHARS = 20000;
export interface CodeHighlight {
    /** Highlighted children, or `null` when the source should render verbatim. */
    nodes: ReactNode[] | null;
    highlighted: boolean;
    /** Resolved grammar, including the detected language for unlabeled blocks. */
    language?: string;
}
/** Highlight explicit languages, or detect unlabeled code with bounded grammars. */
export declare function highlightCode(value: string, language?: string): CodeHighlight;
export interface CodeBlockViewProps {
    value: string;
    language?: string;
    mode: 'interactive' | 'static';
    /** Renderer-validated P0 HTML attributes, never raw source attributes. */
    htmlProps?: Record<string, string>;
}
export declare function CodeBlockView({ value, language, mode, htmlProps }: CodeBlockViewProps): ReactElement;
