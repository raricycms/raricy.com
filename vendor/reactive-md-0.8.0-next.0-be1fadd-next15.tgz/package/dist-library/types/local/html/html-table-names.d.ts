/**
 * Theme-free table vocabulary shared by the parser, HTML policy and audit
 * passes. Kept separate from `html-table.ts` so importing the accepted names
 * never pulls the HTML parser into a compiler assembly that does not use it.
 */
/** Contextual names: they do not reserve new component names globally. */
export declare const HTML_TABLE_NAMES: ReadonlySet<string>;
export declare const HTML_TABLE_ATTRIBUTES: Readonly<Record<string, ReadonlySet<string>>>;
export declare function validHtmlTableValue(name: string, value: string): boolean;
