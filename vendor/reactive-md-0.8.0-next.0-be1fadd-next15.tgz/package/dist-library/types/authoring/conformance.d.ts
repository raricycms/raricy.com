import type { EditorLocale } from './command-types.js';
import type { LocalConfig } from '../sdk/types.js';
/**
 * Insertion-template conformance for external components.
 *
 * Authoring templates are not compiled at registration time: a host may
 * declare a template before the component set (or its config) is final. This
 * helper performs the deferred check against the *same* configuration that
 * editing uses, so a catalog never offers a snippet that fails immediately.
 *
 * Static compiler imports are shared with catalog validation. The compiler
 * does not import authoring, so this dependency has no initialization cycle.
 */
export interface LocalInsertTemplateIssue {
    readonly id: string;
    readonly name: string;
    readonly message: string;
    readonly diagnostics: readonly {
        readonly code: string;
        readonly message: string;
    }[];
}
/** Compile every external catalog insertion template with `config`. */
export declare function validateLocalComponentInsertTemplates(config: LocalConfig, locale?: EditorLocale): readonly LocalInsertTemplateIssue[];
