import { type Plugin } from 'vite';
/** Directory mode: discover `theme/` and `plugin/` entries relative to the Vite root. */
export interface ReactiveMdDirectoryOptions {
    /** Theme root relative to the Vite root. Defaults to `theme`. */
    readonly themeDir?: string;
    /** Package entry root relative to the Vite root. Defaults to `plugin`. */
    readonly pluginDir?: string;
    /**
     * Install the built-in default preset. Defaults to true. Discovered preset
     * packages are installed in both modes; `false` installs no built-in preset.
     */
    readonly defaultPreset?: boolean;
}
/** Manual mode: one local module exporting `host = createReactHost(...)`. */
export interface ReactiveMdExtensionsOptions {
    /** Local module exporting `host = createReactHost(...)`. Relative to Vite root. */
    readonly extensions: string;
}
/**
 * Passing `extensions` selects manual registration. Omitting every option, or
 * passing only `themeDir`/`pluginDir`, enables directory registration.
 */
export type ReactiveMdViteOptions = ReactiveMdDirectoryOptions | ReactiveMdExtensionsOptions;
/**
 * Optional Node-only adapter. Directory mode discovers `theme/` and `plugin/`
 * once per snapshot and generates one registration module; manual mode keeps
 * the explicit `extensions` entry. Registration and code execution stay
 * explicit on the consumer side.
 */
export declare function reactiveMd(options?: ReactiveMdViteOptions): Plugin;
export default reactiveMd;
