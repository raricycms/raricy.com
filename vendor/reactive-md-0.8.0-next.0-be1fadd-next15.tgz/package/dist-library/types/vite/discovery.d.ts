import { type LocalStyleResource, type LocalThemePackage } from '../sdk/theme.js';
import { type LocalBuildAsset } from '../build/resources.js';
/**
 * Directory-driven discovery for the Vite adapter.
 *
 * The scheme is intentionally small and explicit:
 *
 * - `theme/<folder>/theme.css` is a theme. `theme/<folder>/theme.json` may
 *   override `id`, `name`, `version`, `protocol` and `colorSchemes`; defaults
 *   are `local/theme/<folder>`, `<folder>`, `0.0.0` and both color schemes.
 * - `plugin/<folder>/index.{ts,tsx,js,jsx,mts,mjs}` is a plugin entry. Exactly
 *   one entry per folder is allowed. `plugin/<folder>/component.css` is an
 *   optional structural stylesheet.
 *
 * Only those conventional files are inspected. Plugin entries are returned as
 * paths and are never imported here; evaluating them belongs to the adapter
 * that builds the registration module.
 *
 * CSS is inlined through `collectLocalBuildResources`, so local `@import`
 * targets and `url()` assets are resolved under the project root, traversal
 * and remote URLs are rejected, and every file read is bounded by
 * `DEFAULT_LOCAL_BUILD_BUDGETS`. The collector exposes no dependency list, so
 * its bounded asset list is the dependency/watch record; the absolute file
 * paths derived from it are returned in `files`.
 */
export interface DiscoveryOptions {
    readonly themeDir?: string;
    readonly pluginDir?: string;
}
export interface DiscoveredTheme {
    readonly file: string;
    readonly theme: LocalThemePackage;
}
export interface DiscoveredPlugin {
    readonly file: string;
    readonly resources: readonly LocalStyleResource[];
}
export interface DirectoryDiscovery {
    readonly themes: readonly DiscoveredTheme[];
    readonly plugins: readonly DiscoveredPlugin[];
    readonly files: readonly string[];
    readonly directories: readonly string[];
    readonly assets: readonly LocalBuildAsset[];
}
/**
 * Discover themes and plugins beneath a project root. Results and every nested
 * package/resource are frozen, sorted by path, and independent of the current
 * working directory. Missing roots produce empty results, but their normalized
 * paths remain in `directories` so a watcher can observe later creation.
 */
export declare function discoverDirectories(root: string, options?: DiscoveryOptions): Promise<DirectoryDiscovery>;
