export declare const rmdMotion: {
    fast: {
        type: 'tween';
        duration: number;
        ease: [number, number, number, number];
    };
    base: {
        type: 'tween';
        duration: number;
        ease: [number, number, number, number];
    };
};
