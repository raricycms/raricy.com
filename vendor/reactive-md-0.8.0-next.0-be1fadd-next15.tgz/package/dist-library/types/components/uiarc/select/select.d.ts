import type { ComponentPropsWithoutRef } from "react";
import * as SelectPrimitive from "@radix-ui/react-select";
export interface SelectProps extends Omit<ComponentPropsWithoutRef<typeof SelectPrimitive.Root>, "children"> {
    label: string;
    description?: string;
    placeholder?: string;
    id?: string;
    className?: string;
    options: {
        value: string;
        label: string;
        disabled?: boolean;
    }[];
    /** Marks the trigger invalid so the surrounding field can announce it. */
    invalid?: boolean;
    /** Ids of hints or errors that describe the trigger. */
    describedBy?: string;
    /** Portal target for the menu. Documents theme their variables on the document root. */
    portalContainer?: HTMLElement | null;
}
export declare const Select: import("react").ForwardRefExoticComponent<SelectProps & import("react").RefAttributes<HTMLButtonElement>>;
