export type CalendarDateMatcher = (date: Date) => boolean;
export interface CalendarProps {
    value?: Date;
    onChange?: (date: Date) => void;
    month?: Date;
    onMonthChange?: (month: Date) => void;
    minDate?: Date;
    maxDate?: Date;
    disabledDates?: CalendarDateMatcher;
    locale?: string;
    className?: string;
    /** Adds a Today button that slides back to the current month and selects today when it is available. */
    showToday?: boolean;
    /** Localized names for the header controls and the Today button. */
    todayLabel?: string;
    previousMonthLabel?: string;
    nextMonthLabel?: string;
}
declare const startOfDay: (date: Date) => Date;
declare const sameDay: (a?: Date, b?: Date) => boolean;
declare const addDays: (date: Date, amount: number) => Date;
declare const addMonths: (date: Date, amount: number) => Date;
/** The viewer's local date (lib/use-today.ts, shared with date-range-picker). Re-exported so existing imports from calendar keep working. */
export { useToday } from "../lib/use-today.js";
export declare function Calendar({ value, onChange, month: controlledMonth, onMonthChange, minDate, maxDate, disabledDates, locale, className, showToday, todayLabel, previousMonthLabel, nextMonthLabel, }: CalendarProps): import("react").JSX.Element;
export { addDays, addMonths, sameDay, startOfDay };
