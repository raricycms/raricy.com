/**
 * Result adaptation for the single-pass compiler entries.
 *
 * The semantic pass still produces `LocalCompileResult`. This module is the
 * only place that maps it to the public `CompileResult` union: it determines
 * `valid` / `recovered` / `failed`, keeps the task-one `ok` and `document`
 * aliases, and publishes the program as an independent, iteratively frozen
 * plain-data snapshot. It never creates a runtime, session, worker, timer or
 * cache.
 */
import type { LocalCompileResult } from '../local/contracts/types.js';
import type { CheckCoverage, CompileResult } from './types.js';
/** Optional-check coverage used by the minimal compiler. */
export declare const MINIMAL_CHECKS: CheckCoverage;
/** Optional-check coverage used by the standard compiler. */
export declare const STANDARD_CHECKS: CheckCoverage;
/**
 * Freeze a plain compiler value without recursion. The stack is explicit so a
 * deeply nested document cannot exhaust the call stack, and a `Set` guards
 * against accidental cycles.
 */
export declare function freezeProgram<T>(value: T): T;
/**
 * Adapt one semantic-pass result. Author-source errors become `failed`; a
 * successful pass is `recovered` only when the parser actually recorded a
 * repair. Recoveries never upgrade a failure, so unrelated semantic errors
 * keep their `failed` status. Internal exceptions are not caught here and
 * cannot be reported as recoveries by construction.
 */
export declare function toCompileResult(result: LocalCompileResult, checks: CheckCoverage): CompileResult;
