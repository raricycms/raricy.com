import type { LocalExtensionRequirements } from './sdk/types.js';
import { type LocalRestorationRequirements } from './export/restoration.js';
import type { LocalStyleResource } from './sdk/theme.js';
import { type LocalStateFile, type LocalStateGenerator } from './local/runtime/state.js';
import type { Diagnostic, LocalCompileOptions, LocalDocument, LocalValue } from './local/contracts/types.js';
import { type LocalComponentStateDocument } from './runtime-services/component-state.js';
/** Version of the single-file HTML envelope, not of the document syntax. */
export declare const SHAREABLE_HTML_FORMAT: 'reactive-md-html/v1';
export declare const SHAREABLE_HTML_FORMAT_V2: 'reactive-md-html/v2';
export type ShareableHtmlMode = 'interactive' | 'static';
export type ShareableAssetMode = 'inline' | 'omit';
export interface ShareableMountPayload {
    version: 1 | 2;
    target: string;
    source: string;
    state: LocalStateFile;
    locale: 'en' | 'zh';
    colorScheme: 'light' | 'dark' | 'auto';
    hydrate: boolean;
    /** Capability flags and limits the document was compiled with. */
    compileOptions?: LocalCompileOptions;
    /** Installed component contracts required before applying saved state. */
    extensions?: LocalExtensionRequirements;
    restoration?: LocalRestorationRequirements;
    resources?: readonly LocalStyleResource[];
    /** Verified relative image URL -> inline raster data URL. */
    images?: Readonly<Record<string, string>>;
    /** Stable document identity used to scope component state. */
    documentId?: string;
    /** Document-level seed for component randomness. */
    randomSeed?: number;
    /** Validated component-state sidecar restored by the standalone runtime. */
    componentState?: LocalComponentStateDocument;
}
export interface ShareableHtmlOptions {
    /** Plain text title; it is escaped by this function. */
    title: string;
    source: string;
    state: LocalStateFile;
    /** Already rendered by the trusted React renderer in static mode. */
    staticMarkup: string;
    /** Trusted host stylesheet, normally the built reactive-md.css. */
    css: string;
    mode: ShareableHtmlMode;
    /** Required for interactive output; the standalone IIFE source. */
    runtimeScript?: string;
    locale?: 'en' | 'zh';
    colorScheme?: 'light' | 'dark' | 'auto';
    generator?: LocalStateGenerator;
    assets?: ShareableAssetMode;
    /** Diagnostics shown in authoring tools; the HTML only records the count. */
    imageCount?: number;
    /** Verified relative image URLs and their inline raster data URLs. */
    images?: Readonly<Record<string, string>>;
    /** Stable document identity used to scope component state in interactive output. */
    documentId?: string;
    /** Document-level seed for component randomness in interactive output. */
    randomSeed?: number;
    /** Component-state sidecar embedded for interactive output. */
    componentState?: LocalComponentStateDocument;
    notices?: string;
    targetId?: string;
    /**
     * Routing capabilities granted by the host and used to compile this exact
     * document. Interactive exports replay them; static native exports are
     * re-sanitized with author JavaScript forced off.
     */
    compileOptions?: LocalCompileOptions;
    /** Companion component requirements, separate from the v1 state format. */
    extensions?: LocalExtensionRequirements;
    /** v2 envelopes verify these contracts and resources before state recovery. */
    restoration?: LocalRestorationRequirements;
    resources?: readonly LocalStyleResource[];
}
export interface LocalStateBaselineResult {
    document: LocalDocument;
    state: Readonly<Record<string, LocalValue>>;
}
export type LocalStateBaselineOutcome = {
    ok: true;
    baseline: LocalStateBaselineResult;
} | {
    ok: false;
    diagnostics: Diagnostic[];
};
/** Escape JSON so it cannot terminate its script element or form HTML text. */
export declare function serializeForScript(value: unknown): string;
/**
 * Rebase public binding defaults onto a validated exported state. The exported
 * document then has one baseline for first render, refresh and Reset instead of
 * silently resetting a shared export to values the author did not select.
 */
export declare function resolveLocalStateBaseline(document: LocalDocument, state: LocalStateFile): LocalStateBaselineOutcome;
/**
 * Build the deterministic single-file HTML envelope. Caller-provided markup and
 * runtime code are trusted build artifacts; all metadata and JSON are escaped.
 */
export declare function createShareableHtml(options: ShareableHtmlOptions): string;
