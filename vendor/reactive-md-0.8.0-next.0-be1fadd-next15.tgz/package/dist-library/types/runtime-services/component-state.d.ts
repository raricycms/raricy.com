/**
 * Versioned, bounded component state and an in-memory state registry.
 *
 * This module defines the save protocol. It does not decide where bytes live:
 * the host can export a snapshot, pass it back to a new runtime, or persist it
 * through a browser backend. Multi-instance writing is deliberately explicit;
 * there is no cross-tab synchronization.
 */
import type { Diagnostic } from '../local/contracts/types.js';
import { type LocalRandomState } from './random.js';
export declare const LOCAL_COMPONENT_STATE_FORMAT: 'reactive-md-component-state/v1';
export declare const LOCAL_COMPONENT_STATE_DOCUMENT_FORMAT: 'reactive-md-component-state-document/v1';
export declare const MAX_COMPONENT_STATE_BYTES: number;
export declare const MAX_COMPONENT_STATE_TOTAL_BYTES: number;
export declare const MAX_COMPONENT_STATE_DEPTH = 16;
export declare const MAX_COMPONENT_STATE_ITEMS = 10000;
export declare const MAX_COMPONENT_STATE_STRING = 100000;
export declare const MAX_COMPONENT_STATE_DOCUMENT_INPUT: number;
export type LocalComponentStateData = null | boolean | number | string | readonly LocalComponentStateData[] | {
    readonly [key: string]: LocalComponentStateData;
};
export interface LocalComponentStateRecord {
    readonly format: typeof LOCAL_COMPONENT_STATE_FORMAT;
    readonly component: string;
    readonly componentVersion: string;
    readonly stateVersion: number;
    readonly key: string;
    readonly documentId?: string;
    readonly data: LocalComponentStateData;
    readonly random?: LocalRandomState;
}
export interface LocalComponentStateDocument {
    readonly format: typeof LOCAL_COMPONENT_STATE_DOCUMENT_FORMAT;
    /**
     * Semantic configuration that produced these records. Sidecars written
     * before this field existed restore through the existing record checks; a
     * present value must match the current config key or one of its legacy
     * aliases.
     */
    readonly configKey?: string;
    readonly records: Readonly<Record<string, LocalComponentStateRecord>>;
}
export interface LocalComponentStateSaveResult {
    readonly ok: boolean;
    readonly diagnostics: Diagnostic[];
    readonly record?: LocalComponentStateRecord;
}
export interface LocalComponentStateRestoreResult {
    readonly accepted: readonly string[];
    readonly skipped: readonly string[];
    readonly diagnostics: Diagnostic[];
}
export interface LocalComponentStateHandleInput {
    readonly nodeId: string;
    readonly component: string;
    readonly componentVersion: string;
    readonly stateKey?: string;
    /** Default state version when `save` does not override it. */
    readonly stateVersion?: number;
}
export interface LocalComponentStateHandle {
    readonly key: string;
    readonly component: string;
    readonly componentVersion: string;
    readonly duplicate: boolean;
    load(): LocalComponentStateRecord | null;
    save(data: unknown, options?: {
        version?: number;
        random?: LocalRandomState;
    }): LocalComponentStateSaveResult;
    clear(): void;
}
export interface LocalComponentStateRegistry {
    readonly documentId: string;
    readonly sourceDigest: string;
    key(input: Omit<LocalComponentStateHandleInput, 'component' | 'componentVersion' | 'stateVersion'>): string;
    handle(input: LocalComponentStateHandleInput): LocalComponentStateHandle;
    load(key: string): LocalComponentStateRecord | null;
    clear(key: string): void;
    snapshot(): LocalComponentStateDocument;
    restore(input: unknown): LocalComponentStateRestoreResult;
    /** Write any pending sidecar now instead of waiting for `writeDelayMs`. */
    flush(): void;
    diagnostics(): readonly Diagnostic[];
    subscribe(listener: () => void): () => void;
}
/**
 * Persistence port. The registry owns the save protocol and calls this after
 * every successful save or clear; with `writeDelayMs` it may call once for
 * several changes. It never syncs across tabs and never reads after creation.
 * Implementations may be in-memory, browser storage or a host service.
 */
export interface LocalComponentStateStorage {
    /**
     * Return the persisted sidecar (JSON text or a JSON-safe value), or `null`
     * when nothing is stored. The registry validates the payload like any other
     * sidecar and skips what does not match.
     */
    read(): unknown;
    /** Persist one complete sidecar. Throwing leaves the in-memory state intact. */
    write(document: LocalComponentStateDocument): void;
    /** Delete the persisted sidecar. */
    remove(): void;
}
export type LocalComponentStateParseResult = {
    readonly ok: true;
    readonly document: LocalComponentStateDocument;
    readonly records: Readonly<Record<string, LocalComponentStateRecord>>;
    readonly diagnostics: Diagnostic[];
    readonly skipped: readonly string[];
} | {
    readonly ok: false;
    readonly diagnostics: Diagnostic[];
};
/**
 * Validate a sidecar without creating a registry. Individual records that fail
 * validation are skipped and reported; a payload that is not a sidecar at all
 * returns `ok: false`.
 */
export declare function parseLocalComponentStateDocument(input: unknown): LocalComponentStateParseResult;
export interface CreateLocalComponentStateRegistryOptions {
    readonly documentId?: string;
    readonly sourceDigest: string;
    /** Sidecar payload to restore before the first render. */
    readonly initial?: unknown;
    /**
     * Persistence port. When set and `initial` is omitted, the registry restores
     * the stored sidecar; later saves and clears write the complete sidecar back.
     */
    readonly storage?: LocalComponentStateStorage;
    /**
     * Coalesce persistence writes. Memory always updates immediately; with a
     * positive delay the complete sidecar is written at most once per window, so
     * high-frequency saves do not serialize and store on every change. Call
     * `flush()` to write pending state now, for example on `pagehide`. Defaults
     * to 0, which writes synchronously after every save or clear.
     */
    readonly writeDelayMs?: number;
    /**
     * Keys currently present in the document. A function is evaluated at each
     * restore so live document updates are reflected.
     */
    readonly knownKeys?: ReadonlySet<string> | (() => ReadonlySet<string>);
    /**
     * Current semantic configuration key. When set, snapshots and persisted
     * sidecars carry it and restore skips records written by another config.
     */
    readonly configKey?: string;
    /** Legacy configuration identities accepted during restore. */
    readonly legacyConfigKeys?: readonly string[];
}
export declare function createLocalComponentStateRegistry(options: CreateLocalComponentStateRegistryOptions): LocalComponentStateRegistry;
