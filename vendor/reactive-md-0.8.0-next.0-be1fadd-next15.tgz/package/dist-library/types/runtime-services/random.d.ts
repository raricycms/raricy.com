/**
 * Serializable seeded randomness.
 *
 * The random state lives in component state. These are pure functions: the
 * host never owns a mutable, implicitly advancing generator, so React state
 * updaters and Strict Mode double invocations stay deterministic.
 */
export declare const LOCAL_RANDOM_ALGORITHM: 'mulberry32';
export declare const LOCAL_RANDOM_VERSION: 1;
export interface LocalRandomState {
    readonly algorithm: typeof LOCAL_RANDOM_ALGORITHM;
    readonly version: typeof LOCAL_RANDOM_VERSION;
    /** Current 32-bit generator position. */
    readonly state: number;
}
export interface LocalRandomStep {
    readonly value: number;
    readonly state: LocalRandomState;
}
export interface LocalRandomIntStep {
    readonly value: number;
    readonly state: LocalRandomState;
}
export interface LocalRandomShuffleStep<T> {
    readonly items: T[];
    readonly state: LocalRandomState;
}
export declare function createRandom(seed: number): LocalRandomState;
/** Validate and normalize a saved random state. */
export declare function normalizeRandomState(value: unknown): LocalRandomState | null;
/** Mulberry32: one 32-bit word of state, uniform in [0, 1). */
export declare function nextRandom(random: LocalRandomState): LocalRandomStep;
/** Inclusive integer range. Invalid or reversed bounds are normalized. */
export declare function randomInt(random: LocalRandomState, min: number, max: number): LocalRandomIntStep;
/** Fisher-Yates over a copy; the input array is never mutated. */
export declare function shuffleRandom<T>(random: LocalRandomState, items: readonly T[]): LocalRandomShuffleStep<T>;
/** Create an independent stream from a base seed and label. */
export declare function deriveRandom(seed: number, label: string): LocalRandomState;
export declare function randomBool(random: LocalRandomState, probability?: number): {
    value: boolean;
    state: LocalRandomState;
};
