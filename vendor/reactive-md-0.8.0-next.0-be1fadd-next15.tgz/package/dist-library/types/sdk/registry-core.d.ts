import { type NormalizedComponent } from '../local/compilation/component-kernel.js';
import type { LocalComponentSchema } from '../local/configuration/schema-core.js';
import type { LocalComponentDefinition } from './types.js';
/** Project a public manifest onto the legacy `LocalComponentSchema` view. */
export declare function componentSchemaFromDefinition(definition: LocalComponentDefinition): LocalComponentSchema;
/** Cached alias used by callers that already hold a manifest. */
export declare function localComponentSchema(definition: LocalComponentDefinition): LocalComponentSchema;
/**
 * Normalize a public manifest exactly once for compilation.
 *
 * Unlike `componentSchemaFromDefinition`, which projects the legacy public
 * schema view, this returns the single internal model: structure derived once,
 * bindings normalized, and no compatibility aliases left for later stages to
 * reinterpret.
 */
export declare function normalizedComponentFromDefinition(definition: LocalComponentDefinition): NormalizedComponent;
