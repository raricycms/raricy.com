import type { LocalCompatProfile } from './compat-profile.js';
import type { LocalConfig, LocalConfigInput, LocalPresetInput } from './types.js';
import type { Diagnostic, LocalDocument } from '../local/contracts/types.js';
import { MAX_LOCAL_SDK_CONFIG_BYTES } from './config-validation.js';
/** Identifiers the default preset contributes in phase one. */
export declare const DEFAULT_PRESET_ID: string;
export declare const DEFAULT_PRESET_VERSION: string;
/** Bounded theme/resource registration budgets for one configuration. */
export declare const MAX_LOCAL_SDK_THEMES = 16;
/** Aggregate serialized-size budget for one configuration, including theme CSS. */
export { MAX_LOCAL_SDK_CONFIG_BYTES };
/** Create an immutable, validated instance configuration. */
export declare function createLocalConfig(input?: LocalConfigInput): LocalConfig;
/** Fingerprint of the manifests that the compiler actually used. */
export declare function localComponentConfigKey(config?: LocalConfig): string;
/** Older compiled documents have no fingerprint and retain contract-based checks. */
export declare function validateLocalDocumentConfig(document: LocalDocument, config?: LocalConfig): Diagnostic[];
/**
 * Revalidate arbitrary configuration data, including a Worker snapshot or a
 * hand-built payload. Supplied derived fields are ignored and rebuilt from the
 * assembly snapshot.
 *
 * `additionalProfiles` extends the SDK-built-in compatibility table with
 * explicit data. It never infers a legacy identity from the current SDK
 * version.
 */
export declare function readLocalConfig(value: unknown, additionalProfiles?: readonly LocalCompatProfile[]): LocalConfig;
/** Cache/transport key that never throws; invalid payloads stay distinct. */
export declare function localConfigKey(value: unknown): string;
/**
 * Worker-side copy. A valid configuration is revalidated into fresh frozen
 * data; an invalid one is passed through so the compiler can report it.
 */
export declare function snapshotLocalConfig(value: unknown): unknown;
export type { LocalPresetInput };
