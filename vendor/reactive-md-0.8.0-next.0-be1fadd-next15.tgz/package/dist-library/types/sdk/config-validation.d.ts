import type { LocalComponentDefinition, LocalPresetReference } from './types.js';
import type { LocalCompatProfile } from './compat-profile.js';
/**
 * Theme-free SDK configuration validation shared by the full SDK entry and the
 * single-compilation reader.
 *
 * This module deliberately imports neither `theme.ts` nor the default preset.
 * Callers pass their assembled built-in component set, so the same rules serve
 * an assembly that installs `defaultPreset.components` and one that installs no
 * preset at all.
 */
/** Aggregate serialized-size budget for one configuration, excluding themes. */
export declare const MAX_LOCAL_SDK_CONFIG_BYTES: number;
export declare const DANGEROUS_KEYS: ReadonlySet<string>;
export declare const CONFIG_KEYS: ReadonlySet<string>;
export declare function fail(path: string, message: string): never;
export declare function isPlainRecord(value: unknown): value is Record<string, unknown>;
export declare function checkKeys(record: Record<string, unknown>, allowed: ReadonlySet<string>, path: string): void;
/**
 * Read the selected preset references against the current default identity and
 * any legacy identities supported by compatibility profiles. Omitting
 * `presets` selects the current default; `"default"` normalizes to it. A
 * declared identity must match a profile exactly, including its version.
 */
export declare function readPresetReferences(value: unknown, preset: LocalPresetReference, profiles?: readonly LocalCompatProfile[]): readonly LocalPresetReference[];
/** Verify the optional legacy component snapshot against installed manifests. */
export declare function validateCompatProfileComponents(profile: LocalCompatProfile, installed: readonly LocalComponentDefinition[]): void;
/**
 * Read external component manifests. Built-in names, kernel grammar names,
 * HTML tag names and the theme declaration are reserved, and external ids may
 * not collide with each other or with the built-in registry.
 */
export declare function readComponents(value: unknown, defaults: readonly LocalComponentDefinition[]): readonly LocalComponentDefinition[];
