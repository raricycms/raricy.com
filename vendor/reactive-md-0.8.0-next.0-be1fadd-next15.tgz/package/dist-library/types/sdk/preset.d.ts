import { defineLocalPreset as defineLocalPresetCore } from './preset-core.js';
import type { LocalPresetPackage } from './types.js';
/** Validate, clone and freeze one preset package, including its themes. */
export declare function readLocalPresetPackage(value: unknown): LocalPresetPackage;
/** Public factory mirroring `defineLocalComponent`. */
export declare function defineLocalPreset(input: LocalPresetPackage): LocalPresetPackage;
/** Semantic digest; themes and authoring are excluded. */
export declare function localPresetDigest(preset: LocalPresetPackage): string;
export { defineLocalPresetCore };
