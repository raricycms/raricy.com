import type { LocalCompatProfile } from './compat-profile.js';
import type { LocalStyleResource, LocalThemePackage } from './theme.js';
import type { LocalAssemblySnapshot, LocalComponentDefinition, LocalComponentRequirement, LocalConfig, LocalLegacyConfigKey, LocalReplacementRecord, LocalResolvedPreset } from './types.js';
/**
 * Deterministic assembly resolver.
 *
 * The resolver is the only place that turns pre-replacement contributions into
 * an active registry. Both the SDK reader and the compiler reader use it, so a
 * transported snapshot cannot acquire a different meaning at a second entry
 * point.
 */
export interface ResolvedLocalAssembly {
    readonly presets: readonly LocalResolvedPreset[];
    readonly components: readonly LocalComponentDefinition[];
    readonly replacements: readonly LocalReplacementRecord[];
    readonly registry: readonly LocalComponentDefinition[];
    readonly themes: readonly LocalThemePackage[];
    readonly key: string;
}
/** Validate and freeze a transported assembly snapshot. */
export declare function readLocalAssemblySnapshot(value: unknown): LocalAssemblySnapshot;
/** Stable semantic configuration key. */
export declare function localAssemblyKey(presets: readonly LocalResolvedPreset[], registry: readonly LocalComponentDefinition[], replacements: readonly LocalReplacementRecord[]): string;
/**
 * Legacy v1 key for the default-only profile. It is emitted as an alias, never
 * as the primary identity of a v2 configuration.
 */
export declare function localLegacyV1Key(preset: {
    readonly id: string;
    readonly version: string;
}, components: readonly LocalComponentDefinition[]): string;
export interface ResolveAssemblyOptions {
    /** Compatibility profiles that may claim a single-preset v1 alias. */
    readonly legacyProfiles?: readonly LocalCompatProfile[];
}
/** Resolve a validated snapshot into a frozen registry and semantic identity. */
export declare function resolveLocalAssembly(snapshot: LocalAssemblySnapshot, options?: ResolveAssemblyOptions): ResolvedLocalAssembly & {
    readonly legacyKeys: readonly LocalLegacyConfigKey[];
};
/**
 * Build the frozen public configuration view from one resolved assembly.
 * Readers keep their own normalization, profile selection and legacy-key
 * rules; this function owns only the shared result shape.
 */
export declare function localConfigFromAssembly(assembly: LocalAssemblySnapshot, resolved: ResolvedLocalAssembly & {
    readonly legacyKeys: readonly LocalLegacyConfigKey[];
}, legacyKeys?: readonly LocalLegacyConfigKey[]): LocalConfig;
/**
 * Compact, transportable identity of one resolved assembly. It is safe to
 * embed in bundle seals, restoration requirements and state sidecars; it
 * contains no React functions, CSS or file paths.
 */
export interface LocalAssemblyIdentity {
    readonly protocol: 'reactive-md-assembly-seal/v1';
    readonly configKey: string;
    readonly presets: readonly LocalResolvedPreset[];
    readonly components: readonly LocalComponentRequirement[];
    readonly replacements: readonly LocalReplacementRecord[];
    readonly legacyKeys: readonly LocalLegacyConfigKey[];
}
type AssemblyIdentityInput = {
    readonly key: string;
    readonly presets: readonly LocalResolvedPreset[];
    readonly registry: readonly LocalComponentDefinition[];
    readonly replacements: readonly LocalReplacementRecord[];
    readonly legacyKeys: readonly LocalLegacyConfigKey[];
};
export declare function localAssemblyIdentity(input: AssemblyIdentityInput): LocalAssemblyIdentity;
/** Deterministic digest over the assembly identity. */
export declare function localAssemblySeal(input: AssemblyIdentityInput): string;
/** Accept both the primary v2 key and its supported legacy aliases. */
export declare function localConfigKeyMatches(input: AssemblyIdentityInput, key: string): boolean;
export type { LocalStyleResource };
