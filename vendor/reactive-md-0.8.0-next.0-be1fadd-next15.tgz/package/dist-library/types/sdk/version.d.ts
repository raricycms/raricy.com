/**
 * SDK protocol identities and package version.
 *
 * These revisions are independent from each other and from the document
 * syntax revision: a package release may move one without changing the others.
 */
export declare const LOCAL_SDK_VERSION: '0.7.0';
export declare const LOCAL_COMPONENT_PROTOCOL: 'reactive-md-component/v1';
/** Legacy configuration protocol. Readable through the v1 compatibility profile. */
export declare const LOCAL_CONFIG_PROTOCOL: 'reactive-md-config/v1';
/** Assembly-based configuration protocol. New configs are written in this form. */
export declare const LOCAL_CONFIG_PROTOCOL_V2: 'reactive-md-config/v2';
export declare const LOCAL_PRESET_PROTOCOL: 'reactive-md-preset/v1';
export declare const LOCAL_REACT_PRESET_PROTOCOL: 'reactive-md-react-preset/v1';
export declare const LOCAL_ASSEMBLY_PROTOCOL: 'reactive-md-assembly/v1';
export declare const LOCAL_EXTENSIONS_PROTOCOL: 'reactive-md-extensions/v1';
/** Bounded range syntax: exact, `^`, `~`, `=`, `>`, `>=`, `<`, `<=`. */
export declare const MAX_LOCAL_VERSION_RANGE_LENGTH = 128;
export declare const MAX_LOCAL_VERSION_COMPARATORS = 8;
interface ParsedVersion {
    readonly major: number;
    readonly minor: number;
    readonly patch: number;
    readonly prerelease: readonly (string | number)[];
}
export type LocalVersionOperator = '=' | '>' | '>=' | '<' | '<=';
export interface LocalVersionComparator {
    readonly operator: LocalVersionOperator;
    readonly version: ParsedVersion;
}
export interface LocalVersionRange {
    readonly source: string;
    readonly comparators: readonly LocalVersionComparator[];
}
/**
 * Parse a bounded semver range. Unsupported syntax (`*`, `||`, hyphen ranges,
 * wildcards, `v` prefixes, spaced operators) returns null instead of being
 * approximated.
 */
export declare function parseLocalVersionRange(source: unknown): LocalVersionRange | null;
/** True when `version` is a valid, complete semantic version. */
export declare function isLocalVersion(value: unknown): value is string;
/**
 * Check one installed version against a parsed or textual range. Invalid
 * versions or ranges never satisfy the range.
 */
export declare function localVersionSatisfies(version: string, range: string | LocalVersionRange): boolean;
export declare function isLocalVersionRange(value: unknown): value is LocalVersionRange;
export {};
