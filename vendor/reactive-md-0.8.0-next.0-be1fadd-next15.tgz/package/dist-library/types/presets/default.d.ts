import type { LocalPresetPackage } from '../sdk/types.js';
/**
 * The default component preset. Its components are ordinary public SDK
 * manifests, validated by `defineLocalComponent` at construction. Language
 * declarations (`theme`, `computed`, `const`, `external`) remain kernel grammar
 * metadata and are not preset components.
 */
export interface LocalDefaultPreset extends LocalPresetPackage {
}
export declare const defaultPreset: LocalDefaultPreset;
export default defaultPreset;
