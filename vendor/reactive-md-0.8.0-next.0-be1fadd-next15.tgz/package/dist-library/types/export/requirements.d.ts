import type { LocalComponentDefinition, LocalConfig } from '../sdk/types.js';
import type { Diagnostic, LocalDocument } from '../local/contracts/types.js';
export declare function extensionDiagnostic(code: string, message: string): Diagnostic;
/** Requirements select installed implementations; they never load or execute code. */
export declare function validateLocalExtensionRequirements(requirements: unknown, config?: LocalConfig): Diagnostic[];
export interface LocalComponentContractCheck {
    readonly document: LocalDocument;
    /** Installed default preset plus external definitions for this host. */
    readonly installed: readonly LocalComponentDefinition[];
    /** Tag names of installed external components (not the default preset). */
    readonly externalNames?: ReadonlySet<string>;
}
/**
 * Preflight the compiled component contracts against the installed manifests.
 *
 * Carried `document.componentDefinitions` are never trusted to replace
 * installed semantics: each entry must revalidate through the public manifest
 * reader and match an installed id/name/version/digest. External component
 * nodes must be covered by matching extension requirements. Default-only
 * documents without carried definitions stay valid through the installed
 * default preset.
 */
export declare function validateLocalComponentContracts(check: LocalComponentContractCheck): Diagnostic[];
