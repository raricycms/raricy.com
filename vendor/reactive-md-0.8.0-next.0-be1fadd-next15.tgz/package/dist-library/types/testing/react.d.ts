import type { LocalConfig } from '../sdk/types.js';
import type { LocalStyleResource } from '../sdk/theme.js';
import type { LocalReactConfig } from '../react/sdk.js';
import { LOCAL_REACT_SPEC_PROTOCOL, type LocalComplianceSuiteResult } from './types.js';
export interface LocalReactErrorProbe {
    readonly source: string;
    /** Defaults to the main config/react config. */
    readonly config?: LocalConfig;
    readonly reactConfig?: LocalReactConfig;
    /** Expected diagnostic code; defaults to `local.extension.ssr-render`. */
    readonly code?: string;
    readonly messageIncludes?: string;
}
export interface LocalReactComplianceSpec {
    readonly protocol: typeof LOCAL_REACT_SPEC_PROTOCOL;
    readonly source: string;
    readonly staticMarkupIncludes?: readonly string[];
    readonly staticMarkupExcludes?: readonly string[];
    readonly ssrMarkupIncludes?: readonly string[];
    readonly ssrMarkupExcludes?: readonly string[];
    readonly error?: LocalReactErrorProbe;
}
export interface LocalReactComplianceOptions {
    readonly resources?: readonly LocalStyleResource[];
    readonly config: LocalConfig | unknown;
    readonly reactConfig: LocalReactConfig;
    /** Tag name under test. */
    readonly component: string;
    readonly spec: LocalReactComplianceSpec | unknown;
    readonly locale?: 'en' | 'zh';
}
/** Validate a React/SSR compliance spec before rendering anything. */
export declare function readLocalReactSpec(value: unknown): LocalReactComplianceSpec;
/**
 * Execute static rendering, strict SSR and an optional server error probe.
 *
 * Static evidence renders the document view directly in static mode. SSR
 * evidence goes through `renderLocalStaticDocument`, which preflights declared
 * capabilities and rejects unavailable placeholders. The probe proves that a
 * failing implementation is reported as a diagnostic instead of escaping.
 */
export declare function runLocalReactCompliance(input: LocalReactComplianceOptions): LocalComplianceSuiteResult;
/** Exposed for adapters that need the same markup contract. */
export declare function checkLocalComplianceMarkup(markup: string, includes?: readonly string[], excludes?: readonly string[]): readonly string[];
export declare const REACT_COMPLIANCE_CAPABILITIES: readonly ["static", "ssr"];
