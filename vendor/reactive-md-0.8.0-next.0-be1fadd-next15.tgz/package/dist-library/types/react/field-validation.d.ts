/**
 * Pure text-field validation shared by the built-in controls and the document
 * renderer. It contains no component state and no localization lookup; callers
 * pass the message table they already use.
 */
export declare function textProblem(value: string, options: {
    required: boolean;
    minLength?: number;
    maxLength?: number;
    email?: boolean;
}, t: (en: string, zh: string) => string): string | null;
