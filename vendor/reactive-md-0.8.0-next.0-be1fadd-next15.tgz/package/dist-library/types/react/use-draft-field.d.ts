import type { LocalComponentContext } from './component-api.js';
/**
 * Editable draft state shared by text-like controls. The draft follows the
 * bound display value while the field is neither focused nor composing; a
 * subtree reset restores the latest display value and clears field state.
 */
export declare function useDraftField(context: LocalComponentContext, display: string, clearWriterError: (value: null) => void): {
    draft: string;
    focused: boolean;
    touched: boolean;
    draftError: string | null;
    composing: import("react").RefObject<boolean>;
    setDraft: import("react").Dispatch<import("react").SetStateAction<string>>;
    setFocused: import("react").Dispatch<import("react").SetStateAction<boolean>>;
    setTouched: import("react").Dispatch<import("react").SetStateAction<boolean>>;
    setDraftError: import("react").Dispatch<import("react").SetStateAction<string | null>>;
};
