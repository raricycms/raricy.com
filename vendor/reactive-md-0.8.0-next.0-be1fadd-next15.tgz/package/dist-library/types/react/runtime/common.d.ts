import type { Diagnostic } from '../../local/contracts/types.js';
import type { LocalComponentContext } from '../component-api.js';
export declare function componentDiagnostic(context: LocalComponentContext, code: string, message: string): Diagnostic;
export declare function reportError(context: LocalComponentContext, code: string, error: unknown): void;
