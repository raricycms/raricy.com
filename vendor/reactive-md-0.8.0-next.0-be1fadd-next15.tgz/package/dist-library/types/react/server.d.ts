import { type LocalDocumentViewProps } from '../local/rendering/LocalDocumentView.js';
import type { Diagnostic } from '../local/contracts/types.js';
import type { LocalStyleResource } from '../sdk/theme.js';
export type LocalStaticRenderResult = {
    readonly ok: true;
    readonly markup: string;
    readonly diagnostics: readonly Diagnostic[];
} | {
    readonly ok: false;
    readonly diagnostics: readonly Diagnostic[];
};
/** Strict server execution: preflight capabilities, then return markup or diagnostics. */
export declare function renderLocalStaticDocument(options: Omit<LocalDocumentViewProps, 'mode' | 'staticFirst'> & {
    readonly resources?: readonly LocalStyleResource[];
}): LocalStaticRenderResult;
