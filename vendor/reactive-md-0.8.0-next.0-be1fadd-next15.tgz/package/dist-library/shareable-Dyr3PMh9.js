import { D as e, G as t, W as n, k as r, q as i, rt as a, z as o } from "./identity-MYJXKSkB.js";
import { f as s, l as c, u as l } from "./config-validation-DXTynAw7.js";
import { w as u } from "./validation-W-bmny-x.js";
import { a as d, c as f, l as p, o as m, s as h } from "./parser-standard-DlCk7sLo.js";
import { s as ee, u as g } from "./registry-De2QLL87.js";
import { n as _ } from "./options-D3KYx3nd.js";
import { t as v } from "./runtime-BXjKrC6W.js";
import { C as y, u as te, w as ne } from "./component-state-Cq2K5gkS.js";
import { i as re, t as ie } from "./resources-haWO_iJb.js";
// src/local/runtime/state.ts
var b = "reactive-md-state/v1", x = 1048576, S = /^fnv1a32:[0-9a-f]{8}$/, C = /* @__PURE__ */ new Set([
	"format",
	"syntax",
	"sourceDigest",
	"parameters",
	"generator"
]), w = /* @__PURE__ */ new Set(["name", "version"]), ae = new TextEncoder();
function T(e, t) {
	return {
		code: e,
		message: t.length > 2e3 ? `${t.slice(0, a - 1)}…` : t,
		severity: "error",
		range: {
			start: 0,
			end: 0
		},
		line: 1,
		column: 1
	};
}
function E(e, t, n) {
	e.length < 100 && e.push(T(t, n));
}
function D(e) {
	return e instanceof Error ? e.message : String(e);
}
function O(e) {
	for (let t = 0; t < e.length; t += 1) {
		let n = e.charCodeAt(t);
		if (n >= 55296 && n <= 56319) {
			let n = e.charCodeAt(t + 1);
			if (n >= 56320 && n <= 57343) {
				t += 1;
				continue;
			}
			return !1;
		}
		if (n >= 56320 && n <= 57343) return !1;
	}
	return !0;
}
function k(e) {
	if (typeof e == "string") return O(e) ? {
		ok: !0,
		value: e
	} : {
		ok: !1,
		message: "contains malformed Unicode."
	};
	if (typeof e == "number") return Number.isFinite(e) ? {
		ok: !0,
		value: e
	} : {
		ok: !1,
		message: "must be a finite number."
	};
	if (typeof e == "boolean" || e === null) return {
		ok: !0,
		value: e
	};
	if (Array.isArray(e)) {
		let t = [], n = e.length === 0 ? "string" : typeof e[0];
		for (let r = 0; r < e.length; r += 1) {
			let i = e[r];
			if (n === "string" && typeof i == "string") {
				if (!O(i)) return {
					ok: !1,
					message: "contains malformed Unicode."
				};
				t.push(i);
			} else if (n === "number" && typeof i == "number" && Number.isFinite(i)) t.push(i);
			else return {
				ok: !1,
				message: "must be an array of strings or finite numbers of one kind."
			};
		}
		return {
			ok: !0,
			value: Object.freeze(t)
		};
	}
	return {
		ok: !1,
		message: "must be a string, finite number, boolean, null or homogeneous primitive array."
	};
}
function A(e) {
	if (typeof e != "object" || !e || Array.isArray(e)) return !1;
	let t = Object.getPrototypeOf(e);
	return t === Object.prototype || t === null;
}
function j(e) {
	return Object.freeze(e.parameters), e.generator && Object.freeze(e.generator), Object.freeze(e);
}
function M(e) {
	if (!e || typeof e != "object" || Array.isArray(e)) throw TypeError("generator must be an object with string name and version.");
	if (typeof e.name != "string" || typeof e.version != "string") throw TypeError("generator must have string name and version.");
	if (!O(e.name) || !O(e.version)) throw TypeError("generator name and version must be well-formed Unicode strings.");
	return Object.freeze({
		name: e.name,
		version: e.version
	});
}
function N(e) {
	return typeof e == "string" ? `"${e.length > 48 ? `${e.slice(0, 48)}…` : e}"` : e === null ? "null" : Array.isArray(e) ? "an array" : typeof e;
}
function P(e, t) {
	return e.length > t ? e.length : ae.encode(e).byteLength;
}
function oe(e, t) {
	let n;
	try {
		let t = JSON.stringify(e);
		if (typeof t != "string") return null;
		n = t;
	} catch {
		return null;
	}
	return P(n, t);
}
function se(e) {
	if (e === void 0) return x;
	if (typeof e != "object" || !e) throw TypeError("parseLocalState options must be an object.");
	let { maxLength: t } = e;
	if (t === void 0) return x;
	if (typeof t != "number" || !Number.isSafeInteger(t) || t <= 0) throw RangeError("maxLength must be a finite positive integer.");
	return t;
}
function F(e, t, n) {
	if (!e || e.syntax !== "local" || typeof e.source != "string") throw TypeError("createLocalStateFile requires a compiled local document.");
	if (!t || typeof t != "object" || Array.isArray(t)) throw TypeError("createLocalStateFile requires a state object.");
	let r = Object.keys(e.bindings).filter((e) => !e.startsWith("@")).sort(), i = new Set(r), a = /* @__PURE__ */ new Map();
	for (let n of Object.keys(t)) {
		if (Object.hasOwn(e.computations ?? {}, n)) continue;
		if (n.startsWith("@")) {
			if (!Object.hasOwn(e.bindings, n)) throw Error(`Cannot persist parameter "${n}": it is not a binding of this document.`);
			continue;
		}
		if (!i.has(n)) throw Error(`Cannot persist parameter "${n}": it is not a public binding of this document.`);
		let r = k(t[n]);
		if (!r.ok) throw TypeError(`Cannot persist parameter "${n}": the value ${r.message}`);
		a.set(n, r.value);
	}
	let o = {};
	for (let e of r) {
		if (!a.has(e)) throw Error(`Cannot persist the document: parameter "${e}" is missing from the supplied state.`);
		o[e] = a.get(e);
	}
	let s = {
		format: b,
		syntax: u,
		sourceDigest: y(e.source),
		parameters: o
	};
	return n !== void 0 && (s.generator = M(n)), j(s);
}
function ce(e, t) {
	let n = [], r = (e, t) => E(n, e, t), i = e;
	if (typeof e == "string") {
		if (P(e, t) > t) return {
			ok: !1,
			diagnostics: [T("local.state.size", `The state payload exceeds the ${t}-byte limit.`)]
		};
		if (!O(e)) return {
			ok: !1,
			diagnostics: [T("local.state.utf", "The state payload contains malformed Unicode.")]
		};
		try {
			i = JSON.parse(e);
		} catch (e) {
			return {
				ok: !1,
				diagnostics: [T("local.state.json", `The state payload is not valid JSON: ${D(e)}`)]
			};
		}
	} else {
		let n = oe(e, t);
		if (n === null) return {
			ok: !1,
			diagnostics: [T("local.state.shape", "The state payload must be a JSON object.")]
		};
		if (n > t) return {
			ok: !1,
			diagnostics: [T("local.state.size", `The state payload exceeds the ${t}-byte limit.`)]
		};
	}
	if (!A(i)) return {
		ok: !1,
		diagnostics: [T("local.state.shape", "The state payload must be a JSON object.")]
	};
	Object.getOwnPropertySymbols(i).length > 0 && r("local.state.shape", "The state payload cannot use symbol keys.");
	for (let e of Object.keys(i)) C.has(e) || r("local.state.key", `Unknown top-level state key "${e}".`);
	let a = i.format;
	a !== "reactive-md-state/v1" && r("local.state.format", `Unsupported state format ${N(a)}; expected "${b}".`);
	let o = i.syntax;
	o !== "local-draft-3" && r("local.state.syntax", `Unsupported state syntax ${N(o)}; expected "${u}".`);
	let s = i.sourceDigest;
	typeof s == "string" && S.test(s) || r("local.state.digest", "sourceDigest must match \"fnv1a32:\" followed by 8 lowercase hexadecimal digits.");
	let c = {}, l = i.parameters;
	if (!A(l)) r("local.state.parameters", "parameters must be a JSON object of public binding values.");
	else for (let e of Object.keys(l).sort()) {
		if (e === "__proto__") {
			r("local.state.parameter.prototype", "Parameter names cannot be \"__proto__\".");
			continue;
		}
		if (e.startsWith("@")) {
			r("local.state.parameter.internal", `Internal parameter "${e}" cannot be persisted.`);
			continue;
		}
		let t = k(l[e]);
		t.ok ? c[e] = t.value : r("local.state.parameter.value", `Parameter "${e}" ${t.message}`);
	}
	let d;
	if (Object.hasOwn(i, "generator")) {
		let e = i.generator;
		if (!A(e)) r("local.state.generator", "generator must be an object with string name and version.");
		else {
			for (let t of Object.keys(e)) w.has(t) || r("local.state.generator", `generator has unknown key "${t}".`);
			typeof e.name != "string" || typeof e.version != "string" ? r("local.state.generator", "generator must have string name and version.") : !O(e.name) || !O(e.version) ? r("local.state.utf", "generator contains malformed Unicode.") : d = Object.freeze({
				name: e.name,
				version: e.version
			});
		}
	}
	if (n.length) return {
		ok: !1,
		diagnostics: n
	};
	let f = {
		format: b,
		syntax: u,
		sourceDigest: s,
		parameters: c
	};
	return d && (f.generator = d), {
		ok: !0,
		file: j(f)
	};
}
function I(e, t) {
	let n = se(t);
	try {
		return ce(e, n);
	} catch (e) {
		return {
			ok: !1,
			diagnostics: [T("local.state.invalid", `Cannot read the local state: ${D(e)}`)]
		};
	}
}
function le(e) {
	let t = /* @__PURE__ */ new Map(), n = (e) => {
		for (let r of e) t.set(r.id, r), r.children && n(r.children);
	};
	return n(e.nodes), t;
}
function L(e) {
	let t = le(e), n = /* @__PURE__ */ new Map(), r = [];
	for (let [i, a] of Object.entries(e.bindingSlots ?? {})) {
		let e = t.get(i);
		if (!e) continue;
		let o = {
			node: e,
			slots: []
		};
		for (let [t, r] of Object.entries(a)) o.slots.push({
			slot: t,
			key: r
		}), r.startsWith("@") || n.set(r, {
			node: e,
			slot: t
		});
		o.slots.length && r.push(o);
	}
	let i = [];
	for (let [r, a] of Object.entries(e.bindings)) {
		if (r.startsWith("@")) continue;
		let e = n.get(r);
		if (e) {
			i.push({
				key: r,
				binding: a,
				node: e.node,
				slot: e.slot
			});
			continue;
		}
		let o = a.owner && t.has(a.owner) ? a.owner : a.nodeIds.find((e) => t.has(e));
		i.push({
			key: r,
			binding: a,
			node: o ? t.get(o) : void 0
		});
	}
	return {
		plans: i,
		groups: r
	};
}
function R(e, t, n) {
	let r = [];
	for (let i of t.plans) i.slot === void 0 && Object.hasOwn(n, i.key) && (i.node ? Object.is(e.get(i.node), n[i.key]) || r.push(...e.set(i.node, n[i.key])) : r.push(T("local.state.document", `The document has no component for parameter "${i.key}".`)));
	for (let i of t.groups) {
		let t = {}, a = !1;
		for (let { slot: e, key: r } of i.slots) Object.hasOwn(n, r) && (t[e] = n[r], a = !0);
		a && r.push(...e.setMany(i.node, t));
	}
	return r;
}
function ue(e, t) {
	let n = e.snapshot(), r = {};
	for (let e of t) {
		let t = n.state[e];
		r[e] = Array.isArray(t) ? Object.freeze([...t]) : t;
	}
	return Object.freeze(r);
}
function z(e, t, n, r) {
	let i = I(t, r);
	if (!i.ok) return i;
	if (!e || e.syntax !== "local" || typeof e.source != "string" || !Array.isArray(e.nodes) || !e.bindings) return {
		ok: !1,
		diagnostics: [T("local.state.document", "resolveLocalState requires a compiled local document.")]
	};
	if (i.file.syntax !== "local-draft-3") return {
		ok: !1,
		diagnostics: [T("local.state.syntax", `This state file uses syntax "${i.file.syntax}", but this build accepts "${u}".`)]
	};
	if (i.file.sourceDigest !== y(e.source)) return {
		ok: !1,
		diagnostics: [T("local.state.source", "This state file was created for a different document (source digest mismatch).")]
	};
	let a = L(e), o = new Set(a.plans.map((e) => e.key)), s = [];
	for (let e of Object.keys(i.file.parameters)) o.has(e) || E(s, "local.state.parameter.unknown", `The state contains unknown parameter "${e}" for this document.`);
	for (let e of o) Object.hasOwn(i.file.parameters, e) || E(s, "local.state.parameter.missing", `The state is missing parameter "${e}".`);
	if (s.length) return {
		ok: !1,
		diagnostics: s
	};
	let c;
	try {
		c = v(e);
	} catch (e) {
		return {
			ok: !1,
			diagnostics: [T("local.state.document", `Cannot validate this document: ${D(e)}`)]
		};
	}
	try {
		if (n) {
			let e = R(c, a, n);
			if (e.length) return {
				ok: !1,
				diagnostics: e
			};
		}
		let e = R(c, a, i.file.parameters);
		if (e.length) return {
			ok: !1,
			diagnostics: e
		};
		let t = [...o].sort();
		return {
			ok: !0,
			file: i.file,
			state: ue(c, t)
		};
	} finally {
		c.dispose();
	}
}
function B(e, t, n) {
	try {
		return z(e, t, void 0, n);
	} catch (e) {
		return {
			ok: !1,
			diagnostics: [T("local.state.invalid", `Cannot resolve the local state: ${D(e)}`)]
		};
	}
}
function V(e, t, n) {
	let r;
	try {
		r = z(e.document, t, e.snapshot().state, n);
	} catch (e) {
		return [T("local.state.invalid", `Cannot apply the local state: ${D(e)}`)];
	}
	if (!r.ok) return r.diagnostics;
	let i = L(e.document);
	try {
		return R(e, i, r.state);
	} catch (e) {
		return [T("local.state.invalid", `Cannot apply the local state: ${D(e)}`)];
	}
}
function de(e, t) {
	return F(e.document, e.getParameters(), t);
}
function fe(e, t, n) {
	let r = I(t, n);
	return r.ok ? V(e, r.file, n) : r.diagnostics;
}
function pe(e) {
	if (!e || typeof e != "object" || Array.isArray(e)) throw TypeError("serializeLocalState requires a state file.");
	if (!e.parameters || typeof e.parameters != "object" || Array.isArray(e.parameters)) throw TypeError("serializeLocalState requires an object of parameters.");
	let t = Object.create(null);
	for (let n of Object.keys(e.parameters).sort()) {
		if (n === "__proto__" || n.startsWith("@")) throw TypeError(`Cannot serialize parameter "${n}".`);
		let r = k(e.parameters[n]);
		if (!r.ok) throw TypeError(`Cannot serialize parameter "${n}": the value ${r.message}`);
		t[n] = r.value;
	}
	let n = {
		format: e.format,
		syntax: e.syntax,
		sourceDigest: e.sourceDigest,
		parameters: t
	};
	if (e.generator !== void 0) {
		let t = M(e.generator);
		n.generator = {
			name: t.name,
			version: t.version
		};
	}
	return JSON.stringify(n);
}
// src/local/configuration/portable-options.ts
function H(e) {
	if (e === void 0) return;
	let t = _(e);
	if (!t.ok) throw TypeError(`Invalid portable compile options: ${t.message}`);
	return {
		enableCss: t.html.enableCss,
		enableJavaScript: t.html.enableJavaScript,
		enableExtendedHtml: t.html.enableExtendedHtml,
		...Object.hasOwn(e, "strict") && e.strict !== void 0 ? { strict: t.strict } : {},
		...e.markdownBreaks === void 0 ? {} : { markdownBreaks: t.markdownBreaks },
		...e.config === void 0 ? t.hostComponents.length ? { hostComponents: t.hostComponents } : {} : { config: g(e.config) },
		...e.limits === void 0 ? {} : { limits: {
			...e.limits.maxSyntaxNodes === void 0 ? {} : { maxSyntaxNodes: t.maxSyntaxNodes },
			...e.limits.maxParseWork === void 0 ? {} : { maxParseWork: t.maxParseWork },
			...e.limits.maxMarkdownDepth === void 0 ? {} : { maxMarkdownDepth: t.maxMarkdownDepth }
		} }
	};
}
// src/export/restoration.ts
var me = i;
function U(e) {
	return i(JSON.stringify([
		e.id,
		e.name,
		e.version,
		e.protocol,
		e.colorSchemes,
		e.css.map(({ id: e, css: t }) => [e, t])
	]));
}
function he(e, t) {
	let n = g(t), r = c(n);
	return Object.freeze({
		protocol: "reactive-md-bundle/v1",
		sdkVersion: o,
		configKey: n.key,
		scriptDigest: i(e),
		assembly: r,
		seal: l(n),
		themes: Object.freeze(n.themes.map((e) => Object.freeze({
			id: e.id,
			name: e.name,
			version: e.version,
			digest: U(e)
		})))
	});
}
function W(t, n, r, a = []) {
	let s = g(n), l = /* @__PURE__ */ new Set(), u = [...t.nodes];
	for (; u.length;) {
		let e = u.pop();
		(e.type === "component" || e.type === "hostComponent") && e.name && l.add(e.name), e.children && u.push(...e.children);
	}
	let d = s.registry.filter((e) => l.has(e.name)).map((t) => Object.freeze({
		id: t.id,
		name: t.name,
		version: t.version,
		range: t.version,
		digest: e(t)
	})).sort((e, t) => e.id.localeCompare(t.id)), f = s.themes.filter((e) => e.name === t.theme).map((e) => Object.freeze({
		id: e.id,
		name: e.name,
		version: e.version,
		digest: U(e)
	}));
	return Object.freeze({
		protocol: "reactive-md-restore/v1",
		sdk: `^${o}`,
		configKey: s.key,
		sourceDigest: i(t.source),
		target: r,
		components: Object.freeze(d),
		themes: Object.freeze(f),
		assembly: c(s),
		resources: Object.freeze(a.map((e) => Object.freeze({
			id: e.id,
			digest: i(e.css)
		})))
	});
}
function G(e) {
	return typeof e == "object" && !!e && !Array.isArray(e) && [Object.prototype, null].includes(Object.getPrototypeOf(e));
}
function K(e) {
	return typeof e == "string" && e.length > 0 && e.length <= 256;
}
function q(a, c) {
	if (a === void 0) return [];
	let l = [], u = (e, t) => l.push({
		code: `local.extension.restore-${e}`,
		message: t,
		severity: "error",
		range: {
			start: 0,
			end: 0
		},
		line: 1,
		column: 1
	});
	try {
		if (!G(a) || r(a) > 262144 || a.protocol !== "reactive-md-restore/v1" || !K(a.sdk) || !K(a.configKey) || !K(a.sourceDigest) || ![
			"static",
			"ssr",
			"offline"
		].includes(a.target) || !Array.isArray(a.components) || a.components.length > 192 || !Array.isArray(a.themes) || a.themes.length > 16 || !Array.isArray(a.resources) || a.resources.length > 128) return u("metadata", "Invalid or oversized restoration requirements."), l;
		let d = /* @__PURE__ */ new Set([
			"protocol",
			"sdk",
			"configKey",
			"sourceDigest",
			"target",
			"components",
			"themes",
			"resources",
			"assembly"
		]);
		Object.keys(a).some((e) => !d.has(e)) && u("metadata", "Unknown restoration requirement field.");
		let f = c.config === void 0 ? ee() : g(c.config);
		t(a.sdk) && n("0.7.0", a.sdk) || u("sdk", `SDK ${o} does not satisfy ${a.sdk}.`), s(f, a.configKey) || u("config", "The installed configuration differs from the exported configuration."), a.assembly !== void 0 && (G(a.assembly) && a.assembly.protocol === "reactive-md-assembly-seal/v1" && K(a.assembly.configKey) && s(f, a.assembly.configKey) || u("assembly", "The exported assembly identity is invalid or belongs to another configuration.")), i(c.source) !== a.sourceDigest && u("source", "The source differs from the exported source. Recompile before restoring state.");
		let p = /* @__PURE__ */ new Set();
		for (let r of a.components) {
			if (!G(r) || ![
				"id",
				"name",
				"version",
				"range",
				"digest"
			].every((e) => K(r[e])) || !t(r.range) || p.has(r.id)) {
				u("metadata", "Invalid or duplicate component restoration requirement.");
				continue;
			}
			p.add(r.id);
			let i = f.registry.find((e) => e.id === r.id);
			if (!i) {
				u("component-missing", `Required component ${r.id}@${r.version} is not installed.`);
				continue;
			}
			n(i.version, r.range) || u("version", `Component ${r.id}@${i.version} does not satisfy ${r.range}.`), (i.version !== r.version || i.name !== r.name || e(i) !== r.digest) && u("contract", `Component ${r.id}@${r.version} differs from the installed contract. Recompile and validate state before upgrading.`);
			let o = a.target === "offline" ? [
				"interactive",
				"static",
				"offline"
			] : [a.target];
			for (let e of o) i.capabilities[e] || u("capability", `Component ${r.id} cannot render ${e}.`);
		}
		if (c.document) {
			let e = W(c.document, f, a.target);
			for (let t of e.components) p.has(t.id) || u("component-missing", `Used component ${t.id} is missing from restoration requirements.`);
		}
		p.clear();
		for (let e of a.themes) {
			if (!G(e) || ![
				"id",
				"name",
				"version",
				"digest"
			].every((t) => K(e[t])) || p.has(e.id)) {
				u("metadata", "Invalid or duplicate theme restoration requirement.");
				continue;
			}
			p.add(e.id);
			let t = f.themes.find((t) => t.id === e.id);
			t && t.name === e.name && t.version === e.version && U(t) === e.digest || u("theme", `Required theme ${e.id}@${e.version} does not match the installed theme.`);
		}
		if (c.document) {
			let e = f.themes.find((e) => e.name === c.document.theme);
			e && !p.has(e.id) && u("theme", `Selected theme ${e.id} is missing from restoration requirements.`);
		}
		let m = ie(c.resources ?? []);
		l.push(...m.diagnostics);
		let h = new Map(m.resources.map((e) => [e.id, e.css]));
		p.clear();
		for (let e of a.resources) {
			if (!G(e) || !K(e.id) || !K(e.digest) || p.has(e.id)) {
				u("metadata", "Invalid or duplicate style restoration requirement.");
				continue;
			}
			p.add(e.id);
			let t = h.get(e.id);
			t === void 0 ? u("resource-missing", `Required style resource ${e.id} is missing before state restoration.`) : i(t) !== e.digest && u("resource-digest", `Style resource ${e.id} differs from the exported content.`);
		}
		if (c.document) {
			let e = W(c.document, f, a.target), t = new Set(e.components.map((e) => e.id)), n = f.registry.filter((e) => t.has(e.id)).flatMap((e) => e.styles ?? []);
			n.push(...f.themes.filter((e) => e.name === c.document.theme).flatMap((e) => e.css.map((e) => e.id)));
			for (let e of n) p.has(e) && h.has(e) || u("resource-missing", `Used style resource ${e} is required before state restoration.`);
		}
	} catch (e) {
		u("metadata", e instanceof Error ? e.message : String(e));
	}
	return l;
}
// src/shareable.ts
var J = "reactive-md-html/v1", Y = "reactive-md-html/v2", ge = /^[A-Za-z][A-Za-z0-9_-]*$/, _e = /^[A-Za-z]{2,8}(?:-[A-Za-z0-9]{1,8})*$/, ve = /^data:image\/(?:png|jpeg|gif|webp);base64,[A-Za-z0-9+/]+={0,2}$/, ye = /[\u0000-\u001f\u007f-\u009f]/, X = 64, be = 41943040, xe = 4096;
function Z(e, t = !1) {
	let n = e.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
	return t && (n = n.replace(/"/g, "&quot;").replace(/'/g, "&#39;")), n;
}
function Se(e) {
	return e.replace(/<\/style/gi, "<\\/style");
}
function Ce(e) {
	return e.replace(/<\/script/gi, "<\\/script").replace(/<!--/g, "<\\!--");
}
function Q(e) {
	return Z(e, !0);
}
function $(e) {
	let t = JSON.stringify(e);
	if (typeof t != "string") throw TypeError("Cannot serialize a non-JSON value for an inline script.");
	return t.replace(/[<>&\u2028\u2029]/g, (e) => {
		switch (e) {
			case "<": return "\\u003c";
			case ">": return "\\u003e";
			case "&": return "\\u0026";
			case "\u2028": return "\\u2028";
			default: return "\\u2029";
		}
	});
}
function we(e) {
	return Array.isArray(e) ? e.slice() : e;
}
function Te(e) {
	try {
		return H(e);
	} catch (e) {
		throw TypeError(`createShareableHtml received invalid compileOptions: ${e instanceof Error ? e.message : String(e)}`);
	}
}
function Ee(e) {
	let t = [];
	for (let n of e.childNodes) {
		if (p.isElementNode(n)) {
			let e = n.tagName.toLowerCase();
			if (e === "script") continue;
			Ee(e === "template" ? p.getTemplateContent(n) : n);
		}
		t.push(n);
	}
	e.childNodes = t;
}
function De(e, t, n) {
	let r = !1;
	for (let i of e.childNodes) if (p.isElementNode(i)) {
		if (i.tagName.toLowerCase() === "iframe") {
			let e = i.attrs.filter((e) => {
				let t = e.name.toLowerCase();
				return t !== "srcdoc" && t !== "sandbox";
			});
			e.push({
				name: "srcdoc",
				value: t
			}), e.push({
				name: "sandbox",
				value: n
			}), i.attrs = e, r = !0;
		}
		De(i, t, n) && (r = !0);
	}
	return r;
}
function Oe(e) {
	let t = "";
	for (let n of e.childNodes) t += f(n, { scriptingEnabled: !1 });
	return t;
}
function ke(e, t, n) {
	try {
		let r = h(e, { scriptingEnabled: !1 });
		if (Ee(r), De(r, t, n)) return Oe(r);
	} catch {}
	return `<div class="reactive-md-native-document"><iframe class="reactive-md-native-frame" title="Reactive MD document" sandbox="${Z(n, !0)}" style="display:block;width:100%;min-height:60vh;border:0;background:#fff" srcdoc="${Z(t, !0)}"></iframe></div>`;
}
function Ae(e, t) {
	let n = t?.enableExtendedHtml === !0, r = t ? `frame-src about:${n ? " data: blob: http: https:" : ""}` : "frame-src 'none'", i = n ? "base-uri 'self' http: https:" : "base-uri 'none'", a = n ? "form-action http: https:" : "form-action 'none'";
	return e ? `default-src 'none'; img-src data:; style-src 'unsafe-inline'; script-src 'unsafe-inline'; font-src data:; connect-src 'none'; media-src 'none'; object-src 'none'; ${r}; ${i}; ${a}` : `default-src 'none'; img-src data:; style-src 'unsafe-inline'; font-src data:; object-src 'none'; ${r}; ${i}; ${a}`;
}
function je(e) {
	if (e === void 0) return;
	if (!e || typeof e != "object" || Array.isArray(e)) throw TypeError("images must be an object mapping relative URLs to data: image URLs.");
	let t = Object.entries(e);
	if (t.length > X) throw RangeError(`images cannot contain more than ${X} entries.`);
	let n = 0;
	for (let [e, r] of t) {
		if (!e || e.length > xe || ye.test(e) || e === "__proto__") throw TypeError("Every image key must be a bounded, control-free URL.");
		if (typeof r != "string" || !ve.test(r)) throw TypeError(`The image map for "${e}" must contain a base64 PNG, JPEG, GIF or WebP data URL.`);
		if (n += r.length, n > be) throw RangeError("The embedded image map exceeds the 40 MiB budget.");
	}
	return Object.fromEntries(t);
}
function Me(e, t) {
	let n = B(e, t);
	if (!n.ok) return n;
	let r = {};
	for (let [t, i] of Object.entries(e.bindings)) r[t] = Object.hasOwn(n.state, t) ? {
		...i,
		initial: we(n.state[t])
	} : i;
	let i = { ...e.initialState };
	for (let [e, t] of Object.entries(n.state)) i[e] = we(t);
	return {
		ok: !0,
		baseline: {
			document: {
				...e,
				bindings: r,
				initialState: i
			},
			state: n.state
		}
	};
}
var Ne = "\n:root { color-scheme: light; background: #f5f7fb; }\nhtml, body { margin: 0; }\nbody.reactive-md-export {\n  min-height: 100vh;\n  padding: clamp(16px, 4vw, 48px);\n  background: #f5f7fb;\n  color: #17233d;\n  font-family: system-ui, -apple-system, \"Segoe UI\", sans-serif;\n}\n.reactive-md-export-root { max-width: 840px; margin: 0 auto; }\n@media print {\n  :root, html, body.reactive-md-export { background: #fff !important; }\n  body.reactive-md-export { min-height: 0; padding: 0 !important; }\n  .reactive-md-export-root { max-width: none !important; margin: 0 !important; }\n}\n";
function Pe(e) {
	let t = e.targetId ?? "reactive-md-document";
	if (!ge.test(t)) throw TypeError("targetId must start with a letter and contain only letters, digits, underscores or hyphens.");
	let n = e.mode === "static" ? "static" : "interactive";
	if (!e.staticMarkup.trim()) throw TypeError("createShareableHtml requires rendered document markup.");
	if (!e.css.trim()) throw TypeError("createShareableHtml requires the document stylesheet.");
	if (e.state.sourceDigest !== y(e.source)) throw Error("The state file does not belong to the exported source.");
	if (n === "interactive" && !e.runtimeScript?.trim()) throw TypeError("Interactive HTML requires the standalone runtime script.");
	let r = Te(e.compileOptions), i = re(e.extensions, r?.config);
	if (i.push(...q(e.restoration, {
		config: r?.config,
		source: e.source,
		resources: e.resources
	})), i.length) throw TypeError(i.map((e) => e.message).join(" "));
	let a = _(r);
	if (!a.ok) throw TypeError(`createShareableHtml received invalid compileOptions: ${a.message}`);
	let o = a.htmlActive, s = e.documentId === void 0 ? void 0 : ne(e.documentId);
	if (e.documentId !== void 0 && s === void 0) throw TypeError("createShareableHtml received an invalid documentId.");
	let c;
	if (e.randomSeed !== void 0) {
		if (!Number.isInteger(e.randomSeed) || e.randomSeed < 0 || e.randomSeed > 4294967295) throw TypeError("createShareableHtml received an invalid randomSeed; expected a 32-bit unsigned integer.");
		c = e.randomSeed;
	}
	let l;
	if (e.componentState !== void 0) {
		let t = te(e.componentState);
		if (!t.ok || t.diagnostics.length > 0) {
			let e = t.diagnostics.map((e) => e.message).join(" ");
			throw TypeError(`createShareableHtml received an invalid component state${e ? `: ${e}` : "."}`);
		}
		l = t.document;
	}
	let u = e.staticMarkup;
	if (o && (n === "static" || !a.html.enableJavaScript)) {
		let t = {
			enableCss: a.html.enableCss,
			enableJavaScript: !1,
			enableExtendedHtml: a.html.enableExtendedHtml
		}, n = m(e.source, t, a.maxSyntaxNodes);
		if (!n.markup) throw Error("The native HTML document could not be regenerated without author JavaScript.");
		u = ke(e.staticMarkup, n.markup, d(t));
	}
	let f = e.locale === "zh" ? "zh" : "en", p = f === "zh" ? "zh-CN" : "en", h = e.colorScheme === "light" || e.colorScheme === "dark" ? e.colorScheme : "auto", ee = e.assets === "omit" ? "omit" : "inline", g = e.generator ?? {
		name: "reactive-md",
		version: "unknown"
	}, v = je(e.images), ie = Number.isSafeInteger(e.imageCount) && (e.imageCount ?? 0) > 0 ? String(e.imageCount) : String(Object.keys(v ?? {}).length), b = n === "interactive", x = {
		version: e.restoration ? 2 : 1,
		target: t,
		source: e.source,
		state: e.state,
		locale: f,
		colorScheme: h,
		hydrate: !0,
		...r === void 0 ? {} : { compileOptions: r },
		...e.extensions === void 0 ? {} : { extensions: e.extensions },
		...e.restoration === void 0 ? {} : {
			restoration: e.restoration,
			resources: e.resources ?? []
		},
		...v ? { images: v } : {},
		...s === void 0 ? {} : { documentId: s },
		...c === void 0 ? {} : { randomSeed: c },
		...l === void 0 ? {} : { componentState: l }
	}, S = Ae(b, o ? a.html : void 0), C = b ? `<script type="application/reactive-md+json" data-reactive-md-auto>${$(x)}<\/script>
<script>${Ce(e.runtimeScript)}<\/script>` : "", w = e.notices?.trim() ? `<template id="reactive-md-notices"><pre>${Z(e.notices)}</pre></template>` : "", ae = !b && e.extensions ? `<template id="reactive-md-extensions">${Z(JSON.stringify(e.extensions))}</template>` : "";
	return `<!doctype html>
<html lang="${Z(_e.test(p) ? p : "en", !0)}">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="referrer" content="no-referrer">
<meta http-equiv="Content-Security-Policy" content="${Q(S)}">
<meta name="generator" content="${Q(`${g.name} ${g.version}`)}">
<meta name="reactive-md-html-format" content="${e.restoration ? Y : J}">
<meta name="reactive-md-syntax" content="${Q(e.state.syntax)}">
<meta name="reactive-md-output" content="${n}">
<meta name="reactive-md-state" content="${Q(e.state.sourceDigest)}">
<meta name="reactive-md-images" content="${ee}">
<meta name="reactive-md-image-count" content="${ie}">
<title>${Z(e.title || "Reactive MD document")}</title>
<style>${Se(e.css)}${Ne}</style>
</head>
<body class="reactive-md-export">
<div id="${t}" class="reactive-md-export-root">${u}</div>
${C}
${ae}
${w}
</body>
</html>
`;
}
export { I as _, $ as a, me as c, H as d, b as f, fe as g, de as h, Me as i, U as l, F as m, Y as n, he as o, V as p, Pe as r, W as s, J as t, q as u, B as v, pe as y };
