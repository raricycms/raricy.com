import { F as e, M as t, P as n, a as r, i, j as a, k as o, q as s } from "./identity-MYJXKSkB.js";
import { $ as c, S as l, _ as u, a as d, c as f, d as ee, g as p, h as te, i as m, m as ne, n as h, nt as g, o as re, p as ie, r as _, s as ae, t as oe, v as se, y as ce } from "./config-validation-DXTynAw7.js";
import { t as le } from "./default-components-CmcEmEkA.js";
import v from "./reactive-md-default-preset.js";
// src/local/theme/theme.ts
var y = "reactive-md-theme-1", b = Object.freeze({
	name: "default",
	protocol: y,
	colorSchemes: Object.freeze(["light", "dark"])
});
function ue(e, t) {
	let n = typeof t == "string" ? t.length : Infinity;
	if (!e || typeof e.start != "number" || typeof e.end != "number" || !Number.isFinite(e.start) || !Number.isFinite(e.end)) return {
		start: 0,
		end: 0
	};
	let r = Math.max(0, Math.min(n, Math.floor(e.start)));
	return {
		start: r,
		end: Math.max(r, Math.min(n, Math.floor(e.end)))
	};
}
function de(e, t) {
	if (typeof e != "string" || e.length === 0) return {
		line: 1,
		column: 1
	};
	let n = Math.min(t, e.length), r = 1, i = 0;
	for (let t = 0; t < n; t += 1) e[t] === "\n" && (r += 1, i = t + 1);
	return {
		line: r,
		column: t - i + 1
	};
}
function fe(e, t, n, r) {
	let i = ue(n, r), { line: a, column: o } = de(r, i.start);
	return {
		code: e,
		message: c(t),
		severity: "warning",
		range: i,
		line: a,
		column: o,
		messageKey: t.key,
		...t.params ? { params: t.params } : {}
	};
}
function pe(e, t, n, r) {
	let i = (e, t) => ({
		name: b.name,
		diagnostics: [fe(e, t, n, r)]
	}), a = e;
	if (a == null || a === "") return {
		name: b.name,
		diagnostics: []
	};
	if (!l(a)) return i("local.theme.name", g("local.theme.name", {
		name: String(a),
		limit: 64
	}));
	let o = a;
	if (o === b.name) return {
		name: b.name,
		diagnostics: []
	};
	if (!Array.isArray(t)) return i("local.theme.missing", g("local.theme.missing", { name: o }));
	let s = 0, c = null;
	try {
		for (let e of t) typeof e == "object" && e && !Array.isArray(e) && e.name === o && (s += 1, c = e);
	} catch {
		return i("local.theme.manifest", g("local.theme.manifest.unreadable"));
	}
	if (s === 0) return i("local.theme.missing", g("local.theme.missing", { name: o }));
	if (s > 1) return i("local.theme.duplicate", g("local.theme.duplicate", { name: o }));
	try {
		let e = c;
		if (!e || typeof e != "object") return i("local.theme.manifest", g("local.theme.manifest.definition", { name: o }));
		if (e.protocol !== "reactive-md-theme-1") return i("local.theme.protocol", g("local.theme.protocol", {
			name: o,
			protocol: y
		}));
		let t = e.colorSchemes;
		if (!Array.isArray(t) || !t.includes("light") || !t.includes("dark")) return i("local.theme.modes", g("local.theme.modes", { name: o }));
	} catch {
		return i("local.theme.manifest", g("local.theme.manifest.selected", { name: o }));
	}
	return {
		name: o,
		diagnostics: []
	};
}
// src/sdk/theme.ts
var me = 128, he = 32, ge = 128, _e = 262144, x = 524288, ve = /^[a-z][a-z0-9]*(?:[-./][a-z0-9]+)*$/, ye = /^[a-z][a-z0-9._/-]*$/, be = /^\d+\.\d+\.\d+(?:[-+][0-9A-Za-z.-]+)?$/, xe = /^\[\s*data-rmd-theme\s*=\s*(?:"[^"]*"|'[^']*'|[^\]]*?)\s*\]/, Se = /^(?::root|html|body)(?![A-Za-z0-9_-])/i, Ce = /* @__PURE__ */ new Set([
	"media",
	"supports",
	"layer",
	"container",
	"scope",
	"starting-style"
]), we = 256, Te = /* @__PURE__ */ new Set([
	"serif",
	"sans-serif",
	"monospace",
	"cursive",
	"fantasy",
	"system-ui",
	"ui-serif",
	"ui-sans-serif",
	"ui-monospace",
	"ui-rounded",
	"math",
	"emoji",
	"fangsong",
	"-apple-system",
	"blinkmacsystemfont"
]), S = /* @__PURE__ */ new Set([
	"inherit",
	"initial",
	"unset",
	"revert",
	"revert-layer"
]), Ee = /* @__PURE__ */ new Set([
	"caption",
	"icon",
	"menu",
	"message-box",
	"small-caption",
	"status-bar"
]), De = /* @__PURE__ */ new Set([
	"xx-small",
	"x-small",
	"small",
	"medium",
	"large",
	"x-large",
	"xx-large",
	"xxx-large",
	"smaller",
	"larger"
]), Oe = /^rmd-theme-([a-z][a-z0-9-]*)-font-([0-9a-f]+)$/;
function C(e, t) {
	return /* @__PURE__ */ Error(`Invalid local theme ${e}: ${t}`);
}
function ke(e) {
	return typeof e == "object" && !!e && !Array.isArray(e);
}
function w(e, t) {
	if (!ke(e)) throw C(t, "must be an object.");
	return e;
}
function T(e, t) {
	if (typeof e != "string" || e.length === 0) throw C(t, "must be a non-empty string.");
	if (e.length > me) throw C(t, `must not exceed ${me} characters.`);
	if (!ve.test(e)) throw C(t, `"${e}" must be lowercase, start with a letter and use "-", "." or "/" only as separators.`);
	return e;
}
function E(e, t) {
	if (!l(e)) throw C(t, "must be a lowercase kebab-case name that starts with a letter.");
	if (e === "default") throw C(t, "must not replace the reserved built-in \"default\" theme.");
	return e;
}
function D(e, t) {
	if (typeof e != "string" || !be.test(e)) throw C(t, "must be a semantic version such as \"1.0.0\".");
	return e;
}
function Ae(e, t) {
	if (e === void 0) return Object.freeze(["light", "dark"]);
	if (!Array.isArray(e)) throw C(t, "must be an array of \"light\" and \"dark\".");
	let n = [];
	for (let r of e) {
		if (r !== "light" && r !== "dark") throw C(t, "may only contain \"light\" and \"dark\".");
		if (n.includes(r)) throw C(t, `must not repeat "${r}".`);
		n.push(r);
	}
	if (!n.includes("light") || !n.includes("dark")) throw C(t, "must declare both \"light\" and \"dark\".");
	return Object.freeze(n);
}
function O(e, t) {
	let n = e[t], r = t + 1;
	for (; r < e.length;) if (e[r] === "\\") r += 2;
	else {
		if (e[r] === n) return r + 1;
		r += 1;
	}
	return e.length;
}
function k(e, t, n, r) {
	let i = 0;
	for (let a = t; a < e.length; a += 1) {
		let t = e[a];
		if (t === "\"" || t === "'") a = O(e, a) - 1;
		else if (t === "/" && e[a + 1] === "*") {
			let t = e.indexOf("*/", a + 2);
			a = (t < 0 ? e.length : t + 2) - 1;
		} else if (t === n) i += 1;
		else if (t === r && (--i, i === 0)) return a + 1;
	}
	return e.length;
}
function je(e, t, n) {
	let r = t + 3;
	for (; r < e.length && /\s/.test(e[r]);) r += 1;
	if (e[r] !== "(") throw C(n, "has a malformed url() value.");
	for (r += 1; r < e.length && /\s/.test(e[r]);) r += 1;
	let i = e[r];
	if (i === "\"" || i === "'") {
		let t = e.indexOf(i, r + 1);
		if (t < 0) throw C(n, "has an unterminated url() string.");
		let a = e.slice(r + 1, t);
		for (r = t + 1; r < e.length && /\s/.test(e[r]);) r += 1;
		if (e[r] !== ")") throw C(n, "has a malformed url() value.");
		return {
			value: a.trim(),
			end: r + 1
		};
	}
	let a = e.indexOf(")", r);
	if (a < 0) throw C(n, "has an unterminated url() value.");
	return {
		value: e.slice(r, a).trim(),
		end: a + 1
	};
}
function Me(e, t, n, r) {
	let i = t;
	for (; i < e.length && e[i] !== "(";) i += 1;
	if (i >= e.length) throw C(r, `has a malformed ${n}() value.`);
	let a = k(e, i, "(", ")");
	if (a <= i + 1 || e[a - 1] !== ")") throw C(r, `has an unterminated ${n}() value.`);
	return {
		body: e.slice(i + 1, a - 1),
		end: a
	};
}
function Ne(e, t) {
	let n = 0;
	for (; n < e.length;) {
		let r = e[n];
		if (r === "\"" || r === "'") {
			let i = O(e, n);
			if (i > e.length || e[i - 1] !== r) throw C(t, "has an unterminated image-set() string.");
			let a = e.slice(n + 1, i - 1).trim();
			if (!/^data:/i.test(a)) throw C(t, "image-set() entries must be inline data: URLs; network and file URLs are not allowed.");
			n = i;
		} else if (r === "/" && e[n + 1] === "*") {
			let t = e.indexOf("*/", n + 2);
			n = t < 0 ? e.length : t + 2;
		} else n += 1;
	}
}
function Pe(e, t, n = !1) {
	if (e.toLowerCase().includes("</style")) throw C(t, "must not contain a closing style tag.");
	let r = 0;
	for (; r < e.length;) {
		let i = e[r];
		if (i === "\"" || i === "'") r = O(e, r);
		else if (i === "/" && e[r + 1] === "*") {
			let t = e.indexOf("*/", r + 2);
			r = t < 0 ? e.length : t + 2;
		} else {
			if (i === "\\") throw C(t, "must not use CSS escapes outside strings; escaped tokens can disguise url() or @import.");
			if (i === "@" && /^@import\b/i.test(e.slice(r, r + 8))) throw C(t, "must not use @import; inline every resource.");
			if ((i === "i" || i === "I" || i === "-") && /^(?:-webkit-)?image-set\s*\(/i.test(e.slice(r, r + 24))) {
				let { body: n } = Me(e, r, "image-set", t);
				Ne(n, t), r += 1;
			} else if ((i === "u" || i === "U") && /^url\s*\(/i.test(e.slice(r, r + 12))) {
				let i = je(e, r, t);
				if (!/^data:/i.test(i.value) && !(n && i.value.startsWith("#"))) throw C(t, "may only reference data: URLs; network and file URLs are not allowed.");
				r = i.end;
			} else {
				if ((i === "e" || i === "E") && /^expression\s*\(/i.test(e.slice(r, r + 16))) throw C(t, "must not use CSS expression().");
				r += 1;
			}
		}
	}
}
function Fe(e) {
	if (typeof e != "string" || e.length > 4194304) return !1;
	try {
		return Pe(e, "css", !0), !0;
	} catch {
		return !1;
	}
}
function Ie(e) {
	let t = [], n = 0, r = 0, i = 0;
	for (let a = 0; a < e.length; a += 1) {
		let o = e[a];
		if (o === "\"" || o === "'") a = O(e, a) - 1;
		else if (o === "/" && e[a + 1] === "*") {
			let t = e.indexOf("*/", a + 2);
			a = (t < 0 ? e.length : t + 2) - 1;
		} else o === "\\" ? a += 1 : o === "(" ? r += 1 : o === ")" ? r = Math.max(0, r - 1) : o === "[" ? i += 1 : o === "]" ? i = Math.max(0, i - 1) : o === "," && r === 0 && i === 0 && (t.push(e.slice(n, a)), n = a + 1);
	}
	return t.push(e.slice(n)), t;
}
function Le(e, t) {
	let n = e.trim(), r = `[data-rmd-theme="${t}"]`, i = xe.exec(n);
	return i ? `${r}${n.slice(i[0].length)}` : `${r} ${n}`;
}
function A(e, t) {
	let n = t;
	for (; n < e.length;) if (/\s/.test(e[n])) n += 1;
	else if (e[n] === "/" && e[n + 1] === "*") {
		let t = e.indexOf("*/", n + 2);
		n = t < 0 ? e.length : t + 2;
	} else break;
	return n;
}
function Re(e, t) {
	let n = e.toLowerCase(), r = /:has\s*\(/g;
	for (let i = r.exec(n); i; i = r.exec(n)) {
		if (r.lastIndex = i.index + 1, i.index >= t) continue;
		let n = i.index + i[0].length - 1, a = k(e, n, "(", ")"), o = e.slice(n + 1, Math.max(n + 1, a - 1));
		for (let t of Ie(o)) if (/^\s*[+~]/.test(t)) throw C("theme.css", `selector "${e.trim()}" uses :has() with a sibling combinator that can escape the theme root.`);
	}
}
function ze(e) {
	let t = e.trim();
	if (t === "") return;
	if (t[0] === "+" || t[0] === "~") throw C("theme.css", `selector "${t}" begins with a sibling combinator and cannot be scoped.`);
	let n = xe.exec(t);
	if (n) {
		let e = n[0].length;
		for (; e < t.length;) {
			let n = t[e];
			if (/\s/.test(n) || n === "+" || n === "~" || n === ">" || n === ",") break;
			n === "[" ? e = k(t, e, "[", "]") : n === "(" ? e = k(t, e, "(", ")") : e += 1;
		}
		let r = A(t, e);
		if (t[r] === "+" || t[r] === "~") throw C("theme.css", `selector "${t}" uses a sibling combinator that can escape the theme root.`);
		Re(t, e);
	}
}
function Be(e, t) {
	let n = Ie(e).map((e) => e.trim()).filter(Boolean);
	if (n.length === 0) return e.trim();
	for (let e of n) {
		if (Se.test(e)) throw C("theme.css", `selector "${e}" targets the host document; scope it under the theme root instead.`);
		ze(e);
	}
	return n.map((e) => Le(e, t)).join(", ");
}
function j(e, t) {
	let n = 1;
	for (let r = t; r < e.length; r += 1) {
		let t = e[r];
		if (t === "\"" || t === "'") r = O(e, r) - 1;
		else if (t === "/" && e[r + 1] === "*") {
			let t = e.indexOf("*/", r + 2);
			r = (t < 0 ? e.length : t + 2) - 1;
		} else if (t === "{") n += 1;
		else if (t === "}" && (--n, n === 0)) return r;
	}
	return e.length;
}
function M(e) {
	return e.trim().replace(/\s+/g, " ").toLowerCase();
}
function Ve(e) {
	let t = [];
	for (let n of e) {
		let e = n.codePointAt(0);
		e <= 127 ? t.push(e) : e <= 2047 ? t.push(192 | e >> 6, 128 | e & 63) : e <= 65535 ? t.push(224 | e >> 12, 128 | e >> 6 & 63, 128 | e & 63) : t.push(240 | e >> 18, 128 | e >> 12 & 63, 128 | e >> 6 & 63, 128 | e & 63);
	}
	return t;
}
function He(e) {
	let t = "", n = 0;
	for (; n < e.length;) {
		let r = e[n], i, a;
		if (r <= 127) i = r, a = 1;
		else if (r >= 194 && r <= 223) i = r & 31, a = 2;
		else if (r >= 224 && r <= 239) i = r & 15, a = 3;
		else if (r >= 240 && r <= 244) i = r & 7, a = 4;
		else return null;
		if (n + a > e.length) return null;
		for (let t = 1; t < a; t += 1) {
			let r = e[n + t];
			if ((r & 192) != 128) return null;
			i = i << 6 | r & 63;
		}
		if (a === 3 && (i < 2048 || i >= 55296 && i <= 57343) || a === 4 && (i < 65536 || i > 1114111)) return null;
		t += String.fromCodePoint(i), n += a;
	}
	return t;
}
function Ue(e, t) {
	return `rmd-theme-${e}-font-${Ve(t).map((e) => e.toString(16).padStart(2, "0")).join("")}`;
}
function We(e) {
	let t = Oe.exec(e);
	if (!t || t[2].length % 2 != 0) return null;
	let n = [];
	for (let e = 0; e < t[2].length; e += 2) n.push(Number.parseInt(t[2].slice(e, e + 2), 16));
	let r = He(n);
	return r === null || r.length === 0 || M(r) !== r ? null : {
		themeName: t[1],
		original: r
	};
}
function N(e) {
	return e === void 0 ? !1 : /[A-Za-z0-9_-]/.test(e) || e.codePointAt(0) >= 128;
}
function Ge(e, t) {
	let n = e[t];
	if (n === void 0) return !1;
	if (/[A-Za-z_]/.test(n) || n.codePointAt(0) >= 128) return !0;
	if (n === "-") {
		let n = e[t + 1];
		return n !== void 0 && (N(n) || n === "-");
	}
	return !1;
}
function Ke(e, t) {
	let n = e[t];
	if (n === void 0) return !1;
	if (n >= "0" && n <= "9") return !0;
	let r = e[t + 1];
	return n === "+" || n === "-" ? r !== void 0 && (r >= "0" && r <= "9" || r === ".") : n === "." && r !== void 0 && r >= "0" && r <= "9";
}
function P(e) {
	let t = [], n = 0;
	for (; n < e.length;) {
		let r = e[n];
		if (/\s/.test(r)) {
			n += 1;
			continue;
		}
		if (r === "/" && e[n + 1] === "*") {
			let t = e.indexOf("*/", n + 2);
			n = t < 0 ? e.length : t + 2;
			continue;
		}
		let i = n;
		if (r === "\"" || r === "'") {
			let r = O(e, n);
			t.push({
				type: "string",
				text: e.slice(i, r),
				start: i,
				end: r,
				name: "",
				stringValue: e.slice(i + 1, Math.max(i + 1, r - 1))
			}), n = r;
		} else if (r === ",") t.push({
			type: "comma",
			text: ",",
			start: i,
			end: n + 1,
			name: "",
			stringValue: ""
		}), n += 1;
		else if (Ke(e, n)) {
			let r = n;
			for ((e[r] === "+" || e[r] === "-") && (r += 1); e[r] >= "0" && e[r] <= "9";) r += 1;
			if (e[r] === ".") for (r += 1; e[r] >= "0" && e[r] <= "9";) r += 1;
			if (e[r] === "e" || e[r] === "E") {
				let t = r;
				r += 1, (e[r] === "+" || e[r] === "-") && (r += 1);
				let n = r;
				for (; e[r] >= "0" && e[r] <= "9";) r += 1;
				r === n && (r = t);
			}
			let a = "number";
			if (e[r] === "%") r += 1, a = "percentage";
			else if (Ge(e, r)) {
				for (r += 1; N(e[r]);) r += 1;
				a = "dimension";
			}
			t.push({
				type: a,
				text: e.slice(i, r),
				start: i,
				end: r,
				name: "",
				stringValue: ""
			}), n = r;
		} else if (Ge(e, n)) {
			let r = n + 1;
			for (; N(e[r]);) r += 1;
			let a = e.slice(n, r).toLowerCase();
			if (e[r] === "(") {
				let o = k(e, r, "(", ")"), s = Math.min(o, e.length);
				t.push({
					type: "function",
					text: e.slice(n, s),
					start: i,
					end: s,
					name: a,
					stringValue: ""
				}), n = s;
				continue;
			}
			t.push({
				type: "ident",
				text: e.slice(n, r),
				start: i,
				end: r,
				name: a,
				stringValue: ""
			}), n = r;
		} else if (r === "(") {
			let r = k(e, n, "(", ")"), a = Math.min(r, e.length);
			t.push({
				type: "function",
				text: e.slice(n, a),
				start: i,
				end: a,
				name: "",
				stringValue: ""
			}), n = a;
		} else t.push({
			type: "delimiter",
			text: r,
			start: i,
			end: n + 1,
			name: "",
			stringValue: ""
		}), n += 1;
	}
	return t;
}
function F(e) {
	return A(e, 0) === e.length;
}
function I(e) {
	let t = P(e);
	if (t.length === 0) return null;
	if (t.length === 1 && t[0].type === "string") {
		let e = M(t[0].stringValue);
		return e === "" ? null : {
			key: e,
			start: t[0].start,
			end: t[0].end
		};
	}
	if (t[0].type === "string") return null;
	for (let n = 0; n < t.length; n += 1) if (t[n].type !== "ident" || n > 0 && !F(e.slice(t[n - 1].end, t[n].start))) return null;
	if (t.length === 1 && (S.has(t[0].name) || Te.has(t[0].name))) return null;
	let n = M(t.map((e) => e.text).join(" "));
	return n === "" ? null : {
		key: n,
		start: t[0].start,
		end: t[t.length - 1].end
	};
}
function L(e) {
	let t = [], n = 0, r = 0;
	for (; r < e.length;) {
		let i = e[r];
		if (i === "\"" || i === "'") r = O(e, r);
		else if (i === "/" && e[r + 1] === "*") {
			let t = e.indexOf("*/", r + 2);
			r = t < 0 ? e.length : t + 2;
		} else i === "(" || i === "[" ? r = k(e, r, i, i === "(" ? ")" : "]") : (i === "," && (t.push({
			start: n,
			end: r
		}), n = r + 1), r += 1);
	}
	return t.push({
		start: n,
		end: e.length
	}), t;
}
function R(e) {
	let t = P(e);
	if (t.length < 2) return {
		body: e,
		important: ""
	};
	let n = t[t.length - 1], r = t[t.length - 2];
	return n.type !== "ident" || n.name !== "important" || r.type !== "delimiter" || r.text !== "!" || !F(e.slice(r.end, n.start)) ? {
		body: e,
		important: ""
	} : {
		body: e.slice(0, r.start),
		important: e.slice(r.start)
	};
}
function z(e, t) {
	if (t.length === 0) return e;
	let n = [...t].sort((e, t) => e.start - t.start), r = "", i = 0;
	for (let t of n) t.start < i || (r += e.slice(i, t.start) + t.text, i = t.end);
	return r + e.slice(i);
}
function qe(e) {
	return `"${e}"`;
}
function B(e, t, n = 0) {
	if (t.size === 0) return e;
	if (n > 64) throw C("theme.css", "font-family fallback nesting exceeds 64 levels.");
	let { body: r, important: i } = R(e), a = [];
	for (let e of L(r)) {
		let i = r.slice(e.start, e.end), o = I(i);
		if (o) {
			let n = t.get(o.key);
			n && a.push({
				start: e.start + o.start,
				end: e.start + o.end,
				text: qe(n)
			});
			continue;
		}
		let s = P(i);
		if (s.length !== 0 && (s.length !== 1 || s[0].type !== "ident" || !Te.has(s[0].name) && !S.has(s[0].name))) {
			if (s.length === 1 && s[0].type === "function" && s[0].name === "var") {
				let r = s[0], i = r.text.indexOf("("), o = r.text.slice(i + 1, -1), c = L(o), l = P(o.slice(0, c[0].end));
				if (!r.text.endsWith(")") || l.length !== 1 || l[0].type !== "ident" || !l[0].text.startsWith("--")) throw C("theme.css", "font-family var() must start with a custom property name.");
				if (c.length > 1) {
					let s = c[0].end + 1, l = o.slice(s);
					a.push({
						start: e.start + r.start + i + 1 + s,
						end: e.start + r.end - 1,
						text: B(l, t, n + 1)
					});
				}
			} else throw C("theme.css", "unsupported font-family syntax; use literal families or var() with a family-list fallback.");
		}
	}
	return z(r, a) + i;
}
function Je(e) {
	let t = P(e);
	if (t.length === 0 || t.length === 1 && t[0].type === "ident" && (Ee.has(t[0].name) || S.has(t[0].name))) return null;
	let n = -1;
	for (let e = 0; e < t.length; e += 1) {
		let r = t[e];
		if (r.type === "dimension" && !/(?:deg|grad|rad|turn)$/i.test(r.text) || r.type === "percentage" || r.type === "ident" && De.has(r.name) || r.type === "number" && Number(r.text) === 0) {
			n = e;
			break;
		}
		if (r.type === "function") {
			let i = t[e + 1];
			if ([
				"calc",
				"min",
				"max",
				"clamp"
			].includes(r.name) || r.name === "var" && i?.type === "delimiter" && i.text === "/") {
				n = e;
				break;
			}
		}
	}
	if (n < 0) return null;
	let r = n + 1, i = t[r];
	return i?.type === "delimiter" && i.text === "/" && (r += 2), r >= t.length ? null : t[r].start;
}
function Ye(e, t) {
	if (t.size === 0) return e;
	let { body: n, important: r } = R(e), i = Je(n);
	if (i === null) {
		let t = P(n);
		if (t.length === 1 && t[0].type === "ident" && (Ee.has(t[0].name) || S.has(t[0].name)) || t.length === 1 && t[0].type === "function" && t[0].name === "var" && L(t[0].text.slice(t[0].text.indexOf("(") + 1, -1)).length === 1) return e;
		throw C("theme.css", "unsupported font shorthand; use an explicit font size (including calc/min/max/clamp) and a family list.");
	}
	let a = B(n.slice(i), t);
	return n.slice(0, i) + a + r;
}
function V(e, t = !1, n = 0) {
	if (n > 64) throw C("theme.css", "nested font declarations exceed 64 levels.");
	let r = [], i = (i) => {
		let a = j(e, i + 1);
		if (t) for (let t of V(e.slice(i + 1, a), !0, n + 1)) r.push({
			name: t.name,
			valueStart: i + 1 + t.valueStart,
			valueEnd: i + 1 + t.valueEnd
		});
		return Math.min(a + 1, e.length);
	}, a = 0;
	for (; a < e.length && (a = A(e, a), !(a >= e.length));) {
		if (e[a] === ";" || e[a] === "}") {
			a += 1;
			continue;
		}
		if (e[a] === "{") {
			a = i(a);
			continue;
		}
		let t = a, n = a;
		for (; n < e.length;) {
			let t = e[n];
			if (t === "\"" || t === "'") n = O(e, n);
			else if (t === "/" && e[n + 1] === "*") n = A(e, n);
			else if (t === "(" || t === "[") n = k(e, n, t, t === "(" ? ")" : "]");
			else {
				if (t === ":" || t === ";" || t === "{" || t === "}") break;
				n += 1;
			}
		}
		if (n >= e.length) break;
		if (e[n] !== ":") {
			a = e[n] === "{" ? i(n) : n + 1;
			continue;
		}
		let o = P(e.slice(t, n)), s = o.length === 1 && o[0].type === "ident" ? o[0] : void 0, c = s?.text ?? "", l = c.startsWith("--") ? c : c.toLowerCase(), u = n + 1, d = u;
		for (; d < e.length;) {
			let t = e[d];
			if (t === "\"" || t === "'") d = O(e, d);
			else if (t === "/" && e[d + 1] === "*") d = A(e, d);
			else if (t === "(" || t === "[") d = k(e, d, t, t === "(" ? ")" : "]");
			else if (t === "{" && c.startsWith("--")) d = j(e, d + 1) + 1;
			else {
				if (t === ";" || t === "{" || t === "}") break;
				d += 1;
			}
		}
		e[d] === "{" ? a = i(d) : (s && r.push({
			name: l,
			valueStart: u,
			valueEnd: d
		}), a = d, e[d] === ";" && (a += 1));
	}
	return r;
}
function Xe(e, t) {
	if (t.size === 0) return e;
	let n = [];
	for (let r of V(e, !0)) {
		let i = r.name === "font-family" || r.name === "--font-sans" || r.name === "--font-mono";
		if (!i && r.name !== "font") continue;
		let a = e.slice(r.valueStart, r.valueEnd), o = i ? B(a, t) : Ye(a, t);
		o !== a && n.push({
			start: r.valueStart,
			end: r.valueEnd,
			text: o
		});
	}
	return z(e, n);
}
function Ze(e, t, n) {
	let r = 0;
	for (; r < e.length;) {
		let i = e[r];
		if (/\s/.test(i) || i === ";" || i === "}") {
			r += 1;
			continue;
		}
		if (i === "/" && e[r + 1] === "*") {
			let t = e.indexOf("*/", r + 2);
			r = t < 0 ? e.length : t + 2;
			continue;
		}
		if (i === "{") {
			r = j(e, r + 1) + 1;
			continue;
		}
		let a = r, o = r;
		for (; o < e.length;) {
			let t = e[o];
			if (t === "\"" || t === "'") o = O(e, o);
			else if (t === "/" && e[o + 1] === "*") {
				let t = e.indexOf("*/", o + 2);
				o = t < 0 ? e.length : t + 2;
			} else if (t === "(" || t === "[") o = k(e, o, t, t === "(" ? ")" : "]");
			else {
				if (t === "{" || t === ";" || t === "}") break;
				o += 1;
			}
		}
		if (o >= e.length) break;
		if (e[o] !== "{") {
			r = o + 1;
			continue;
		}
		let s = j(e, o + 1), c = e.slice(a, o).trim();
		if (c.startsWith("@")) {
			let r = (/^@([A-Za-z-]+)/.exec(c)?.[1] ?? "").toLowerCase();
			r === "font-face" ? n(e.slice(o + 1, s), t) : Ce.has(r) && Ze(e.slice(o + 1, s), t, n);
		}
		r = Math.min(s + 1, e.length);
	}
}
function Qe(e, t) {
	let n = V(e).filter((e) => e.name === "font-family");
	if (n.length === 0) throw C(t, "@font-face must declare a font-family descriptor.");
	if (n.length > 1) throw C(t, "@font-face may declare font-family only once.");
	let { body: r, important: i } = R(e.slice(n[0].valueStart, n[0].valueEnd));
	if (i !== "") throw C(t, "@font-face descriptors must not use !important.");
	if (L(r).length !== 1) throw C(t, "@font-face font-family must be a single family name, not a list.");
	let a = I(r);
	if (!a) throw C(t, "@font-face font-family must be one quoted or unquoted family name; generic families, keywords, var() and other functions are not allowed.");
	if (Ve(We(a.key)?.original ?? a.key).length > we) throw C(t, `@font-face font-family must not exceed ${we} UTF-8 bytes.`);
	return a.key;
}
function $e(e, t, n) {
	let r = /* @__PURE__ */ new Map();
	for (let i of e) Ze(i.css, n, (e, n) => {
		let i = Qe(e, n), a = We(i), o = a ? a.original : i, s = Ue(t, o), c = r.get(i);
		if (c !== void 0 && c !== s) throw C(n, `@font-face family "${i}" maps to more than one name.`);
		r.set(i, s), r.set(o, s);
	});
	return r;
}
function et(e, t, n) {
	let r = V(e).filter((e) => e.name === "font-family");
	if (r.length !== 1) throw C(n, "@font-face must declare exactly one font-family descriptor.");
	let i = r[0], { body: a } = R(e.slice(i.valueStart, i.valueEnd));
	if (L(a).length !== 1) throw C(n, "@font-face font-family must be a single family name, not a list.");
	let o = I(a);
	if (!o) throw C(n, "@font-face has an unsupported font-family descriptor.");
	let s = t.get(o.key);
	if (s === void 0) throw C(n, `@font-face family "${o.key}" was not registered.`);
	return z(e, [{
		start: i.valueStart + o.start,
		end: i.valueStart + o.end,
		text: qe(s)
	}]);
}
var tt = /* @__PURE__ */ new Map();
function nt(e, t, n = tt) {
	let r = "", i = 0;
	for (; i < e.length;) {
		let a = e[i];
		if (a === "/" && e[i + 1] === "*") {
			let t = e.indexOf("*/", i + 2), n = t < 0 ? e.length : t + 2;
			r += e.slice(i, n), i = n;
			continue;
		}
		if (/\s/.test(a) || a === ";" || a === "}") {
			r += a, i += 1;
			continue;
		}
		let o = i, s = i;
		for (; s < e.length;) {
			let t = e[s];
			if (t === "\"" || t === "'") s = O(e, s);
			else if (t === "/" && e[s + 1] === "*") {
				let t = e.indexOf("*/", s + 2);
				s = t < 0 ? e.length : t + 2;
			} else if (t === "(") s = k(e, s, "(", ")");
			else if (t === "[") s = k(e, s, "[", "]");
			else {
				if (t === "{" || t === ";" || t === "}") break;
				s += 1;
			}
		}
		if (s >= e.length) {
			r += e.slice(o);
			break;
		}
		let c = e.slice(o, s), l = e[s];
		if (l === ";" || l === "}") {
			r += c + l, i = s + 1;
			continue;
		}
		let u = j(e, s + 1), d = e.slice(s + 1, u), f = c.trim();
		if (f.startsWith("@")) {
			let e = (/^@([A-Za-z-]+)/.exec(f)?.[1] ?? "").toLowerCase();
			if (e === "import") throw C("theme.css", "must not use @import.");
			if (e === "keyframes" || e.endsWith("-keyframes")) throw C("theme.css", `@${e} declares a global name; phase one only supports document-scoped CSS.`);
			if (e === "font-face") r += `${f} {${et(d, n, "theme.css")}}`;
			else {
				let i = Ce.has(e) ? nt(d, t, n) : d;
				r += `${f} {${i}}`;
			}
		} else r += `${Be(f, t)} {${Xe(d, n)}}`;
		i = Math.min(u + 1, e.length);
	}
	return r;
}
function H(e, t, n = tt) {
	return nt(e, t, n);
}
function U(e, t) {
	if (!Array.isArray(e)) throw C(t, "must be an array of { id, css } resources.");
	if (e.length > he) throw C(t, `may contain at most ${he} resources.`);
	let n = /* @__PURE__ */ new Set(), r = [], i = 0;
	for (let a = 0; a < e.length; a += 1) {
		let o = e[a], s = `${t}[${a}]`;
		if (!ke(o)) throw C(s, "must be an object.");
		let c = o.id;
		if (typeof c != "string" || c.length === 0) throw C(`${s}.id`, "must be a non-empty string.");
		if (c.length > ge) throw C(`${s}.id`, `must not exceed ${ge} characters.`);
		if (!ye.test(c)) throw C(`${s}.id`, `"${c}" must start with a letter and use letters, digits, ".", "_", "-" or "/".`);
		if (n.has(c)) throw C(`${s}.id`, `"${c}" is declared more than once.`);
		n.add(c);
		let l = o.css;
		if (typeof l != "string") throw C(`${s}.css`, "must be a string.");
		if (l.length > _e) throw C(`${s}.css`, `must not exceed ${_e} characters.`);
		if (i += l.length, i > x) throw C(t, `must not exceed ${x} characters in total.`);
		Pe(l, `${s}.css`), r.push(Object.freeze({
			id: c,
			css: l
		}));
	}
	return {
		resources: Object.freeze(r),
		totalLength: i
	};
}
function W(e) {
	return Object.freeze({
		id: e.id,
		name: e.name,
		version: e.version,
		protocol: e.protocol,
		colorSchemes: Object.freeze([...e.colorSchemes]),
		css: Object.freeze(e.css.map((e) => Object.freeze({
			id: e.id,
			css: e.css
		})))
	});
}
function rt(e, t) {
	let n = w(e, t), r = T(n.id, `${t}.id`), i = E(n.name, `${t}.name`), a = D(n.version, `${t}.version`);
	if (n.protocol !== "reactive-md-theme-1") throw C(`${t}.protocol`, `must be "${y}".`);
	let o = Ae(n.colorSchemes, `${t}.colorSchemes`), { resources: s } = U(n.css, `${t}.css`);
	return W({
		id: r,
		name: i,
		version: a,
		protocol: y,
		colorSchemes: o,
		css: s
	});
}
function G(e) {
	let t = w(e, "input"), n = T(t.id, "theme.id"), r = E(t.name, "theme.name"), i = D(t.version, "theme.version");
	if ((t.protocol === void 0 ? "reactive-md-theme-1" : t.protocol) !== "reactive-md-theme-1") throw C("theme.protocol", `must be "${y}".`);
	let a = Ae(t.colorSchemes, "theme.colorSchemes"), { resources: o } = U(t.css, "theme.css"), s = $e(o, r, "theme.css");
	return W({
		id: n,
		name: r,
		version: i,
		protocol: y,
		colorSchemes: a,
		css: o.map((e) => Object.freeze({
			id: e.id,
			css: H(e.css, r, s)
		}))
	});
}
function it(e) {
	let t = w(e, "input"), n = T(t.id, "theme.id"), r = E(t.name, "theme.name"), i = D(t.version, "theme.version"), a = rt(t.base, "theme.base"), o = U(t.overrides, "theme.overrides"), s = $e([...a.css, ...o.resources], r, "theme.css"), c = new Set(a.css.map((e) => e.id));
	for (let e of o.resources) {
		if (c.has(e.id)) throw C("theme.overrides", `resource "${e.id}" is already declared by the base theme.`);
		c.add(e.id);
	}
	let l = [...a.css.map((e) => Object.freeze({
		id: e.id,
		css: H(e.css, r, s)
	})), ...o.resources.map((e) => Object.freeze({
		id: e.id,
		css: H(e.css, r, s)
	}))], u = 0;
	for (let e of l) if (u += e.css.length, u > x) throw C("theme.css", `must not exceed ${x} characters in total.`);
	return W({
		id: n,
		name: r,
		version: i,
		protocol: a.protocol,
		colorSchemes: a.colorSchemes,
		css: l
	});
}
function at(e) {
	let { resources: t } = U(w(e, "theme").css, "theme.css");
	return t.map((e) => e.css).join("\n");
}
// src/sdk/preset.ts
var K = /* @__PURE__ */ new WeakSet();
function ot(e, t) {
	let n = t instanceof Error ? t.message : String(t);
	throw Error(`Invalid local preset (themes[${e}]): ${n}`);
}
function q(e) {
	if (typeof e == "object" && e && K.has(e)) return e;
	let t = r(e);
	if (t.themes === void 0) return K.add(t), t;
	let n = t.themes.map((e, t) => {
		try {
			return G(e);
		} catch (e) {
			ot(t, e);
		}
	}), i = Object.freeze({
		...t,
		themes: Object.freeze(n)
	});
	return K.add(i), i;
}
function st(e) {
	return q(e);
}
function ct(e) {
	return i(e);
}
// src/sdk/config.ts
var lt = v.id, ut = v.version, dt = Object.freeze({
	id: lt,
	version: ut
}), ft = 16, pt = /* @__PURE__ */ new Set([
	"presets",
	"components",
	"replacements",
	"themes"
]), J = /* @__PURE__ */ new WeakSet();
function mt(e) {
	d(e) || m("themes", "each theme must be an object."), _(e, /* @__PURE__ */ new Set([
		"id",
		"name",
		"version",
		"protocol",
		"colorSchemes",
		"css"
	]), "theme");
	try {
		return G(e);
	} catch (e) {
		m("theme", e instanceof Error ? e.message : String(e));
	}
}
function Y(e) {
	if (e === void 0) return Object.freeze([]);
	Array.isArray(e) || m("themes", "must be an array."), e.length > 16 && m("themes", "accepts at most 16 themes.");
	let t = /* @__PURE__ */ new Set(), n = /* @__PURE__ */ new Set(), r = [];
	for (let i of e) {
		let e = mt(i);
		t.has(e.id) && m("themes", `theme id "${e.id}" is declared more than once.`), n.has(e.name) && m("themes", `theme name "${e.name}" is declared more than once.`), t.add(e.id), n.add(e.name), r.push(e);
	}
	return Object.freeze(r.sort((e, t) => e.id < t.id ? -1 : +(e.id > t.id)));
}
function ht(e, t) {
	if (typeof e == "string") return e !== "default" && e !== v.id && m(`presets[${t}]`, `unsupported preset "${e}"; phase one accepts only the built-in default package.`), v;
	if (d(e) || m(`presets[${t}]`, "must be a preset package, \"default\" or a preset reference."), e.protocol !== void 0 || e.components !== void 0) try {
		return q(e);
	} catch (e) {
		m(`presets[${t}]`, e instanceof Error ? e.message : String(e));
	}
	let n = e.id, r = e.version;
	return typeof n != "string" && m(`presets[${t}].id`, "must be a string."), typeof r != "string" && m(`presets[${t}].version`, "must be a string."), (n === "default" ? v.id : n) !== v.id && m(`presets[${t}]`, `unsupported preset "${n}"; phase one accepts only "${v.id}".`), r !== v.version && m(`presets[${t}].version`, `must be "${v.version}".`), v;
}
function gt(e) {
	if (e === void 0) return Object.freeze([v]);
	Array.isArray(e) || m("presets", "must be an array.");
	let t = [], n = /* @__PURE__ */ new Set();
	for (let r = 0; r < e.length; r += 1) {
		let i = ht(e[r], r);
		n.has(i.id) && m("presets", `preset "${i.id}" is selected more than once.`), n.add(i.id), t.push(i);
	}
	return Object.freeze([...t].sort((e, t) => e.id < t.id ? -1 : +(e.id > t.id)));
}
function _t(e) {
	if (e === void 0) return Object.freeze([]);
	Array.isArray(e) || m("components", "must be an array.");
	let t = e.map((e, t) => {
		try {
			return a(e);
		} catch (e) {
			m(`components[${t}]`, e instanceof Error ? e.message : String(e));
		}
	});
	return Object.freeze(t.sort((e, t) => {
		if (e.id !== t.id) return e.id < t.id ? -1 : 1;
		let n = e.replaces === void 0 ? 0 : 1, r = t.replaces === void 0 ? 0 : 1;
		return n === r ? e.version === t.version ? e.name < t.name ? -1 : +(e.name > t.name) : e.version < t.version ? -1 : 1 : n - r;
	}));
}
function vt(e) {
	return e === void 0 ? "allow" : (e !== "allow" && e !== "forbid" && m("replacements", "must be \"allow\" or \"forbid\"."), e);
}
function yt(e, n) {
	d(e) || m(n, "must be an object."), _(e, pt, n);
	let r = Object.freeze({
		protocol: t,
		presets: gt(e.presets),
		components: _t(e.components),
		replacementPolicy: vt(e.replacements),
		themes: Y(e.themes)
	});
	return o(r) > 16777216 && m(n, `serialized size exceeds the ${h}-byte budget.`), r;
}
function bt(e) {
	return Object.freeze({
		...e,
		presets: Object.freeze(e.presets.map((e) => q(e))),
		themes: Y(e.themes)
	});
}
function X(e) {
	let t = bt(e), n = te(t, { legacyProfiles: p }), r = ee(t, n);
	return J.add(r), r;
}
function Z(e = {}) {
	return X(yt(e, "config"));
}
var xt;
function St(e) {
	return e === void 0 ? xt ??= Z().key : Q(e).key;
}
function Ct(e) {
	return new Set(e.legacyKeys.map((e) => e.key));
}
function wt(e, t) {
	let n = Q(t ?? Z()), r = e.componentConfigKey;
	return r === void 0 || r === n.key || Ct(n).has(r) ? [] : [{
		code: "local.extension.config-mismatch",
		severity: "error",
		message: "The document compiler configuration differs from the installed renderer. Recompile with the same host.config used by host.reactConfig (including Worker requests).",
		range: {
			start: 0,
			end: 0
		},
		line: 1,
		column: 1
	}];
}
function Tt(e) {
	return e.preset.id === v.id && e.preset.version === v.version ? v : q({
		...v,
		id: e.preset.id,
		version: e.preset.version
	});
}
function Et(e, n) {
	let r = ae(e.presets, dt, n)[0] ?? dt, i = u(r, n);
	i === void 0 && m("presets", `local.config.migration-unsupported: no compatibility profile matches preset "${r.id}" ${r.version}.`);
	let a = i.legacyKeys[0];
	a === void 0 && m("presets", `local.config.migration-unsupported: profile "${i.name}" has no legacy key mapping.`), f(i, v.components);
	let o = Tt(i), s = re(e.components, v.components);
	s.some((e) => e.replaces !== void 0) && m("config", "replaces is not supported by reactive-md-config/v1.");
	let c = Y(e.themes), l = Object.freeze({
		protocol: t,
		presets: Object.freeze([o]),
		components: s,
		replacementPolicy: "forbid",
		themes: c
	}), d = te(l, { legacyProfiles: n }), p = ie(i.preset, d.components), ne = [...d.legacyKeys, ...d.legacyKeys.some((e) => e.key === p) ? [] : [Object.freeze({
		profile: a.profile,
		key: p
	})]], h = ee(l, d, ne);
	return J.add(h), h;
}
function Q(t, r = []) {
	return typeof t == "object" && t && J.has(t) ? t : (d(t) || m("config", "must be an object."), _(t, oe, "config"), t.protocol === "reactive-md-config/v1" ? Et(t, se(r)) : (t.protocol !== "reactive-md-config/v2" && m("config.protocol", `must be "${e}" (or legacy "${n}").`), X(ne(t.assembly))));
}
function Dt(e) {
	if (typeof e == "object" && e && J.has(e)) return e.key;
	try {
		return Q(e).key;
	} catch {
		try {
			return `invalid:${s(JSON.stringify(e))}`;
		} catch {
			return "invalid";
		}
	}
}
function Ot(e) {
	try {
		return Q(e);
	} catch {
		return e;
	}
}
// src/sdk/registry.ts
function kt() {
	return le;
}
function $(e) {
	return e ? Q(e).registry : kt();
}
function At(e, t) {
	let n = $(t);
	for (let t of n) if (t.name === e) return t;
}
function jt(e) {
	let t = /* @__PURE__ */ new Map();
	for (let n of $(e)) t.set(n.name, ce(n));
	return t;
}
export { pe as S, it as _, ut as a, b, St as c, Ot as d, wt as f, at as g, q as h, lt as i, Dt as l, ct as m, $ as n, ft as o, st as p, jt as r, Z as s, At as t, Q as u, G as v, y as x, Fe as y };
